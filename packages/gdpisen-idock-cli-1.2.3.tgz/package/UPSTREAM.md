# 上游来源

本目录从 https://github.com/yuque/yuque-cli 克隆后改造，原作者为 Barret Lee。

- 上游提交：`34016d90a16f08ab7f9baf9d0c0f68df1257ec2d`
- 上游 README 声明许可：MIT。
- 保留并改造了 Commander 命令入口、独立配置/API/业务编排结构，以及 `src/ui.js` 的中文终端表格算法。
- 业务已替换为本仓库的录音接口，配置、鉴权、下载、导出及交互命令均由本项目维护。
- 本目录由当前 Java 项目的 Git 仓库统一管理，不是 Git 子模块。
