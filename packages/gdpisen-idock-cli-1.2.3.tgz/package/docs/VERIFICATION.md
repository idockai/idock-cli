# iDock CLI 验证记录

2026-11-06，`@gdpisen/idock-cli@1.2.1` 已发布到官方 npm 仓库，`latest=1.2.1`。远端 integrity 及下载 tarball 的 SHA-256 与 2026-11-05 验证过的最终发布包完全一致，未重新打包。沿用 137 项全量测试和独立安装验证结果；发布回执及下载校验见仓库 `idock-cli/command-results/2026-11-06-release/`。

2026-11-05，1.2.1 发布准备：全量 Node **137 项通过，0 失败/跳过**。新增会议主键迁移回归，覆盖列表同时返回 `id/taskId`、大整数主键、后端 Long 边界、两种音频下载、全部文档导出通道及错误参数在请求前拒绝；运行时版本统一读取包清单。本轮为本地 HTTP/OSS 替身及独立子进程验证，没有执行线上业务联调，未重新运行 Java 后端测试。npm 和 GitHub 的实际发布状态另见仓库 `idock-cli/command-results/2026-11-05-release/README.md`。

2026-10-29 组织包验证：包名为 `@gdpisen/idock-cli`，tarball 为 `gdpisen-idock-cli-1.2.0.tgz`，命令继续使用 `idock`。全量 Node **133 项通过，0 失败/跳过**；在独立临时前缀离线安装后，确认 scoped 目录、bin 入口、version/help/schema 和包内 Skill 安装器均通过。默认公开发布到官方 npm registry；说明及 Skill ZIP 同步新名称。原无 scope 的安装路径仅保留在以下历史记录中。本轮不修改后端，详细证据见仓库 `idock-cli/command-results/2026-10-29-scope-release/README.md`。

最新验收（2026-10-28 18:22）：Node **133 项**、Java **184 项 / 15 类**全部通过，0 失败/错误/跳过。33 个命令均有本轮结果，含全部 23 个正式入口、7 个兼容入口、help 和两个真实 Windows TTY 入口；普通入口共 32 次调用，TTY 各 14 步，叶子帮助 33 份。逐条参数、完整返回、退出码、双节点 29 次限流及成功重试、五个合成附件见 [最新结果](../command-results/2026-10-28-refresh/README.md)。使用隔离 H2/Redis、双 MVC 和本机业务替身；本轮没有重测真实业务后端或部署服务。以下保留各阶段的历史验证记录。

日期：2026-10-27。按本次确认的 Node、P0–P2、RAG 专用检索、不新增会员及 30 天限制口径执行。

逐条命令、测试方法、修复项及未验证边界见 [TEST-MATRIX.md](TEST-MATRIX.md)。本轮补齐 23 个正式命令的实际子进程调用，并保留旧命令与真实终端验证；通过数量是测试/子测试数，不是命令数或全部参数组合数。

| 验证 | 结果 | 覆盖范围 |
| --- | --- | --- |
| Node CLI | 99 项通过，0 失败/跳过 | 23 个正式命令逐项真实执行，全部 help；JSON/text、大整数 ID、错误退出码、游标、确认计划、九种音频 MIME/SHA/上传字节、OSS 凭证隔离、断连/恢复、job 各状态/完成/失败/超时、配置优先级、下载/导出、交互连接继承及兼容命令 |
| Java 后端 | 156 项通过，14 个测试类，0 失败/跳过 | 共享 Redis 鉴权/撤销/导入幂等与多节点并发；全部业务路由 scope 隔离；H2/MyBatis 分页/归属/时间；各板块锁定与 Unicode 续读；四类闪记业务字段；八种真实文档生成与重新解析；既有上传/额度/转写回归 |
| Windows TTY | login、browse、repl 均通过 | 实际隐藏输入不回显；交互查询、关键词、翻页、选择、下载/导出文件、RAG 搜索、正文和退出。各浏览入口执行 9 个本地 HTTP 请求 |
| 浏览器 | 通过 | Chrome 中登录、签发、隐藏 Key、重置、撤销、退出；默认不授予导入，显式勾选后生效，页面无脚本错误、不持久化凭证 |
| Skill | 既有验证通过，本轮未修改 | skill-creator 的 quick_validate.py 校验 SKILL.md |
| 分发 | 临时安装后重跑 99 项全部通过 | npm pack、临时目录安装，IDOCK_TEST_ENTRY 指向安装后的 CLI 入口重跑同一套验收，包含 23 命令、版本/schema 和旧命令；本机 idock.cmd 指向 1.2.0 |

## 测试方式

Node：在 `idock-cli` 执行 `npm.cmd test`。

安装包：`npm.cmd pack` 后在独立临时前缀使用 `npm.cmd install --ignore-scripts --no-audit --no-fund` 安装；把 `IDOCK_TEST_ENTRY` 指向该前缀的 `node_modules/idock-cli/src/index.js`，再执行 `npm.cmd test`，99 项通过。临时安装不修改用户的全局安装。

Java：JDK 21 / Maven 3.9.4，在独立工作区副本执行下述命令，避免 IDE 编译覆盖测试产物：

```powershell
mvn -pl user-starter -am '-Dtest=IdockAgentReadTest,IdockDocumentExportTest,IdockRagServiceTest,IdockImportFlowTest,IdockAccessKeyFlowTest,IdockTelemetryFilterTest,IdockExportPermissionTest,IdockControllerLoggingTest,RecordingAudioDownloadServiceTest,TingwuMeetingTaskListTest,FileOfflineControllerTest,FileOfflineUploadQuotaTest,FileOfflineTranscriptionResultTest,FileOfflineStorageQuotaServiceTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.useIncrementalCompilation=false test
```

测试使用临时目录、本机随机端口 Redis、H2 和本地 HTTP。CLI 集成测试从真实 Node 入口执行全部 23 个正式命令，远端请求在两个 MVC 实例间交替调用，包含原音/MP3 下载落盘和导入实际 PUT。RAG、短信、OSS、听悟及计费服务使用本地替身，不读取真实业务数据或调用付费转写。导入集成中的业务编排为替身，其真实共享 Redis 幂等/恢复逻辑由 IdockImportFlowTest 独立验证。

专门验证了 OSS PUT 成功但登记未完成的恢复：新增 `objectExists` 表示本次 HEAD 已确认对象，独立于 `synced`；恢复时跳过 PUT 并完成原任务登记。相同幂等键的文件改名后继续沿用首次文件名和任务，不创建另一份上传对象。

CLI 来源回归继续保留：新导入写入 `source=cli/source_detail=idock-cli`，真实上传服务的 DAO 写入参数和返回值保留来源，四种存储/转写额度组合均覆盖；App HTTP 上传入口拒绝声明 `source=cli`。共享 Redis 验证了旧 phone 导入任务的原来源固定，以及跨节点任务查询返回持久化来源。

本轮修复未知命令误返回成功 schema、UUID 校验不严格、交互子命令丢失启动连接参数三个问题，均补有回归测试。浏览器本轮重跑通过：本地短信 1 次、签发/重置 2 次、API 请求 8 次、脚本错误 0。

## 发布前的环境联调

- 确认网关透传个人 Key 和 CLI 版本头，RAG 查询地址、内部认证及用户过滤已生效。
- 用测试账号实测真实音频的 OSS 上传、原音/MP3 下载、听悟转写和现有额度变化。
- 导入客户端上限暂按原稿 2GB／4 小时；共享上传默认 100MB，需要支持到 2GB 时设置 `FILE_OFFLINE_OSS_MAX_FILE_SIZE_BYTES=2147483648`，该设置也影响 App 离线上传。
- 导入上限与闪记命名仍在 [PRD](PRD.md) 标为待最终确认，不能把自动化测试通过视为产品口径确认。

## 2026-10-28 发布服务器配置回归

本次 `npm.cmd test` 全量运行 **107 项通过，0 失败、0 跳过**，其中原有 99 项保留，新增 `test/release.test.js` 的 8 项测试。后端代码本次未修改，上述 Java 结果仍为 2026-10-27 的验证记录。

新增覆盖：首次登录仅输入 AccessKey、交互只询问一次且保持隐藏输入、随包网关前缀与任意工作目录、配置覆盖优先级、已验证地址与凭证绑定、空地址/缺失/损坏/非法配置拒绝、实际 npm pack 拦截漏配、实际分发包解压后直接登录。发布测试在隔离副本和本地 HTTP 上执行，不修改真实网关、个人配置或全局安装。

Windows PowerShell 中直接执行 `idock --version` 已通过，无需固定使用 `.cmd`。`.cmd` 保留作为执行策略拦截 `.ps1` 时的备用入口。

## 2026-10-28 数据库 AccessKey 与 Redis 到期时间回归

上述 Java 命令在隔离工作区重新执行：**169 项通过，14 个测试类，0 失败、0 错误、0 跳过**。其中 `IdockAccessKeyFlowTest` 从 16 项增至 29 项，使用真实 MyBatis/H2、JDBC 事务、用户行锁、测试专用 Redis 和两个 MVC 节点，继续从实际 Node 入口执行全部 23 个正式 CLI 命令。此次未修改 Node 实现，未重复运行独立的 107 项 Node 套件。

新增 13 项数据库专项覆盖：手工设置 Key/到期时间、Redis 毫秒 TTL 与数据库固定失效时刻一致、缩短/延长期限且鉴权不续期、缓存丢失恢复原受限权限、手工换 Key 不继承导入授权、空值/错误格式/用户不匹配/注销拒绝、缓存损坏重建、权限元数据变更及损坏、普通用户实体读写与 fastjson/fastjson2/Jackson 输出隔离、授权写入失败回滚、数据库故障拒绝、事务开始前切主库及上下文恢复、撤销后重新签发、无效用户禁止签发。

首轮发现并修复并发首次签发的事务隔离问题：授权读取使用独立重复读事务，保持 Key 和权限快照一致；签发/重置/撤销使用读已提交事务并先锁用户行，让等待者在获取锁后读取已提交的新授权。修复后专项 29 项和上述 169 项回归均通过。

数据库迁移和手工生成示例位于 `user-starter/sql/045_add_idock_access_key.sql`；本次没有连接或修改业务数据库、Redis，也没有部署服务。上线需要先在各区域用户主库执行迁移，再升级全部节点；升级前只在 Redis 中保存的 Key 需要重新签发。

## 2026-10-28 终端帮助排版回归

`npm.cmd test` 全量执行 **112 项通过，0 失败、0 跳过**。原有 107 项保留，新增 `test/help.test.js` 的 5 项帮助专项；全部 23 个正式命令分别通过真实子进程验证文本帮助和显式 JSON 帮助。业务调用、版本、无参数 schema、退出码、上传、下载、导出及发布配置回归全部通过。

帮助专项覆盖根命令分区、中文说明、多层 `help` 与叶子 `--help` 一致、必填及继承参数、JSON 参数位置和兼容开关、未知路径、旧版/交互入口、颜色及无 ANSI 的机器输出。测试故意提供损坏的独立配置和不可连接的地址，确认帮助不依赖登录、初始化业务服务或改写配置。说明文档与 schema 同步声明：帮助默认文本，显式 `--format json` 或 `--json` 返回 JSON 信封；业务命令继续默认 JSON。

## 2026-10-28 可安装 Skill 回归

将已有 `SKILL.md` 补为可独立复制的 `idock-cli` Skill，添加 `agents/openai.yaml`、按需工作流引用、安装器和 [Codex 使用指南](SKILL-USAGE.md)。Skill 通过宿主终端调用已安装的 `idock`，不再假设 Skill 目录包含 CLI 源码。默认安装到个人 `~/.agents/skills/idock-cli`，支持 `--target` 指定技能父目录。

本次 `npm.cmd test` 全量执行 **116 项通过，0 失败、0 跳过**：保留此前 112 项，新增 4 项安装器测试。覆盖中文/空格路径、任意工作目录、仅复制三个必要文件、重复安装、保护用户定制、显式覆盖保留额外文件、帮助/非法参数不写入。既有真实 npm pack 测试增加 Skill 文件清单和解压包独立安装验证，登录与业务命令回归继续通过。

`skill-creator/scripts/quick_validate.py` 对仓库 Skill 和本机安装副本均校验通过。安装器已在本机实际运行；真实已登录 CLI 完成版本、schema、状态、最近录音、关键词定位、纪要读取及 `next_offset` 续读验证，只进行读取，不执行真实上传或撤销。本轮未修改后端，不重复运行 Java 全量测试；没有启动第二个 AI 会话来验证自动选中 Skill 的行为。

## 2026-10-28 全部 CLI 列表改为游标分页

`npm.cmd test` 全量执行 **122 项通过，0 失败、0 跳过**，保留此前 116 项，新增 1 项旧页码迁移和 5 项交互分页器测试。复数 `recordings list` 保留分组、手机关联和页大小，改为 `--cursor`；`--page` 仅兼容首页 1，拒绝深页码并明确提示迁移。兼容列表响应不再返回 `total/totalPages/pageNum`，新增 `next_cursor/has_more`，schema、帮助及 README 已同步。

Java 在独立构建副本执行本文原有的 14 类回归命令，**173 项通过，0 失败、0 错误、0 跳过**；此前为 169 项，新增 3 项真实 MyBatis/H2 游标查询及 1 项双 MVC 节点续读。直接捕获执行 SQL，验证 LIMIT、无 COUNT/无 OFFSET、ID 降序与深边界；保留手机多关联去重、用户/分组/删除/关键词/解锁过滤，覆盖首次读取后的插入及已读边界删除。App 页码查询与 CLI 游标查询共用过滤构造，App 的原有响应及分页回归继续通过。新 Agent 录音列表增加字段投影，不读取纪要正文等非列表字段。

Windows 真实伪终端执行 `browse`、`repl`，各 14 条输入全部通过、各 9 次本地 HTTP。覆盖首页 prev、末页 next 的重复操作不请求；find 重置、前后翻页、选择录音、下载、导出、搜索及正文窗口。逐条输出见仓库 `idock-cli/performance-audit/2026-10-28/cursor-tty.json`。所有服务和凭证使用隔离本地替身，没有修改业务数据库、原个人设置或全局 CLI 安装，没有重启或部署运行中的后端。

正文 get 仍保留 4000 Unicode 码点窗口，本次未新增 `--full` 或正文缓存。全文返回的传输、内存、AI 上下文及权限取舍说明见仓库 `idock-cli/游标分页改造与全文返回说明.md`；完整转写/纪要可使用现有 TXT 导出。最初性能审查保留为改造前基线，并加注本次已修复范围。

## 2026-10-28 转写临时 URL 与 CLI 本地转换

已将现有 `recording export --type transcription --file-format txt|md|markdown` 接到新的 `GET /idock/recordings/{id}/transcription-url`。后端仅执行精简归属/解锁查询并签名，不下载正文；CLI 从 OSS 流式落盘，在本地解析句子并原子生成 TXT/Markdown，只返回本地文件信息。PDF/Word 和纪要继续保留服务端生成。签名最长 15 分钟并受 Key 到期截断，不记录到命令结果或控制器响应日志；详情见 [TRANSCRIPTION-DOWNLOAD.md](TRANSCRIPTION-DOWNLOAD.md)。

`npm.cmd test` 全量 **128 项通过，0 失败、0 跳过**；此前 122 项继续通过，新增 `test/transcription.test.js` 的 6 项测试。覆盖真实 CLI 子进程的两种文本格式、中文/emoji/大整数 ID、时间/说话人、无用户凭证的 OSS GET、签名不泄漏、过期与断连重签、重试次数上限、权限拒绝不下载、错误页/损坏内容/空转写拒绝、流式字节限制、临时文件清理和禁止远端 HTTP/重定向。

Java 在独立副本运行 **61 项通过，6 个测试类，0 失败/错误/跳过**：`IdockTranscriptionDownloadServiceTest,IdockAccessKeyFlowTest,IdockAgentReadTest,IdockDocumentExportTest,IdockExportPermissionTest,IdockControllerLoggingTest`。其中新增 6 项真实 H2/签名专项和 1 项 MVC 授权专项；实际 Node 入口的跨节点集成已切换到本地对象存储下载，确认无正文中转且最终文件内容正确。旧的八组服务端文档生成与所有路由权限隔离继续通过。

签名专项验证逻辑删除/跨用户/损坏配置/未解锁/未生成拒绝、固定 TTL 及 Key 到期、两节点版本、历史 URL 丢弃旧签名与路径只解码一次、旧 HTTP 链接仅升级协议而不重编码签名。OSS 替身只允许 `generatePresignedUrl`，没有 GET/HEAD/PUT 调用。新增转写接口也验证 Cache-Control no-store，以及 Key 在签名前到期时返回 401。

测试没有连接真实业务 OSS、改动原用户设置或更新全局安装，没有发布 npm 或重启后端。安装包已随本次代码重新生成；服务端和 CLI 需配套更新后生效。本次未重复执行其余 9 类无关 Java 测试，上一条 173 项完整回归为分页改造时的记录。

## 2026-10-28 CLI 每用户每秒一次限流

在 SDK 的 AccessKey 拦截入口接入 `IdockCliRateLimiter`，使用共享 Redis 原子 NX 加一秒过期限制同一用户全部 CLI API，合法身份后的 scope/参数错误也计入额度。跨节点、跨接口、跨终端和 Key 重置均共用额度；拒绝请求不续期，Redis 故障返回 503 并阻止业务执行。超限返回 429 / `IDOCK_RATE_LIMITED` / `Retry-After: 1`。CLI 仅对该明确的执行前拒绝按秒等待，最多额外请求两次；持续竞争返回退出码 6 和等待秒数，不自动重放未知执行结果。

`npm.cmd test` 完整 **133 项通过，0 失败、0 跳过**；原有 128 项保留，新增 `test/api-rate-limit.test.js` 五项专项，覆盖同一身份和 POST 请求体/幂等键保持、有界等待、持续限流错误结构、文件流、网络异常/鉴权失败及无可信重试头的 RAG 上游错误不重放。

Java 在隔离副本执行 **56 项通过，6 个测试类，0 失败/错误/跳过**：`IdockAccessKeyFlowTest,IdockTranscriptionDownloadServiceTest,IdockImportFlowTest,IdockRagServiceTest,IdockTelemetryFilterTest,IdockControllerLoggingTest`。其中鉴权闭环新增四项，验证真实 Redis 的 16 请求并发唯一放行、到期恢复、拒绝不续期、节点/接口/Key 重置共享、不同用户独立、App 管理入口不受影响、非法身份隔离、scope 失败计数，以及存储异常/不确定结果拒绝执行业务。

实际 Node 子进程执行全部 23 个正式命令的双 MVC 节点闭环启用真实用户限流，断言确实发生 429 并等待后完成；包含上传/完成确认、任务等待、原音/MP3 和转写文本下载，确认导入创建与完成业务各执行一次，最终字节正确。普通 scope/参数专项使用放行替身隔离时间因素，真实额度行为由上述专项及完整命令闭环验证。

后端全部节点需要升级，CLI 包需重新安装，网关保留 `Retry-After`。规则及部署说明见 [RATE-LIMIT.md](RATE-LIMIT.md)。本次未修改业务数据库/Redis、未部署后端、未更新全局安装或发布 npm；未重跑其余无关 Java 类，历史全量结果见前文。

## 2026-10-28 文档与 Skill 分发同步

补齐 `SKILL.md` 和 `references/workflows.md`：完整转写/纪要优先一次导出后按需本地读取；旧复数列表同样使用游标且不再返回总数；转写临时 URL 由 CLI 自动消费，不传播签名；源 JSON 16 MiB 上限、重签与 API 限流重试分开处理；最终退出码 6 后 Agent 停止叠加重试，跨终端/接口/节点共用用户额度。

PRD 更新为 V1.4，使用指南增加既有 Skill 更新和独立 ZIP 安装说明；命令逐条实测记录、性能审查标注历史输出与最新行为，保留原始实测结果。重新生成 `idock-cli/idock-cli-skill.zip` 和 npm `.tgz`；本机 `~/.agents/skills/idock-cli` 在确认与旧发行源一致、没有个人修改后同步更新，保留未修改的界面元数据。

本轮执行 `node --test test/skill.test.js test/release.test.js`，**12 项通过，0 失败/跳过**，包含独立目录安装、更新冲突保护、发行包实际打包/解压及脱离源码安装 Skill。`quick_validate.py` 对仓库源、本机安装、ZIP 解压副本均通过；进一步按字节核对源文件、独立 ZIP、npm 包和本机三个受管理文件一致，文档相对链接检查通过。

本次只更新文档与 Skill 分发资源，没有修改 CLI/后端业务实现，不重复运行完整 Node 或 Java 套件；上一轮完整 Node 133 项及限流相关 Java 56 项结果见前文。没有请求真实业务接口或修改 Key/个人 CLI 设置，没有更新全局 CLI、部署后端或发布 npm。

## 2026-10-29 main-test 审查问题修复

修复用户档案误查业务分库的问题：按本次认证用户切换所属区域主库，仅查询时区字段，查询成功或异常后恢复原身份及业务分库。录音和闪记游标绑定解析后的绝对起止时间；跨当地日界或周界使相对时间窗变化时明确返回 `IDOCK_CURSOR_INVALID`，CLI 沿用一次首页重查并标记 `cursor_reset=true`。章节正文白名单补充听悟实际字段 `Headline`，保留原有 `Title` 和敏感信息过滤。默认 HTTP 网关按用户要求暂不调整。

新增 24 项正式回归：九项时区测试验证五类区域路由、真实 H2 主库/业务分库隔离、字段最小投影、异常与上下文恢复及显式覆盖；十一项时间窗测试同时执行录音和闪记查询，覆盖相对时间跨日/跨周、夏令时日界/跳时/重复时、同周跨日以及固定/无时间区间；四项章节测试验证 `chapters/all` 的真实标题、仅标题状态、Unicode 与敏感字段隔离。

独立工作区执行相关 Java 正式回归 **17 类 / 221 项通过**，另重新执行修复前失败的三个审查探针，**3 项均通过**；本轮合计 **18 类 / 224 项，0 失败、0 错误、0 跳过**。`npm.cmd test` 完整 **133 项通过，0 失败、0 跳过**，现有失效游标一次重查及参数保留测试继续通过。已按字节核对独立工作区执行的四份修改 Java 文件与当前项目一致。

完整日志、测试统计及修复说明见 [2026-10-29 修复验证记录](../command-results/2026-10-29-main-test-fixes/README.md)。本次未连接正式业务环境、未发布 npm 或部署服务。后端全部节点需同步更新；升级前的录音和闪记游标会进入既有的失效重查流程。CLI 调用契约及 Skill 操作步骤保持兼容。
