# iDock Agent CLI PRD

| 项目 | 内容 |
| --- | --- |
| 文档版本 | V1.4（同步游标、转写直传与用户限流） |
| 原作者 | 于桐 |
| 更新日期 | 2026-10-28 |
| 原始文件 | iDock Agent CLI PRD.md V1.2 |

## 本次确认的范围

1. 保留并扩展现有 **Node.js 实现**，不改为 Python。命令名继续使用 `idock`，环境变量前缀 `IDOCK_`，配置目录 `~/.idock/`。
2. **P0、P1、P2 全部交付**：认证、自发现、环境配置与诊断、录音读取/导出/下载/导入、RAG 搜索、闪记读取、异步任务查询和等待。
3. **`idock search` 仅检索现有 RAG 向量库**，调用用户隔离查询接口。录音和闪记的列表筛选使用各自命令，搜索结果不从业务数据库补齐。
4. **本次不做会员与 30 天限制**，不按会员身份限制录音、搜索、详情、导出或下载。既有资源归属、内容解锁、无痕及上传/转写额度逻辑继续复用。

本文件是项目内的产品与实现契约；原需求链接中的附件未随 Markdown 导出。本次不新增附件中可能存在但此文未定义的翻译、笔记写入或 MCP 功能。

## 交付与用户流程

交付现有 Node CLI、`SKILL.md`、后端接口、使用说明及测试。需要 Node.js 22+，通过 `npm ci` 安装现有依赖；可 `npm link` 提供 `idock` 命令，也可直接运行 `node <目录>/src/index.js`。npm 发行包归属 `gdpisen` 组织，包名为 `@gdpisen/idock-cli`，公开安装命令为 `npm install -g @gdpisen/idock-cli`；本地分发文件名为 `gdpisen-idock-cli-1.2.1.tgz`，Skill 名称仍为 `idock-cli`。

Skill 使用随包安装器复制到个人 `~/.agents/skills/idock-cli/`；项目共享或旧版宿主可通过 `--target` 指定技能父目录。也可解压独立 `idock-cli-skill.zip` 后复制整个 Skill 目录。复制 Skill 不会安装 CLI 或增加 PATH；具体步骤见 [SKILL-USAGE.md](SKILL-USAGE.md)。Windows 保留现有原生 Node 支持，也支持 WSL。本次不实现 MCP，不自动发布 npm。

用户在 iDock App 生成按 scope 授权的 AccessKey。后端管理接口及同源测试管理页继续保留，App 前端可复用接口。CLI 登录只使用个人 Key，无需用户 ID 或 App Token。

流程：生成 Key → `auth login` 校验后保存 → `schema`/`doctor` → 查列表或向量检索 → 读取必要正文 → 导出/下载或确认导入 → `job wait` → 本机退出或服务端撤销。

发布包由维护者在 `config/release.json` 预先配置完整服务器地址，含统一网关路径前缀；用户安装后直接执行 `idock auth login`，仅输入个人 AccessKey，不再询问服务器地址。打包和发布前校验配置，地址漏配或非法时停止。命令直接使用 `idock`；Windows 的 `.cmd` 仅作脚本策略受限时的备用入口。

## 能力清单

| 优先级 | 命令 | 行为 |
| --- | --- | --- |
| P0 | `auth login` | 隐藏输入或标准输入接收 Key，远端校验后才保存 |
| P0 | `auth status` | 查询固定有效期、scopes、末四位与状态 |
| P0 | `schema` | 无需登录，输出结构化命令、参数、默认值及退出码 |
| P0 | `recording list` | 按时间、标题关键词、来源筛选，最多十条，游标分页 |
| P0 | `recording get <id>` | 元信息和转写、章节、笔记、AI 纪要；按板块与字符窗口读取 |
| P0 | `search <问题>` | 仅查询当前用户 RAG 向量库，返回片段、分数及锚点 |
| P1 | `auth logout` / `config set` / `doctor` | 本机退出、配置非秘密字段、连接/鉴权/版本检查 |
| P1 | `recording export` | 转写或纪要导出 txt、md、pdf、Word，返回实际文件路径 |
| 保留 | `recording download` | 下载原始音频或 MP3；支持原有批量处理与流式落盘 |
| P1 | `flash <类型> list/get` | 按类型和时间读取四类闪记，正文可裁剪续读 |
| P2 | `recording import <文件>` | 确认后直传 OSS，登记完成后触发现有离线转写并返回 job_id |
| P2 | `job get/wait <job_id>` | 查询或有界等待原任务，超时不重新上传 |

旧 `recordings list/show/download/export` 保留兼容；Agent 优先使用上述单数命令。原交互模式由 `browse`/`repl` 显式进入；无参数调用输出 schema。交互 `find` 按录音名筛选，`search` 调用 RAG。

## 命令与输出规则

- 业务命令 stdout 默认只有一个 JSON 信封：`{ok,data,meta,error}`。`meta.cli_version` 标识 CLI 版本，错误包含稳定 `code/message/hint/retryable`，权限错误附缺失 scopes。进度、日志和交互提示写 stderr。
- `--help` 默认输出终端分区排版：功能/工具/交互命令、全局及当前参数、示例、Agent 上手指引；子命令支持同样的帮助。`idock help <多层命令路径>` 可直达叶子帮助。交互终端支持颜色，管道、重定向和 `NO_COLOR` 使用纯文本。显式 `--format json` 或 `--json` 返回 `{ok,data:{help},meta,error}`，`schema` 和无参数调用继续返回 JSON 契约；帮助不读取凭证或访问网络。
- 全局 `--format text` 面向人类显示；导出文档格式独立使用 `--file-format`，避免冲突。旧 `recordings export --format word` 兼容转换为文件格式。
- 退出码：0 成功或待确认计划，2 参数，3 认证，5 权限，6 限流，1 服务/任务失败或批量部分失败。部分成功保留已生成文件并给出每项结果。
- 机器 JSON 保留后续定位所需的内部 ID、RAG 锚点和游标；Agent 回复用户时隐藏内部 ID、request_id 和秘密。
- Agent 列表和搜索 `--limit` 为 1 至 10；服务端新接口同时校验。不会自动遍历整库。空结果成功返回空数组。
- `today` 为用户时区当日，`7d` 为含当日在内七个自然日，`last-week` 为上一自然周周一零点至本周周一零点。`--from/--to` 接受带时区偏移的 ISO 时间，使用含起点、不含终点区间，与 `--time` 互斥。
- 时区默认来自用户档案，可用 `IDOCK_TIMEZONE`/`--timezone` 显式覆盖；历史无配置用户使用 Asia/Shanghai。日期过滤按记录创建时间。
- 正文默认最多 4000 个 Unicode 码点，返回 `offset/truncated/next_offset/total_chars`，`--offset` 续读。单板块锁定返回权限错误；`all` 返回已解锁板块并说明各板块状态。
- 游标绑定用户、类型和过滤条件，录音与闪记还绑定解析后的绝对时间窗；相对时间因跨当地日界或周界改变时，旧游标须明确返回 `IDOCK_CURSOR_INVALID`，不能成功返回遗漏原时间窗记录的空页。失效时 CLI 只重查一次当前时间窗首页并标记 `cursor_reset=true`；跨日连续遍历固定区间使用 `--from/--to`。RAG 不是普通列表游标，受现有 RAG top_k 配置影响，CLI 不伪造分页或额外结果。
- 旧复数 `recordings list` 与交互浏览也采用 ID 游标，兼容分组/手机关联过滤，返回 `dataList/pageSize/next_cursor/has_more`，不查询总数或返回 `total/totalPages/pageNum`。`--page` 只兼容 1，其余明确拒绝；交互保存已访问游标以支持上一页，首尾不发重复请求。
- `recording get` 保留窗口，没有新增 `--full`；需要完整转写/纪要且已具备导出权限时优先一次导出，再按需读取本地文件。

## 转写文本直传

`recording export --type transcription --file-format txt|md|markdown` 自动申请临时 URL，CLI 从 OSS 无用户凭证下载句子 JSON 并在本地生成文本，成功后只返回实际文件信息。后端校验归属、删除、转写解锁和 `transcription:export`，只签名，不读取或中转正文。签名最多 15 分钟，受 AccessKey 到期时间限制，URL 不出现在命令结果或普通响应日志中。

转写源实际解压后字节上限为 16 MiB；失败清理临时源，不发布不完整文件。OSS 失败默认额外重签一次，`--retries 0..5` 控制。PDF/Word 与所有纪要格式仍走原服务端生成；新转写文本链路需配套升级后端，不静默回退。详见 [TRANSCRIPTION-DOWNLOAD.md](TRANSCRIPTION-DOWNLOAD.md)。

## 授权与多节点

个人 AccessKey 默认 90 天、可撤销；保留原有可配置期限。明文仅在签发/重置接口响应中返回。按直接改库管理的要求，`user` 表新增 `idock_access_key` 和 `idock_access_key_expire_time` 两个字段，普通用户实体读写和 JSON 输出隐藏；权限、摘要和签发时间复用同一用户主库的 `app_user_setting` 内部记录。每个用户一把有效 Key，重置替换旧 Key。

手工配置的 Key 须采用 `idock_<真实用户ID>_<64位小写随机十六进制>` 格式并填写未来到期时间，默认授予六项读取/下载/导出权限，不继承旧 Key 的导入授权。接口签发的受限权限在 Redis 清空后仍从数据库恢复，不扩大为默认权限。

| scope | 能力 | 默认授予 |
| --- | --- | --- |
| `recording:read` | 录音列表与已解锁正文 | 是 |
| `recording:download` | 音频下载授权 | 是 |
| `transcription:export` | 转写导出 | 是 |
| `summary:export` | 纪要导出 | 是 |
| `rag:search` | 用户 RAG 向量库检索 | 是 |
| `flash:read` | 四类闪记读取 | 是 |
| `recording:import` | 上传并触发转写、查看导入任务 | **否，显式勾选** |

Key 使用 `X-Access-Key`，不得使用请求体/URL 传入身份或用内部共享 Key 替代。管理接口只接受原 App 登录态。鉴权在业务分库路由前完成，每次核对所属区域用户主库的当前授权，直接改库和多节点重置均在后续请求生效，完成后恢复原路由上下文。用户行锁及事务保证多节点首次签发、重置和撤销的一致性。

Redis 只缓存摘要快照，Lua 原子设置数据库的绝对到期时间，TTL 为数据库到期时间减当前时间；请求不续期，缓存缺失或损坏时按数据库恢复。数据库到期时间为空、已过期或用户注销均拒绝授权；数据库或 Redis 故障时拒绝授权。上线前在所有区域用户主库执行迁移脚本，再升级全部节点；原 Redis 独有的 Key 需要重新签发。

**CLI 每用户限流：** 有效 AccessKey 和用户身份验证后，全部 CLI API 合计每秒最多一次；共享 Redis 原子占位，两个放行至少间隔 1000 毫秒，拒绝不续期，不按自然秒重置。跨接口、终端、节点和重置 Key 共用用户额度，不同用户独立；后续 scope/参数/业务错误也消耗已取得的额度。App 接口与 OSS 直传不使用此额度。

超限返回 HTTP 429 / `IDOCK_RATE_LIMITED` / `Retry-After: 1`，CLI 已对这一执行前拒绝自动等待并最多额外请求两次，持续超限退出码 6，附 `error.details.retry_after_seconds`。Redis 故障或不能确定占位结果时返回 HTTP 503 / `IDOCK_RATE_LIMIT_UNAVAILABLE`，不执行业务或退化成本机限流；网关透传该头和真实 HTTP 状态。全节点需配套更新，详见 [RATE-LIMIT.md](RATE-LIMIT.md)。

## 导入与任务恢复

写操作先输出计划供 Agent 复述；显式 `--yes` 才发出上传或撤销请求。CLI 的文件扫描、摘要计算、OSS PUT 均不会发送 App Token，OSS 请求不携带个人 AccessKey。

导入声明包含本地文件、实际音频秒数、字节数、流式 SHA-256 及幂等键。不依赖 ffmpeg/ffprobe，非 WAV 容器也不猜测时长，用户通过 `--duration-seconds` 提供实际值。

文件以流方式上传，申请授权与完成确认复用现有服务。**上传并被服务端受理后立即返回 job_id，不等待转写完成**；上传大文件本身需要传输时间。完成确认按服务器保存的对象执行，不能由客户端切换 objectKey。

新导入音频保存 `offline_audio.source=cli`、`source_detail=idock-cli`，由服务端根据专属 CLI 入口写入；App 的设备/手机上传入口不能声明 CLI 来源。CLI 无设备 SN，不查询 OTA 型号；转写任务仍为 `OFFLINE`。`job get/wait` 返回持久化的 `source/source_detail`。改造前已按 phone 准备的导入任务保留原业务身份，仍可用 `source_detail=idock-cli` 识别，重试不切换来源。

来源字段已有 VARCHAR 存储，无需新增表或列。多节点部署应先升级全部服务节点，再开放新版 CLI 导入，保证所有节点均能识别 `cli` 来源。

相同用户和幂等键在七天任务元信息保留期内复用任务；不同内容、大小、时长或 MIME 复用同键返回冲突。默认幂等键为文件 SHA-256，也可显式提供。共享 Redis 记录准备状态，分布式锁避免重复初始化；转写提交沿用数据库唯一认领和既有后台补偿。

`job wait` 只查询原任务，超时不取消后台处理、不再次上传，也不重新创建听悟任务。七天后 CLI 临时任务查询过期，但业务录音仍按原规则保留，与会员和 30 天限制无关。

### 仍待确认的细节

- 原 PRD 的导入上限为“暂定单文件 2GB／4 小时”；目前实现及验证按此草案执行，待产品最终确认。
  实际文件上限还受现有共享上传配置约束，默认 100MB；若部署需支持到 2GB，应设置 `FILE_OFFLINE_OSS_MAX_FILE_SIZE_BYTES=2147483648`，此设置同样作用于 App 的离线上传接口。
- 闪记命名建议：`note`=随手记、`todo`=待办、`bill`=账目、`idea`=灵感；兼容原 PRD 的 `flash flash` 作为灵感别名，待产品最终确认。

## 错误与监控

未登录或 Key 过期提示 `auth login`；scope 不足列出缺失项；RAG/Redis/OSS 故障不伪装成功空结果；版本过低返回升级提示。录音不存在、已删除、其他用户资源统一返回不存在。

复用 Micrometer/Prometheus，服务端记录 `cli_command_total`、`cli_auth_result`、`cli_search_result`、`cli_search_hits` 与 `cli_truncation_rate`。标签只使用有限命令类别、HTTP 状态和布尔值，不采集问题正文、令牌、用户 ID 或签名 URL；纯本地 schema/config 操作不产生服务端请求指标。

## 验收

- Node：JSON 与 text、schema、参数边界、精确大整数 ID、错误退出码、游标重置、确认计划、流式导入/下载、OSS 凭证隔离、转写本地转换/超限清理/重签、有界限流等待、导出落盘、job 超时不重传、配置切换、旧命令回归。
- Java：真实 Redis 下签发/撤销/重置及导入幂等、多节点和并发冲突；真实 MyBatis/H2 下分页前过滤、日期边界、类型/用户/删除隔离；正文锁定与 Unicode 续读；HTTP RAG 用户过滤、元信息白名单和失败响应。
- 集成：真实 Node CLI 通过 HTTP 在两个 MVC 节点间完成认证、读取、导出及撤销，并启用真实隔离 Redis 的每用户限流；验证并发唯一放行、到期恢复、Key 重置共享及存储故障拒绝。外部 RAG/OSS/听悟使用本地替身，测试不发送真实短信、不使用真实业务数据或扣费。
