# iDock CLI 发布与 GitHub 文档同步

本流程用于后续每次“发布 npm 并同步 GitHub 文档”的任务。npm 包为 `@gdpisen/idock-cli`，命令为 `idock`；对外文档仓库为 `https://github.com/mu-qiao/idock-cli`，默认分支为 `main`。服务端仓库与公开文档仓库分别处理。

## 1. 核对状态与登录

在 `idock-cli` 目录检查 `git status --short`，保留已有修改。查询官方仓库的当前版本和登录状态：

```powershell
npm.cmd view @gdpisen/idock-cli version dist-tags --json --registry=https://registry.npmjs.org/
npm.cmd whoami --registry=https://registry.npmjs.org/
```

使用现有登录发布，不读取或展示 `.npmrc` 中的 Token。返回 401 时，让用户在自己的终端执行 `npm.cmd login --registry=https://registry.npmjs.org/`，继续准备与登录无关的工作；恢复后重新执行 `whoami`。双因素认证由用户本人完成。

需要 Agent 唤起授权时，使用带 TTY 的 `npm.cmd login --registry=https://registry.npmjs.org/ --auth-type=web`，按 Enter 触发 npm 自带的浏览器打开动作，同时立即把本次命令生成的完整链接提供给用户。保持该进程运行，等待用户在浏览器完成通行密钥、PIN 或其他验证；用户凭证不得交给 Agent。旧链接返回 404 时取消旧的登录等待，重新生成链接，不复用历史授权地址。浏览器额外启动操作若被执行策略拒绝，直接使用链接，不更换系统启动方式绕过策略。

GitHub 使用独立的干净检出目录，先检查其状态、远端地址和分支，再拉取最新提交。可复用本机现有文档检出目录，但不要覆盖其中未提交的修改。GitHub 直连失败时，可检查本机已有代理；本次验证过 `git -c http.proxy=http://127.0.0.1:7890 ...`，使用前仍需确认该端口实际监听，仅对当前命令设置，不修改全局 Git 配置，不关闭 TLS 校验。

本机 Git Credential Manager 保存了 `mu-qiao` 和 `idockai` 两个账号，默认选择可能导致 403。用 `git credential-manager github list` 只列出账号名；已有 `mu-qiao` 登录时，可以用以下命令选择正确身份，不读取凭证、不退出其他账号：

```powershell
git -c http.proxy=http://127.0.0.1:7890 -c credential.useHttpPath=false -c credential.gitHubAccountFiltering=true push https://mu-qiao@github.com/mu-qiao/idock-cli.git main
```

代理参数仅在已验证本机代理可用时添加；`mu-qiao` 是公开仓库所属账号名，不是 Token。普通 `credential.username` 在本机配置下未能避免选中 `idockai`，应以上面的显式用户名 URL 和账号筛选为准。

## 2. 更新版本与文档

选择未发布的版本；兼容性修复通常递增补丁版本：

```powershell
npm.cmd version <新版本> --no-git-tag-version --ignore-scripts
```

`src/version.js` 从随包 `package.json` 读取版本，命令输出、schema、响应信封、HTTP 请求头和 doctor 检查均引用它。测试中的服务端最低版本可以保留历史值；当前版本的断言应读取统一版本来源。

更新本地 `README.md`、`README.zh-CN.md` 及受影响的 `docs/`。历史验证的日期和版本保留原值，避免把旧测试写成新结果。更新 `github/README.md` 和 `github/CHANGELOG.md` 中的公开安装、迁移与版本说明，不公开服务端源码、用户数据、账号凭证或测试内部日志。若改动 Skill，则同时更新受管理的引用资源和独立 Skill ZIP；未改动 Skill 时沿用原文件。

## 3. 验证与固定发布包

依赖缺失时按锁文件安装，然后运行全量测试：

```powershell
npm.cmd ci --ignore-scripts --no-audit --no-fund
npm.cmd test
git diff --check
```

检查 `config/release.json` 中的服务器根地址和网关前缀；多节点环境使用统一网关。该文件仅包含公开连接地址，不得包含个人 AccessKey。运行 `npm.cmd pack --json`，核对文件清单不包含服务端源码、个人配置或 `node_modules`，记录生成包的 SHA-256 和 npm integrity。

在独立临时前缀安装刚生成的 tarball（`npm.cmd install --prefix <临时目录> <tarball绝对路径> --ignore-scripts --no-audit --no-fund`），执行包内入口的 `--version`、`--help`、`schema` 和 Skill 安装器；检查其版本、会议主键契约及三个 Skill 文件。验证不读取真实业务账号或触发音频上传。验证后不再修改待发包内容；若修改则重新测试相应部分、打包和校验。

## 4. 发布 npm 并读回核验

发布已验证的同一个 tarball，不能临时重新打包目录：

```powershell
npm.cmd publish .\gdpisen-idock-cli-<版本>.tgz --access public --tag latest --registry=https://registry.npmjs.org/
npm.cmd view @gdpisen/idock-cli@<版本> version dist.integrity dist.tarball --json --registry=https://registry.npmjs.org/
npm.cmd view @gdpisen/idock-cli dist-tags --json --registry=https://registry.npmjs.org/
```

核对返回版本、integrity 和 `latest`。从官方仓库下载该版本，确认下载包 SHA-256 与验证过的本地 tarball 一致。只有发布命令成功且远端读回一致，才记录“已发布”。若网络中断导致结果未知，先查询该版本，避免重复发布或无理由增加版本号。认证失败时保留发布包和验证记录，待用户恢复登录后继续。

登录成功不等于本次发布已获 npm 的验证。发布命令也使用 TTY；若返回 `Authenticate your account at` 和 `/auth/cli/` 链接，按 Enter 触发 npm 的浏览器打开动作，并立即把该链接提供给用户，保持同一个发布进程等待。用户完成网页确认后由该进程继续；不要另起重复发布请求，不索要或记录验证码，不将短期授权链接写入发布记录。

若命令退出码为 0、打印 `+ @gdpisen/idock-cli@<版本>`，同时提示 `Your package is being processed`，说明 npm 已受理，公共查询可能暂时仍为 404、latest 仍指向旧版。保留成功回执，等待 registry 处理完成并再次读回，不能把这种延迟当作发布失败而重复发包或增加版本。

本次遇到过 `whoami` 返回 401、`publish` 却返回 404 的情况；此时不能据 404 判断公开包不存在，应先用 `npm view` 核对包和版本，再恢复发布账号登录与组织权限。不要因这类认证失败改包名、registry 或连续增加版本号。

## 5. 推送 GitHub 文档并核对提交

公开仓库仅同步文档：`github/README.md` 对应远端根目录 `README.md`，`github/CHANGELOG.md` 对应远端根目录 `CHANGELOG.md`。核对 Markdown 相对链接在该仓库中确实存在。

在独立文档检出目录执行 `git diff --check`、审查差异、仅暂存本次文档，然后提交并 `git push origin main`。不强制推送；远端更新导致拒绝时先拉取并解决本次文档冲突。推送后用 `git ls-remote origin refs/heads/main` 核对远端 SHA 与本次提交一致，必要时读取 GitHub 页面检查展示。npm 尚未发布时，公开版本记录必须准确标明“待发布”，不能宣称可安装该版本。

## 6. 保存本次记录

在 `command-results/<日期>-release/` 保存版本、测试数量与范围、tarball 文件名、SHA-256、npm integrity、官方发布核验结果、GitHub 提交 SHA 和文档路径、遇到的问题及解决方式。不写 Token、密码、验证码、用户 AccessKey 或登录配置。最终回复给出 npm 版本、GitHub 文档链接及记录位置；未完成项明确说明原因和恢复入口。
