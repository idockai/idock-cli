# 完整转写从 OSS 下载

使用现有导出命令，无需手工复制或访问临时 URL：

```powershell
idock recording export --id 123 --type transcription --file-format txt --out ./exports
idock recording export --id 123 --type transcription --file-format md --out ./exports --retries 1
```

TXT、md/markdown 走以下流程：

1. CLI 携带 AccessKey 请求 `GET /idock/recordings/{id}/transcription-url`。
2. 后端验证 `transcription:export`，查询当前用户未删除的录音及转写解锁配置，只计算 OSS GET 签名，不读取正文，不生成新对象。
3. 返回 `downloadUrl/expiresAt/sourceFormat/version/fileName/title/meetingId`；响应为既有 `Response` 信封并带 `Cache-Control: no-store`。URL 最长有效 15 分钟，不晚于个人 Key 到期。
4. CLI 直接从对象存储流式下载 JSON 到独立临时目录，请求不携带 AccessKey、App Token 或 Authorization，不跟随存储重定向。
5. 本地解析句子列表，按时间、说话人、内容生成 TXT/Markdown。只在完整成功后原子发布最终文件，返回本地路径、实际字节数及来源版本标识，清理原始临时 JSON。

示例结果项：

```json
{
  "id": "123",
  "success": true,
  "type": "transcription",
  "format": "txt",
  "path": "D:\\exports\\123_sentences_123456.txt",
  "sizeBytes": 256,
  "version": "源对象与数据库更新时间生成的哈希标识"
}
```

结果不包含下载 URL。`version` 用于标记本地文件来源，不是 OSS 原生版本或持续授权凭证；对象在原路径被覆盖时，不提供对象版本锁定保证。

## 权限和兼容

- 需要 `transcription:export`，不能用 `recording:read`、音频下载或纪要导出权限代替；锁定和损坏配置在签发前拒绝。
- 仅对服务端配置的精确 OSS 桶/域名签名，兼容 `oss://` 和历史 HTTPS 地址；旧签名查询参数丢弃后重签，真实对象名只解码一次。
- 下载 URL 不记录到 CLI 结果或普通控制器响应日志。已签发 URL 是独立短期授权，Key 撤销不能立即作废该 URL；有效期到达后需重新鉴权申请。
- 后端签发不依赖节点内存或本地文件，任意节点均可处理；本地文件属于执行该 CLI 的机器，AI 需在同一可访问环境中读取。
- PDF/Word 与所有纪要格式继续由已有后端接口生成；旧 HTTP 转写导出接口继续保留供兼容使用。新 CLI 的转写文本需要更新后的后端，不静默回退到重复正文读取。
- `recording get --offset/--length` 仍是最多 4000 Unicode 码点的片段读取，没有新增 `get --full`。需要完整转写时优先执行上面的导出命令，再按需读取本地文件。

## 失败与边界

签名过期、存储 403、网络中断、存储限流和可重试服务错误，默认最多重新申请一次链接；`--retries 0..5` 控制额外重签次数。申请授权遇到明确的用户 API 限流时，CLI 另按 `Retry-After` 等待并最多额外请求两次，详见 [RATE-LIMIT.md](RATE-LIMIT.md)；401/403 等授权拒绝不重新申请。多个 ID 仍逐项报告，部分失败退出码为 1，已成功文件保留。

下载实际字节和声明大小均受 16 MiB 源 JSON 上限约束；压缩响应按解压后字节检查。下载为流式落盘，本地 JSON 解析仍需在内存中处理这份受限源文件。HTML/XML、非法 UTF-8/JSON、非句子数组、非法内容字段和空转写均不会生成伪文档。输出同名、覆盖及临时文件发布沿用已有下载规则。

TXT 保留 `[mm:ss.SS]说话人:  内容`，分钟可超过 59；Markdown 保留会议标题及每句说话人/时间小节。额外内部字段不写入最终文本。

## 本次验证

- Node 实际入口验证 OSS 请求无用户凭证、URL 不泄露、TXT/Markdown 内容、精确大整数 ID、过期与断连重签、次数上限、非法源和超限清理。
- Java 使用真实 MyBatis/H2 证明精简字段查询、归属/删除/解锁过滤；OSS 替身只允许签名，验证没有 GET/HEAD/PUT。
- 验证两节点版本一致、Key 到期限制 TTL、历史 URL 重签和路径编码、旧 HTTP 签名升级 HTTPS；MVC 验证 scope 隔离及禁止缓存。
- 实际 Node CLI 在两个 MVC 节点之间调用授权并从本地对象存储服务下载转写，检查最终文件内容。

测试使用合成数据及隔离本地服务，没有连接真实业务 OSS、修改个人 CLI 配置或部署后端。最终数量见 [VERIFICATION.md](VERIFICATION.md) 的本次条目。
