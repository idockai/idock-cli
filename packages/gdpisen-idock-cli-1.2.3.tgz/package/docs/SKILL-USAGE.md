# 用 AI 调用 iDock CLI

Skill 名称为 **`idock-cli`**，npm 包名为 **`@gdpisen/idock-cli`**，命令仍是 **`idock`**。Skill 提供命令选择、参数、分页、权限和任务恢复的指引；AI 通过自己的终端工具执行 CLI，使用当前用户的个人 AccessKey。只安装 Skill 不会安装 CLI，也不会获得额外权限。

2026-10-28 已同步游标分页、完整转写 TXT/Markdown 的临时 URL 下载与本地转换，以及每用户每秒一次限流。需要新版 CLI 和配套后端；更新 npm 包不会自动覆盖已经复制出去的 Skill，已有安装按下面步骤同步。

Trae 用户可直接使用相同 Skill，按 [Trae 安装与交付指南](TRAE-USAGE.md) 从 npm 包安装到项目 `.trae/skills`。2026-10-29 已确认 `@gdpisen/idock-cli@1.2.0` 公开可下载，并实际验证公开包内安装器可生成完整 Trae 项目技能目录。

`1.2.2` 的 Skill 新增检索时间参数、来源引用及无匹配处理，需要同时更新 CLI、Skill 与配套后端。搜索时间用 `--time today/7d/last-week` 或带偏移的 `--from/--to`，两者互斥；用 `metadata.recording_id/title/recorded_at` 定位并引用来源。低相关性或空片段应说明未找到相关内容，不按原始召回分数猜答案。

## Windows 本机 Codex

### 1. 安装 CLI 并登录

使用本次提供的 `.tgz`，将下面路径改成实际包路径。服务器地址由维护者配置在包内，无需用户输入。

```powershell
npm.cmd install -g .\gdpisen-idock-cli-1.2.2.tgz
idock --version
idock auth login
idock auth status
```

登录时在终端隐藏输入自己的 AccessKey，不把 Key 发到 AI 聊天。PowerShell 若拦截 `idock.ps1`，上述 `idock` 可改成 `idock.cmd`，不用修改执行策略。已经安装并登录的用户可跳过此步。

组织包发布后，也可执行 `npm.cmd install -g @gdpisen/idock-cli` 在线安装。

原先全局安装过无 scope 的 `idock-cli` 时，先执行 `npm.cmd uninstall -g idock-cli`，再安装组织包，释放原来的 `idock` 命令入口。个人登录配置仍位于 `~/.idock/`。

### 2. 安装 Skill

从本仓库运行：

```powershell
cd D:\code\code-server\server-main-tmp\idock-cli
npm.cmd run skill:install
```

或者使用**本次更新后的全局安装包**内置脚本，在任意目录执行：

```powershell
$idockPackage = Join-Path ((npm.cmd root -g).Trim()) '@gdpisen/idock-cli'
node (Join-Path $idockPackage 'scripts/install-skill.mjs')
```

默认只复制三个文件到当前用户的技能目录：

```text
C:\Users\<用户名>\.agents\skills\idock-cli\
├── SKILL.md
├── agents\openai.yaml
└── references\workflows.md
```

脚本不读取 CLI 配置或密钥、不连接后端、不改 Codex 配置。内容相同时可重复执行；目标已有不同内容时停止，需确认替换自己的定制后手动加 `--force`。只会覆盖上面三个文件，保留其它文件。

已有 Skill 要更新到当前发行内容时，先比较这三个文件是否有个人定制；使用发行版替换时，从最新包或源码运行：

```powershell
# 在最新 idock-cli 源码目录；只更新三个受管理的 Skill 文件
npm.cmd run skill:install -- --force

# 或使用最新全局安装包中的安装器
$idockPackage = Join-Path ((npm.cmd root -g).Trim()) '@gdpisen/idock-cli'
node (Join-Path $idockPackage 'scripts/install-skill.mjs') --force
```

独立 Skill 包是仓库 `idock-cli/idock-cli-skill.zip`，也可使用维护者提供的同名附件。解压后包含一个 `idock-cli` 目录，只有上述三个文件；把整个目录放入目标 AI 的技能父目录，更新时替换对应三个文件并保留自己的其它文件。ZIP 不包含 CLI、凭证或服务器配置，仍需单独安装最新 `.tgz` 并登录。

### 3. 在 Codex 对话中使用

在 Codex CLI 或 IDE 扩展输入 `$` 或 `/skills` 查找 **iDock 录音助手**，也可直接发下面的提示。自动识别未生效时显式指定 `$idock-cli`；新增技能未出现时重启 Codex。[官方 Skill 文档](https://developers.openai.com/codex/skills/)

```text
使用 $idock-cli，列出我最近一周的 5 条录音，按时间显示。

使用 $idock-cli，查找标题含“产品会议”的录音，把匹配的会议列出来供我选择。

使用 $idock-cli，从 RAG 知识库搜索“上次会议决定了哪些上线事项”，附上来源。

使用 $idock-cli，把刚才选中的会议纪要导出成 Word，保存到 D:\exports。

使用 $idock-cli，把指定会议的完整转写导出为 TXT，保存到 D:\exports，再按需读取本地文件总结，不逐段重复请求后端。

使用 $idock-cli，列出我今天的待办和随手记。

使用 $idock-cli，上传 D:\audio\会议.wav 并触发转写，实际时长 3600 秒；我同意该上传和转写操作，完成后给我纪要。
```

导入及任务查询需要 `recording:import`；默认 Key 只有六项读取、下载和导出权限，需要时由用户在 App/管理页授权。等待超时会继续使用原任务编号，不会重复上传。

所有 CLI API 按用户共用每秒一次额度，批量导出、导入或自检可能自动等待。CLI 已按服务端 `Retry-After` 最多额外重试两次；最终退出码 6 时 Skill 会停止额外循环并报告等待提示。完整转写的 TXT/Markdown 由 CLI 自动下载和转换，AI 不手工获取签名 URL；源 JSON 超过 16 MiB 时不生成文本，可根据用户目标改用 PDF/Word。权限不足不绕过，原有 `get` 仍是 4000 字符窗口且没有 `--full`。

## macOS / Linux

CLI 登录后，从源码目录或全局包安装 Skill：

```sh
# 在 idock-cli 源码目录
npm run skill:install

# 或使用已安装的新版本包
node "$(npm root -g)/@gdpisen/idock-cli/scripts/install-skill.mjs"
```

默认目标同样为 `~/.agents/skills/idock-cli`。CLI、Skill 和登录凭证必须在 AI 实际运行的系统及用户环境中可用；WSL、容器或远程环境不会自动继承 Windows 的全局 npm 包和登录。

## 项目共享、旧版本与其它 AI

当前 Codex 官方支持个人 `~/.agents/skills` 与项目 `.agents/skills`。项目共享时，从目标项目根目录运行以下命令，仅把 Skill 放进版本库；不要提交 `~/.idock/settings.json` 或 Key。[官方加载路径](https://developers.openai.com/codex/skills/)

```powershell
# --target 是父目录，脚本会自动创建 idock-cli 子目录
node 'D:\code\code-server\server-main-tmp\idock-cli\scripts\install-skill.mjs' --target .\.agents\skills
```

旧版宿主若明确使用 `~/.codex/skills`，可显式指定该父目录。不要同时安装到多个扫描路径，以免出现重名技能。

```powershell
node .\scripts\install-skill.mjs --target "$env:USERPROFILE\.codex\skills"
```

其它支持 `SKILL.md` 格式的 AI 可把同一个 `idock-cli` 目录放入该产品的技能目录，用 `--target` 指定父目录；具体扫描路径按对应产品说明。`agents/openai.yaml` 只是 Codex 界面元数据，其它宿主可以忽略。若没有 Skill 加载功能，可让支持终端执行的 AI 直接读取 `SKILL.md` 及其引用文件，再调用 `idock`。纯聊天、没有终端或本机访问能力的 AI 不能仅凭这份 Skill 执行本机命令。

## 常见问题

| 现象 | 处理 |
| --- | --- |
| AI 找不到 `idock` | 在 AI 实际运行的终端检查 `idock --version`；安装 CLI 并确保 PATH 生效 |
| 提示未登录或 Key 无效 | 在该用户/运行环境的终端执行 `idock auth login` |
| 缺少导入权限 | 由用户为 Key 授予 `recording:import`，重新登录后继续原操作 |
| RAG 不可用、无痕限制、纪要未生成 | 如实报告后端错误，Skill 不绕过业务规则 |
| 旧全局包没有安装脚本 | 安装本次新的 `.tgz`，或从本仓库运行脚本 |
| 已有定制 Skill，脚本拒绝覆盖 | 先比较差异；要用发行版替换时再加 `--force` |

开发验证：`npm test` 验证 CLI 和安装器；Skill 本身可用 `skill-creator` 的 `quick_validate.py` 校验 frontmatter。完整 CLI 使用说明见 [README](../README.md)，逐条本地实测记录在仓库 `idock-cli/命令分类与逐条执行结果.md`。
