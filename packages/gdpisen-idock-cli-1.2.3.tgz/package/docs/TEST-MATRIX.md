# CLI 逐命令验收矩阵

2026-10-28 当前版本已重新完整验收：Node 133 项、Java 184 项（15 类）全部通过；除 23 个正式命令外，兼容入口、help、browse/repl 均保存了本轮执行结果，见 [33 个命令逐条索引](../command-results/2026-10-28-refresh/README.md) 与 [完整返回原文](../command-results/2026-10-28-refresh/commands.md)。新一轮覆盖游标、转写临时 URL 下载、按用户跨节点限流和有限重试；历史真实环境输出独立保留。

验证日期：2026-10-27。依据 [PRD V1.3](PRD.md)、[README](../README.md) 和实际 schema 的 23 个正式命令进行验收。

## 测试层次与边界

- Node 验收通过实际 CLI 子进程执行，不只调用内部方法；检查完整 stdout、退出码、实际 HTTP 方法/参数、上传字节与落盘文件。
- Java 使用测试专用 Redis、H2/MyBatis 和真实 MVC 鉴权链；`IdockAccessKeyFlowTest.realCliCompletesEveryDocumentedCommandAcrossNodes` 从真实 Node 入口执行全部 23 个正式命令，业务 HTTP 请求交替经过两个 MVC 实例。身份与撤销使用共享的真实数据库、事务和 Redis，业务服务使用替身；导入幂等和文档生成另有服务测试。
- 文档生成使用真实导出服务：转写/纪要 × TXT/Markdown/PDF/Word 共八组；PDF 经 PdfReader/PdfTextExtractor 重新读取，Word 经 XWPFDocument 重新读取，断言中文、正文、说话人/时间或待办。只替换数据库和 OSS 读取，不用文本冒充 PDF/docx 验证生成。
- Windows 原生 TTY 实际运行隐藏输入、`browse`、`repl`；使用本地 HTTP 和临时配置/文件目录。
- 本地替身不验证真实 RAG 数据集的检索质量、真实 OSS 签名/网关配置、听悟解码与计费。没有调用真实短信、业务 Redis/RAG/OSS 或付费转写。

## 23 个正式命令

全部命令均有子进程成功路径、终端帮助和显式 JSON 帮助校验；业务结果检查公共 JSON 信封。以下列出额外场景；同类公共校验由共享测试覆盖，不代表穷举所有参数排列。

| 命令 | 主要验收场景 | 后端验证 |
| --- | --- | --- |
| `auth login` | 标准输入、环境变量、有效身份保存、远端无效身份拒绝、过期 Key 不覆盖旧配置、空/超长输入、禁止命令行 Key、TTY 隐藏输入 | 数据库签发/手工配置、固定有效期、Redis 仅摘要、跨节点识别、App 管理态隔离 |
| `auth status` | 远端确认、无本地 Key、到期/scopes/末四位、输出不含 Key | TTL/过期/撤销与共享存储故障拒绝 |
| `auth logout` | 清除当前 profile、保留其它 profile、说明环境变量仍生效 | 本地操作不发送远端撤销 |
| `auth revoke` | 无 `--yes` 只输出计划、确认后 DELETE、清除配置、失败保留 Key | 跨节点立即失效、旧 Key 并发撤销不误删新 Key |
| `schema` | 未登录/无参数可读取、23 命令与独立执行矩阵严格相等、默认值与 RAG 声明 | 本地操作，不产生业务请求 |
| `config set` | profile/endpoint/timezone、参数优先级、非法配置不覆盖、损坏 JSON 不重建、同地址保留 Key、换地址清除 Key | 本地操作，拒绝写入秘密字段 |
| `doctor` | 健康返回、无凭证拒绝、数字版本比较与升级提示 | profile 契约、认证故障、旧版本请求拒绝 |
| `recording list` | 三种来源、关键词、时间/时区、limit、游标、空结果、大整数 ID、失效游标只重查一次 | H2 分页前归属/删除/手机本地可见性/来源过滤，半开时间区间、DST、游标绑定 |
| `recording get` | 五种 section、精确 ID、offset/length、text 正文、参数边界、404/401/403/429/503 | 转写/章节/笔记/最新有效纪要，all 混合锁定状态、空板块、归属/删除隔离、Unicode 续读、OSS 失败 |
| `recording download` | 原音/MP3、实际字节、中文/空格目录、去重、批量部分失败、同名保留/覆盖、重授权次数、OSS 错误页、凭证隔离 | 原音归属/状态、手机本地、音频删除/隐藏、无痕、权限、跨节点授权并落盘 |
| `recording export` | 两种正文 × 五种格式写法（含 md/markdown）、转写 TXT/Markdown 临时 URL 直传与本地转换、时间/说话人/Unicode、过期/断连有限重签、字节上限和临时清理、OSS 不收凭证、扩展名/中文文件名、JSON/text、批量部分失败、伪文件拒绝 | 八组真实文档生成与重新解析、独立导出 scope、内容锁定、归属/删除、只签名不读正文、Key 到期截断 TTL、HTTPS 与历史签名路径、跨节点导出落盘 |
| `recording import` | 计划/确认、四种容器 MIME/大写后缀、关闭格式在 HTTP 请求前拒绝、流式 SHA-256 与默认/自定幂等键、实际上传字节、准备中/已存在对象恢复、PUT/确认失败、断连/重定向、恢复标识、文件/时长/大小边界、OSS 身份隔离 | Redis 多节点幂等/并发、原文件名固定、原任务恢复、CLI 独立来源与旧 phone 任务兼容、额度/转写回归、App 不能冒充 CLI |
| `job get` | preparing/uploading/processing/completed/failed、任务与录音定位、持久化来源、严格 UUID、404/认证/权限/限流/故障 | 用户归属、共享 Redis 查询、数据库完成/失败状态、跨节点 HTTP 查询 |
| `job wait` | processing→completed、failed、超时、timeout/interval 边界；只 GET 原任务，不重传 | 导入 scope、跨节点已有任务查询，不创建新转写 |
| `search` | RAG 专用路由、分数/锚点、空结果、字符窗口、最多十条、text 隐藏内部字段、认证/权限/限流/故障 | HTTP 用户过滤、二次归属过滤、元信息白名单、Unicode 裁剪、上游失败拒绝、无数据库兜底 |
| `flash note list` | 类型、时间、游标、最多十条、空结果、失败响应 | H2 用户/类型/删除/时间过滤、200 字符预览、游标绑定 |
| `flash note get` | 正文、offset/length、text、失败响应 | 随手记真实字段、Unicode 续读、超尾空窗口、跨用户/类型/删除拒绝 |
| `flash todo list` | 类型、时间、游标重置、最多十条、失败响应 | H2 分页与类型过滤，待办预览 |
| `flash todo get` | 正文、offset/length、text、失败响应 | 待完成/已完成状态、待办时间、Unicode 续读 |
| `flash bill list` | 类型、显式时间、最多十条、失败响应 | H2 分页与类型过滤，账目预览 |
| `flash bill get` | 正文、offset/length、text、失败响应 | 收入/支出、金额精度、标题、场景、记账时间 |
| `flash idea list` | 类型、显式时间、最多十条、失败响应 | H2 分页与类型过滤，灵感预览 |
| `flash idea get` | 正文、offset/length、text、失败响应 | 灵感真实字段、Unicode 续读，与旧别名内容一致 |

七种 scope 对全部远端业务路由逐项进行反向权限检查：只授予其它 scope 时必须在调用业务服务前返回 403。导入默认未授权，任务查询/确认也不能绕过导入 scope。请求中的 `userId` 不得覆盖 Key 身份。

2026-10-28 新增数据库授权回归：手工配置两个字段、Redis 毫秒 TTL 与数据库绝对到期时间一致、缩短/延长有效期且请求不续期、缓存清空/损坏后的权限恢复、手工换 Key 不继承导入权限、字段为空/格式无效/用户不匹配/注销拒绝、权限修改及损坏、普通实体查询/更新/三种 JSON 输出隔离、写入失败事务回滚、数据库故障拒绝、主库路由先于事务且上下文恢复、撤销清空并重新签发、无效用户禁止签发。并发首次签发由两个独立节点共享真实数据库行锁验证。

## 兼容与终端入口

| 入口 | 结果与检查 |
| --- | --- |
| `recordings list/show/download/export` | 游标/关键词/分组/手机关联、旧页码仅首页兼容、show 数字 ID、旧导出 `--format`、大整数 ID、下载/导出字节、错误与批量行为；交互游标首尾、上一页、筛选重置、失败保持状态与循环游标拒绝 |
| `whoami` | 真实子进程读取 Key 身份，未配置凭证拒绝 |
| `flash flash list/get` | 灵感别名可调用，Java 验证与 idea 相同业务内容 |
| `browse`、`repl` | 脚本非 TTY 不阻塞；会话内命令保留 profile/endpoint/timezone；真实 Windows TTY 验证 help、list、find、next/prev、select、download、export、RAG search、recording get、exit；各执行 9 个本地 HTTP 请求 |
| `--version`、`--help`、无参数 | 版本和无参数返回 JSON；help 默认终端排版，显式 JSON 帮助保持一份信封；全部 23 个正式命令分别检查文本和 JSON 帮助 |
| `help [path...]` | 根/多层路径与直接 --help 一致；中文说明、必填参数、示例及继承参数；无认证、损坏配置和断网地址仍可使用；管道/JSON 无 ANSI，交互可着色；旧命令与未知路径 |
| 未知命令/参数、缺必填项 | 返回参数错误和退出码 2，禁止误返回成功 schema |
| 发布包默认服务器地址 | `test/release.test.js` 实际验证免地址登录、仅隐藏输入 Key、网关前缀/工作目录、覆盖优先级、凭证绑定、错误配置拒绝、npm pack 校验及真实 tarball 解压登录 |

text 输出移除独立的内部 ID/锚点字段；下载/导出仍返回真实路径，路径中的文件名可能含会议编号，不能改写路径使文件不可定位。

## 复现

```powershell
cd idock-cli
npm.cmd test

# 必须在交互终端分别执行；脚本列出操作序列，退出时检查实际请求与文件并清理临时目录。
node scripts/terminal-smoke.mjs login
node scripts/terminal-smoke.mjs browse
node scripts/terminal-smoke.mjs repl
```

Java 的完整命令和实际通过数量见 [VERIFICATION.md](VERIFICATION.md)。Node 测试也支持 `IDOCK_TEST_ENTRY` 指向临时安装包的 `src/index.js`，从安装后的入口重跑同一套子进程验收。

CLI 用户限流专项：`IdockAccessKeyFlowTest` 使用真实隔离 Redis 验证同用户跨节点/跨接口/重置 Key 共用一秒额度，不同用户独立，16 个并发请求只有一次放行，TTL 到期恢复且拒绝不续期；Redis 故障不执行业务。完整 23 命令的 Node→HTTP→双 MVC 闭环启用真实限流，验证等待后重试、导入只执行一次和文件落盘。`test/api-rate-limit.test.js` 覆盖有界等待、持续超限退出码/秒数、POST 参数及身份保持、文件流和非限流错误不重放。

## 尚未验证的环境与规模

- 真实网关、真实测试账号的 RAG/OSS/听悟全链路，以及真实语音解码、付费扣减、最终转写质量。
- 2GB/4 小时上限有参数校验测试；使用稀疏文件验证客户端拒绝超过 2GB，服务端检查声明值的精确上下界。没有传输 2GB 或执行 4 小时音频的压力/耗时测试。
- 上游 RAG 的 top_k、真实数据集命中与用户隔离配置仍需部署联调；本地测试验证协议和服务端过滤逻辑。
- 未在 macOS、Linux、WSL 各运行一遍；本轮实际平台为 Windows、Node 22、JDK 21。
- 当前上传恢复是重试原任务并必要时整文件 PUT，不是 multipart 或字节断点续传。本轮没有把测试通过解释为新增了这些能力。

## 本轮发现并修复

1. 未知顶层命令误返回成功 schema：现在拒绝多余参数并返回退出码 2。
2. job_id 只检查长度和字符集合：现在要求 UUID 的完整分组格式，在发请求前拒绝非法编号。
3. REPL 内执行命令丢失启动连接设置：现在保留 profile/endpoint/timezone，并由自动化回归与真实 TTY 流程验证。
