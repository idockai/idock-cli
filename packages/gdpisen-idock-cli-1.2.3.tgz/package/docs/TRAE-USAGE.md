# 在 Trae 中使用 iDock

本文面向接收方用户，可以单独分享。CLI npm 包为 `@gdpisen/idock-cli`，终端命令和 Skill 名称分别为 `idock`、`idock-cli`。现有 Skill 可由 Trae 的终端工具调用 CLI，服务端仍按用户个人 AccessKey 授权。

2026-10-29 已从官方 npm 仓库确认 `1.2.0` 已公开发布，并在隔离临时目录实际下载、安装 CLI 和项目 Skill。此验证覆盖分发与目录结构；尚未在 Trae 界面中验证技能发现、模型调用或正式用户的业务链路。

升级至 `1.2.2` 后重新运行 Skill 安装器，更新检索时间、来源引用和无匹配规则。可执行 `idock search "会议行动项" --time last-week --limit 5`；问题中的时间词不替代筛选参数。JSON 来源的 `recording_id` 可继续读取录音，text 显示标题和录制时间，无匹配时明确提示；这些检索能力需要配套新版后端。

希望由 AI 代为安装时，把 [给 AI 的安装提示词](../README.zh-CN.md#直接交给-ai-的安装提示词) 发给具有终端能力的 Trae Agent 即可。提示词已包含 CLI 和 Skill 的独立安装、已有文件保护、AccessKey 隐藏输入以及非交互终端的处理方式。当前 `auth login` 不会弹出浏览器授权；仍需用户取得个人 Key，并在自己的终端输入。

维护者对外发布时，可将完整提示词直接放到帮助页或发给用户。安装包中的 `README.md`、`README.zh-CN.md` 与 GitHub 对外说明应同步更新；具体步骤见 [发布流程](RELEASING.md)，实际发布状态以官方 npm 版本和 GitHub 更新记录为准。

## 接收方用户的操作

### 1. 在 Trae 实际执行命令的环境安装并登录

准备 Node.js 22 或以上版本，在 Trae 内置终端执行：

```powershell
node --version
npm.cmd install -g @gdpisen/idock-cli
idock --version
idock auth login
idock auth status
```

`auth login` 会隐藏输入个人 AccessKey。Key 从 iDock 提供的领取入口或管理员处取得，在用户自己的终端输入；不要把 Key 发到 AI 对话中。安装包内置服务器地址。

Windows PowerShell 如果拦截 `.ps1`，上述命令使用 `idock.cmd`。原先全局安装过无 scope 的 `idock-cli` 时，先执行 `npm.cmd uninstall -g idock-cli` 释放旧的同名命令，再安装组织包。

如果 Trae 刚启动时还没有安装 Node/CLI，可关闭并重新打开 Trae，让它继承新的 PATH；用其内置终端中的 `idock --version` 确认。远程开发、WSL、容器或云端任务需要在实际执行命令的环境安装 CLI 并登录，登录状态随该环境的用户配置保存。

### 2. 安装项目 Skill

先在 Trae 中打开接收方自己的项目或工作目录，再在该目录的终端执行：

```powershell
$idockPackage = Join-Path ((npm.cmd root -g).Trim()) '@gdpisen/idock-cli'
node (Join-Path $idockPackage 'scripts/install-skill.mjs') --target .\.trae\skills
```

生成的结构：

```text
你的项目/
└── .trae/
    └── skills/
        └── idock-cli/
            ├── SKILL.md
            ├── agents/
            │   └── openai.yaml
            └── references/
                └── workflows.md
```

`--target` 指向技能父目录，安装器会创建 `idock-cli` 子目录。此安装器已随公开的 `1.2.0` 包提供，接收方不需要克隆 iDock 服务端仓库。

macOS/Linux 在项目终端执行：

```sh
npm install -g @gdpisen/idock-cli
idock auth login
node "$(npm root -g)/@gdpisen/idock-cli/scripts/install-skill.mjs" --target ./.trae/skills
```

安装器默认保护已有不同内容；更新时先比较是否有个人定制，确定替换这三个发行文件后，在原安装命令末尾加 `--force`。后续升级 CLI 后，需要再次运行 Skill 安装器同步副本。

### 3. 在 Trae 中确认发现并使用

在 Trae 的“设置 → 技能与命令”中确认项目技能 `idock-cli` 已被识别且启用，使用具备终端执行能力的 Agent。未出现时检查当前打开的项目和目录层级，再重新加载窗口。项目技能的目录与手动调用方式见 [Trae 官方技能文档](https://docs.trae.com.cn/ide/skills)。

给 Trae 的第一条消息可以是：

```text
使用 idock-cli 技能，先检查 CLI 版本、命令契约和我的登录状态。
然后列出我最近一周的 5 条录音，展示标题和时间，不执行上传或撤销操作。
```

再按需要提问：

```text
使用 idock-cli 技能，把我选中的这条录音纪要导出成 Word，保存到 ./exports。

使用 idock-cli 技能，从我的 RAG 知识库搜索“上次产品会议确定了哪些行动项”，附上来源。
```

已登录用户查询自己有权访问的数据。搜索需要 `rag:search`，导出纪要需要 `summary:export`；导入音频需要单独授予 `recording:import`，并明确授权上传及触发转写。

### 可选：使用全局技能或 ZIP

中文客户端的全局技能目录为 `%USERPROFILE%\.trae-cn\skills`，可以把安装命令中的 `--target` 改为该目录：

```powershell
node (Join-Path $idockPackage 'scripts/install-skill.mjs') --target (Join-Path $env:USERPROFILE '.trae-cn\skills')
```

其他版本的全局目录以客户端设置为准。项目安装路径 `.trae/skills` 便于明确技能的生效范围。

也可取得维护者提供的 `idock-cli-skill.zip`，解压后把整个 `idock-cli` 文件夹放到项目 `.trae/skills/` 下。保留 `references/workflows.md`，Skill 正文会按需读取它。`agents/openai.yaml` 是 Codex 界面元数据，Trae 的调用指引由 `SKILL.md` 提供。

Trae 设置也支持导入包含 `SKILL.md` 的 ZIP，但不同产品的导入布局要求可能不同。直接使用上面的安装器或解压复制完整目录，可以明确保留引用资源。

## 维护者交付前还需确认

| 项目 | 当前证据 / 后续操作 |
| --- | --- |
| npm 公开分发 | 已确认 `@gdpisen/idock-cli@1.2.0` 可从官方仓库下载；包内含完整 Skill 和安装器 |
| Skill 目录安装 | 已从公开包安装到临时 `.trae/skills/idock-cli`，校验三个文件、重复安装、frontmatter 和 CLI version/schema 均通过 |
| Key 领取入口 | 仓库已有 AccessKey 管理接口和管理页；需确认实际面向用户的 App/网页领取入口已上线，并说明有效期、重置、撤销和申请导入权限的流程 |
| 配套后端部署 | 需确认正式环境全部节点均部署匹配版本、数据库授权字段已落地、共享 Redis 正常，网关保留 `Retry-After`；本次没有验证正式部署 |
| 正式服务地址 | 当前公开包内默认地址为 `http://47.111.189.244:7001/user`；面向外部用户建议配置 HTTPS 网关，以保护请求中的个人 Key，更新随包地址时发布新版本 |
| 真实用户闭环 | 待在另一台机器和一个普通用户账号上完成 Trae 发现 Skill → 登录 → 列表 → RAG → 纪要导出；如开放导入，再单独验收上传和任务完成 |
| 对外说明 | 可以分享本文和现有 ZIP；若需要统一下载入口，可再发布到你们的帮助站或代码仓库，本文尚未上传到外部站点 |
| 平台市场 | 项目目录安装可直接使用；如希望用户从 Trae 市场搜索安装，另行完成市场提交和审核，npm 发布不会自动完成该步骤 |

对外提供的材料可以包含 npm 安装命令、本文和可选的 Skill ZIP。每个接收方使用自己的 AccessKey，个人登录配置与 Key 不放进 Skill 包。

## 本次验证范围

公开 npm 下载安装、真实安装器写入 Trae 项目目录、三个文件逐字节核对、重复安装无变化、Skill 格式校验以及 CLI version/schema 均已执行。证据见仓库 `idock-cli/command-results/2026-10-29-trae-distribution/verification.json`。本次没有执行真实用户查询、部署后端、修改全局 CLI 或启动 Trae 界面。
