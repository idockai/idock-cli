# CLI 用户请求限流

## 规则

所有使用 `@IdockAccess` 的接口，在个人 AccessKey 和用户身份验证成功后，按用户 ID 统一申请额度：同一用户相邻两次放行至少间隔 1000 毫秒。包含身份查询、录音列表/详情/签名/导出、RAG、闪记、导入及任务状态查询，旧版复数命令与新版命令共用额度。

一个命令可能发起多次 API 请求，例如导入包含申请上传、完成确认、任务查询；限制的是 API 次数。通过了限流但后续参数、scope 或业务校验失败，也消耗本次额度。非法 Key、身份不匹配的请求仍先返回原认证错误，不能利用伪造的用户 ID 占用其他用户额度。

按用户而非 IP、URL、进程或 Key 计数。不同用户分别限流，同一用户切换终端、接口、节点或重置 Key 均不能增加额度。CLI 来源由专属鉴权接口确定，不依赖可修改的 User-Agent。

App Token 管理 Key 的接口、普通 App 接口，以及 CLI 直接向 OSS 上传/下载文件不使用此额度。文件传输过程中不会每秒扣一次额度。

## 服务端实现

`IdockCliRateLimiter` 复用 `idockAccessKeyRedisTemplate`，原子执行相当于 `SET idock:cli:rate-limit:user:<userId> 1 NX PX 1000` 的操作。占位和值的过期时间在同一个 Redis 命令设置；拒绝请求不会续期。不按自然秒分桶，不会在秒边界额外放行。

超限在业务执行及用户分库路由前返回：

```http
HTTP/1.1 429 Too Many Requests
Retry-After: 1
Cache-Control: no-store
Content-Type: application/json;charset=UTF-8
```

业务错误码为 `IDOCK_RATE_LIMITED`。Redis 异常或不能确定占位结果时，返回 HTTP 503 / `IDOCK_RATE_LIMIT_UNAVAILABLE`，不使用本机缓存兜底，也不执行业务操作。

## CLI 行为

CLI 仅对同时具有 HTTP 429、`IDOCK_RATE_LIMITED` 和 `Retry-After` 为 1–5 的整数秒数的响应自动等待；最多额外请求两次。当前服务端固定返回 1 秒。只重放在业务执行前拒绝的请求，沿用同一份连接、方法、参数及请求体，上传幂等键不变。403、401、网络异常、503 和没有该响应头的上游 RAG 限流不在本次机制中自动重试。

持续竞争时仍可能最终限流，返回退出码 6、`retryable: true`、等待提示和 `error.details.retry_after_seconds`。下载命令原有的 `--retries` 仍控制 OSS 失败/签名重取次数，与 API 用户限流等待相互独立。

## 部署

后端全部节点更新后生效，所有节点必须连接同一环境的共享 Redis。限流键自动过期，不需要数据库迁移、手工初始化或定时清理。CLI 重新安装最新打包文件后支持自动等待；旧 CLI 同样受服务端限制，可能直接显示 429。

网关需要透传 `X-Access-Key` 和服务端的 `Retry-After`，保留真实 HTTP 状态。无需用户配置限流参数。

测试使用本机随机端口 Redis、两套 MVC 请求链和真实 Node 子进程，覆盖并发、跨接口、跨节点、不同用户、Key 重置、TTL 到期/拒绝不续期、Redis 故障，以及全部正式命令在限流下完成。具体通过数量见 [VERIFICATION.md](VERIFICATION.md)。
