# iDock Agent CLI

使用个人 AccessKey 查询 iDock 录音、转写、纪要和闪记，搜索 RAG 知识库，下载音频、导出文档，以及导入音频并跟踪转写任务。npm 包为 `@gdpisen/idock-cli`，命令为 `idock`，Agent Skill 名称为 `idock-cli`。

`1.2.3` 更新正式服务地址，并继续支持搜索时间筛选、录音来源展示、无匹配提示及统一参数错误码。搜索 JSON 中可使用 `documents[].metadata.recording_id` 继续读取、下载和导出；标题与录制时间用于引用来源。录音编号保持字符串，不能使用听悟 `taskId`、导入任务 `job_id` 或纪要、向量文档编号替代。对外发布包和安装说明见 [GitHub 仓库](https://github.com/idockai/idock-cli)。

```sh
idock search "会议行动项" --time last-week --limit 5
idock --format text search "采购流程" --time 7d
```

时间范围支持 `today/7d/last-week`，自定义范围用带时区偏移的 `--from/--to`，与 `--time` 互斥；问题中的“上周”不会自动过滤时间。`low_confidence=true` 或空片段表示没有可引用结果，text 模式提示“未找到相关内容。”。升级 CLI 后也应按下文更新已安装的 Skill。

## 直接交给 AI 的安装提示词

把下面整段发给具有终端执行能力的 Trae、Codex 或其它 Agent。安装应在 Agent 实际执行命令的环境完成；远程开发时，本机安装不会自动配置远程环境。

```text
请帮我安装 iDock CLI，并配置当前 AI 使用的 idock-cli Skill。
GitHub 发布包：https://github.com/idockai/idock-cli
备用 npm 包：https://www.npmjs.com/package/@gdpisen/idock-cli

1. 检查 Node.js 版本，需要 22 或以上；先从 GitHub 下载固定发布包并安装：
   Windows PowerShell：
   $packageUrl = 'https://github.com/idockai/idock-cli/raw/refs/heads/main/packages/gdpisen-idock-cli-1.2.3.tgz'
   Invoke-WebRequest -Uri $packageUrl -OutFile .\gdpisen-idock-cli-1.2.3.tgz
   npm.cmd install -g .\gdpisen-idock-cli-1.2.3.tgz --ignore-scripts
   GitHub 下载失败时，再使用备用 npm 包：
   npm install -g @gdpisen/idock-cli@latest --registry=https://registry.npmjs.org/
   idock config set endpoint https://app.pisenidock.com/user
   当前 npm 为 1.2.2，1.2.3 尚未发布；更换服务地址后需要重新登录。
   macOS/Linux 使用 curl -fL 下载上述 URL 到同名文件，再用 npm install -g ./gdpisen-idock-cli-1.2.3.tgz --ignore-scripts 安装。
   Windows PowerShell 如拦截 .ps1，使用 npm.cmd 和 idock.cmd。
2. 用 npm root -g 定位全局包目录，读取其中
   @gdpisen/idock-cli/README.md 和 SKILL.md 的安装及调用说明。
3. 使用包内 scripts/install-skill.mjs 配置 Skill：
   Trae 安装到当前项目 .trae/skills，使用 --target 指定该父目录；
   Codex 使用安装器默认的 ~/.agents/skills。
   其它 Agent 按其实际支持的目录安装，不假定所有 Agent 共用同一路径。
   保留 SKILL.md、agents/openai.yaml 和 references/workflows.md；
   如遇已有定制内容，先比较，不直接强制覆盖。
4. 检查 idock --version、idock schema 和 idock auth status。
   已有效登录时复用登录状态；否则引导我在自己的交互终端执行
   idock auth login，隐藏输入我自己的 AccessKey。
   不要让我把 Key 发到聊天中，不读取或展示凭证配置文件。
   当前登录不提供浏览器或二维码授权；如果你的工具没有交互终端，
   先完成 CLI 和 Skill 安装，再告诉我手动登录命令，等我登录后继续验证。
5. 登录后验证 idock auth status 和 idock doctor；报告实际版本、Skill
   安装位置和验证结果。尚未完成用户登录或 Agent 技能发现时明确说明。
   本次只做安装与验证，不上传音频、重置或撤销 Key。
```

当前采用 AccessKey 登录。用户需要先通过 iDock 提供的领取入口或管理员取得自己的 Key；安装 Skill 不会创建账号、发放 Key 或扩大权限。上述提示词可使用已发布的 `1.2.0` 包，安装器已包含在包内。若宿主未立即发现新增 Skill，重新加载窗口后再检查；文件安装成功与宿主实际加载成功需要分别确认。

## 手动安装与登录

需要 Node.js 22+。优先从 GitHub 下载固定发布包：

```powershell
$packageUrl = 'https://github.com/idockai/idock-cli/raw/refs/heads/main/packages/gdpisen-idock-cli-1.2.3.tgz'
Invoke-WebRequest -Uri $packageUrl -OutFile .\gdpisen-idock-cli-1.2.3.tgz
npm.cmd install -g .\gdpisen-idock-cli-1.2.3.tgz --ignore-scripts
idock.cmd --version
```

GitHub 下载失败时，再使用 npm 备用包。当前 npm 为 1.2.2，1.2.3 尚未发布；备用安装后设置正式服务地址，更换地址后需要重新登录：

```sh
npm install -g @gdpisen/idock-cli@latest --registry=https://registry.npmjs.org/
idock config set endpoint https://app.pisenidock.com/user
idock --version
idock auth login
idock auth status
idock doctor
```

服务器地址由发布者配置在包内，用户不需要输入。AccessKey 在自己的终端隐藏输入，不放入命令参数或 AI 聊天。

Windows PowerShell 在 Trae 打开的项目目录安装 Skill：

```powershell
$idockPackage = Join-Path ((npm.cmd root -g).Trim()) '@gdpisen/idock-cli'
node (Join-Path $idockPackage 'scripts/install-skill.mjs') --target .\.trae\skills
```

Codex 使用同一安装器，省略 `--target`，默认生成 `~/.agents/skills/idock-cli`。macOS/Linux 的 Trae 项目安装命令：

```sh
node "$(npm root -g)/@gdpisen/idock-cli/scripts/install-skill.mjs" --target ./.trae/skills
```

安装、登录和 Skill 加载完成后，可以对 AI 说：

```text
使用 idock-cli 技能，列出我最近一周的 5 条录音，展示标题和时间。
```

完整命令、配置与服务端接入见包内 [README.md](README.md)，宿主安装步骤见 [Skill 使用指南](docs/SKILL-USAGE.md) 和 [Trae 使用指南](docs/TRAE-USAGE.md)。
