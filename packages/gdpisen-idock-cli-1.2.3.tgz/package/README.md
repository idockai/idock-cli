# iDock Agent CLI

基于 [yuque/yuque-cli](https://github.com/yuque/yuque-cli) 改造的 Node CLI，命令名 `idock`。通过个人 AccessKey 读取录音、转写、纪要和闪记，检索用户 RAG 向量库，下载/导出文件，以及导入音频并查询转写任务。上游信息见 [UPSTREAM.md](UPSTREAM.md)。

版本 **1.2.3**，更新正式服务地址。该检索契约需要配套新版后端；实际发布包和安装说明见 [GitHub 仓库](https://github.com/idockai/idock-cli)。不增加会员与 30 天限制。完整范围和待定细节见 [docs/PRD.md](docs/PRD.md)，Agent 调用规范见 [SKILL.md](SKILL.md)。

## 让 Codex 或其它 AI 使用

希望用户直接把一句安装指令交给 AI 时，复制 [给 AI 的完整安装提示词](README.zh-CN.md#直接交给-ai-的安装提示词)。该提示词优先从 GitHub 下载固定发布包，下载失败时再使用公开 npm 包，依次完成 CLI 安装、宿主 Skill 配置和 AccessKey 登录验证；当前没有浏览器或二维码授权流程。用户不需要访问服务端源码仓库。

安装 CLI 并完成 `idock auth login` 后，在本目录运行 `npm run skill:install`，将 `idock-cli` Skill 安装到个人 `~/.agents/skills`。然后在 Codex 中说：`使用 $idock-cli，列出我最近一周的录音并导出指定会议的纪要`。Skill 随 npm 包携带，支持独立复制到其它 AI 的技能目录；完整安装、项目共享与示例见 [Skill 使用指南](docs/SKILL-USAGE.md)。

Trae 使用同一份 Skill，公开 npm 包已携带安装器，可安装到使用者项目的 `.trae/skills`；完整接收方操作及维护者交付项见 [Trae 使用指南](docs/TRAE-USAGE.md)。

当前 Skill 已同步检索时间参数、来源引用和无匹配处理，并保留游标分页、完整转写优先一次导出及每用户每秒一次限流规则。升级 GitHub 或 npm 包后，已复制出去的 Skill 需重新运行安装器更新；仓库中的 `skill/idock-cli/` 与发布包内 Skill 使用同一份源文件。

## 安装与登录

需要 Node.js 22+，CLI 独立于 Maven modules。优先从 GitHub 下载固定发布包：

```powershell
$packageUrl = 'https://github.com/idockai/idock-cli/raw/refs/heads/main/packages/gdpisen-idock-cli-1.2.3.tgz'
Invoke-WebRequest -Uri $packageUrl -OutFile .\gdpisen-idock-cli-1.2.3.tgz
npm.cmd install -g .\gdpisen-idock-cli-1.2.3.tgz --ignore-scripts
idock.cmd --version
```

GitHub 下载失败时，再使用 npm 公开包：

```powershell
npm.cmd install -g @gdpisen/idock-cli@1.2.3 --registry=https://registry.npmjs.org/
idock.cmd --version
```

开发者从源码运行时：

```powershell
cd D:\code\code-server\server-main-tmp\idock-cli
npm.cmd ci
npm.cmd link
idock --version
```

也可运行 `node .\src\index.js schema`。npm 包名为 `@gdpisen/idock-cli`，安装后的命令为 `idock`，Windows、macOS 和 Linux 均可直接使用。只有 Windows PowerShell 执行策略拦截 `.ps1` 时，才使用 `npm.cmd`、`idock.cmd` 备用入口，无需修改系统执行策略。发布包由维护者预先配置服务器地址，用户无需输入网关。GitHub 包和 npm 包使用同一份固定构建内容。

用户操作步骤：

1. 在 iDock App 领取个人 AccessKey；App 可接入下文管理接口。另有同源管理页 `https://服务域名/网关前缀/idock/index.html`，通过已有手机号和短信验证码登录、生成/重置/撤销 Key。
2. 选择需要的权限。默认六项读取/下载/导出权限；**导入并转写需单独勾选 `recording:import`**。默认有效期 90 天，每个用户一把有效 Key，重置后旧 Key 在各节点立即失效。
3. 执行登录，按终端提示隐藏输入 Key；CLI 远端验证成功后才保存：

```powershell
idock auth login
idock auth status
idock doctor
idock schema
```

无需输入服务器地址、用户 ID 或 App Token。服务根地址由发布者随安装包配置，支持网关前缀，不追加 `/idock`、`/tingwu` 或 `/api/v2`。

个人配置保存在 `%USERPROFILE%\.idock\settings.json`，各 profile 隔离。自动化可由密钥管理工具注入 `IDOCK_ACCESS_KEY`，可选 `IDOCK_PROFILE`、`IDOCK_TIMEZONE`、`IDOCK_CONFIG_DIR`；也支持标准输入配合 `auth login --key-stdin`，不接受把 Key 放入命令行参数。管理页只在内存保留 App Token 和本次生成的 Key。

```powershell
idock config set timezone Asia/Shanghai
idock config set profile cn_test
```

测试和私有部署可通过 `--endpoint`、`IDOCK_ENDPOINT` 或 `config set endpoint` 显式覆盖地址；普通用户无需设置。地址优先级为命令行、环境变量、profile 配置、包内发布配置。切换服务地址清除该 profile 旧 Key，需要重新登录。登录成功时保存已验证的地址，升级包默认地址不会把旧 Key 自动发送给新服务。`config set` 不允许写入凭证。

## 查询、读取与 RAG 搜索

`idock --help` 默认展示分区终端帮助，包含功能命令、工具命令、全局参数和上手示例。子命令沿用同一排版；交互终端支持颜色，重定向和 `NO_COLOR` 输出纯文本。查看帮助无需登录或连接服务器。

```powershell
idock --help
idock recording --help
idock help recording import
idock flash todo get --help
idock --format json recording list --help
```

供 Agent 读取的命令契约使用 `idock schema`；需要 JSON 帮助时显式加 `--format json` 或 `--json`。业务命令仍默认输出 JSON。

```powershell
idock recording list --time 7d --limit 5
idock recording list --time last-week --source offline --keyword "产品会议"
idock recording list --from 2026-10-01T00:00:00+08:00 --to 2026-11-01T00:00:00+08:00
idock recording list --cursor <上一页返回的next_cursor>
idock recording get <列表返回的id> --section summary
idock recording get <id> --section transcription --offset 4000 --length 4000
idock search "上次会议确定了哪些行动项" --limit 5
idock search "会议行动项" --time last-week --limit 5
idock --timezone Asia/Shanghai search "采购流程" --from 2026-10-01T00:00:00+08:00 --to 2026-11-01T00:00:00+08:00
idock flash note list --time today
idock flash todo list --time 7d
idock flash bill list --limit 5
idock flash idea get <同类型列表返回的id>
```

录音来源为 `online/offline/merged`，每次最多十条；所有条件先过滤再分页。时区来自用户档案，可用 `--timezone` 或 `IDOCK_TIMEZONE` 覆盖；历史未配置用户使用 Asia/Shanghai。`today` 为当天，`7d` 为含当天的七个自然日，`last-week` 为上一自然周周一至本周周一。显式 ISO 时间区间含起点、不含终点，与 `--time` 互斥。

所有 CLI 列表均使用 ID 游标。复数兼容入口使用 `idock recordings list --page-size 20 --cursor <next_cursor>`，保留 `--group-id`、`--app-tmp-id` 和关键词过滤；响应为 `dataList/pageSize/next_cursor/has_more`，不再返回 `total/totalPages`。原 `--page` 仅接受首页 `1`，随机跳页会报参数错误。单数入口和闪记列表继续使用 `--limit`，最多十条。续页须保持筛选条件；`next_cursor=null` 即结束。录音与闪记的相对时间筛选还会绑定解析后的绝对时间窗：跨当地日期或周界导致时间窗改变时，旧游标返回 `IDOCK_CURSOR_INVALID`，CLI 只重查一次当前时间窗首页并标记 `cursor_reset=true`；需要跨日连续遍历固定区间时使用 `--from/--to`。`browse/repl` 记录已访问游标以支持上一页，首尾不重复请求；界面页序号只表示当前会话位置。

正文板块为 `transcription/chapters/notes/summary/all`。按 Unicode 码点裁剪，默认最多 4000 字符，返回 `truncated/next_offset/total_chars`，按 `next_offset` 续读。锁定板块不可读，`all` 只返回已解锁内容并报告各板块状态。

已按 2026-11-05《听悟会议接口 id 迁移说明》核对：录音读取、下载和导出统一使用 `tingwu_meeting_task.id`，从 `recording list` 的 `items[].id` 或兼容列表的 `dataList[].id` 获取；导入完成后也可使用任务响应中的 `recording_id`。ID 按十进制字符串传递，范围为 `1..9223372036854775807`；不能使用听悟 `taskId`、导入 `job_id` 或纪要 `recordId`。CLI 继续通过 `/idock/.../{id}` 专用接口携带 `X-Access-Key`，无需切换到 App 的 `/tingwu/...` 接口或增加 `User-Id`。转写 TXT/Markdown 继续走 `transcription-url`，其余导出走 `/idock/recordings/{id}/export/{type}`；说明中的停止、打标、分享、删除、移动、合并等接口目前没有对应 CLI 命令。

需要完整转写或纪要且具有对应导出权限时，使用 `idock recording export --id <id> --type transcription --file-format txt --out ./exports`，将 `transcription` 换成 `summary` 可导出完整纪要。当前 `recording get` 仍保留窗口，不支持 `--full`；全文一次返回的取舍及本次分页验证见仓库 `idock-cli/游标分页改造与全文返回说明.md`。

**`search` 只请求现有 RAG 向量库**。服务端用业务主库校验录音归属、删除与解锁状态，并补充来源信息，不从业务正文凑检索结果。`--time/--from/--to` 按录制时间在召回前过滤，按用户时区解析；问题里仅写“上周”不会自动限定时间。`--time` 与显式区间互斥，ISO 时间须携带偏移，含起点、不含终点。没有普通列表游标，`--limit` 是上限，不保证凑满。

默认 JSON 的每条片段包含 `content/score/metadata`，`metadata.recording_id` 是可直接用于 `recording get/download/export` 的十进制字符串，`title/recorded_at` 用于引用来源；`doc_id/point_id/source_id` 不能当录音主键。响应的 `score_type` 声明分数含义，`rerank_score` 也不能解释成答案正确率。`low_confidence=true` 或 `documents=[]` 表示未找到可引用片段，命令正常成功，Agent 应说明未找到相关内容。`--format text` 显示标题、录制时间和正文，无匹配时显示“未找到相关内容。”，不展示内部编号或原始分数。参数校验统一输出 `INVALID_ARGUMENT`，退出码 2。

```json
{
  "ok": true,
  "data": {
    "backend": "rag",
    "count": 1,
    "low_confidence": false,
    "relevance_verified": true,
    "score_type": "rerank_score",
    "documents": [{
      "content": "示例片段",
      "score": 0.87,
      "metadata": {
        "recording_id": "9007199254740993",
        "title": "采购评审会议",
        "recorded_at": "2026-11-10T02:00:00Z"
      }
    }]
  },
  "meta": { "cli_version": "<当前 CLI 版本>" },
  "error": null
}
```

闪记暂按 `note=随手记、todo=待办、bill=账目、idea=灵感`；兼容 `flash flash` 为灵感别名。命名及导入上限仍以 PRD 的“待确认”项为准。

## 下载、导出与导入

```powershell
idock recording download --id <id> --source original --out .\downloads
idock recording download --ids <id1>,<id2> --source mp3 --out .\downloads
idock recording export --id <id> --type transcription --file-format md --out .\exports
idock recording export --ids <id1>,<id2> --type summary --file-format word --out .\exports

# 先输出计划，不读取文件或上传；确认后加 --yes
idock recording import .\会议.wav --duration-seconds 3600
idock recording import .\会议.wav --duration-seconds 3600 --idempotency-key meeting-20261027 --yes
idock job get <job_id>
idock job wait <job_id> --timeout 300 --interval 3
```

导出支持 txt、md/markdown、pdf、word（生成 docx）。文档格式用 `--file-format`，全局 `--format json|text` 控制终端输出。下载/导出每批最多 200 条，逐项报告，部分失败退出码 1。默认不覆盖同名文件；`--overwrite` 显式覆盖。流式写临时文件，成功后发布，结果返回实际路径。

**完整转写的 TXT/Markdown 导出已改为 OSS 直传：** 后端验证 `transcription:export`、录音归属和转写解锁，签发最长 15 分钟且不晚于 Key 到期的临时 URL；CLI 无凭证直连 OSS 下载句子 JSON，在本地生成带时间、说话人的文本。签名 URL 不出现在命令结果中。过期/断连默认重新申请一次，可用 `--retries 0..5` 控制。原始 JSON 按实际下载字节限制为 16 MiB，失败清理临时源文件，不发布不完整文档。PDF/Word 和纪要继续使用现有服务端导出。需配套更新后端；更多说明见 [转写直传](docs/TRANSCRIPTION-DOWNLOAD.md)。

原音保持实际格式；分段分别下载，不自动合并。缺少原始文件时可尝试 MP3，手机本地尚未上传的文件无法由服务端下载。复用既有归属、删除、无痕及内容解锁检查；OSS 请求不携带用户 AccessKey。

导入校验单文件 2GB、4 小时，仅支持 wav、mp3、mp4、m4a，扩展名不区分大小写；其它格式在请求上传授权前拒绝。服务端同时校验扩展名与 MIME 是否匹配，上传声明校验不代表真实音频解码成功。无需 ffmpeg/ffprobe，必须提供实际秒数。流式计算 SHA-256，默认以摘要为幂等键；授权、完成确认、转写沿用现有服务和额度规则。

实际文件大小还受共享上传配置限制，项目默认 100MB。部署需支持到 2GB 时，设置 `FILE_OFFLINE_OSS_MAX_FILE_SIZE_BYTES=2147483648`；此配置也作用于 App 离线上传。CLI 不绕过服务端配置。

上传并登记完成后返回 job_id，后台继续转写。相同用户和幂等键在七天元信息保留期内复用任务，不同内容/大小/时长/MIME 返回冲突。中断时保留 `error.details.job_id/idempotency_key`，查询原任务或用同一文件和同一键恢复。`job wait` 超时不会重传、取消后台任务或重建转写。

七天后临时任务查询过期，业务录音按原规则保留，与会员和 30 天限制无关。状态为 `preparing/uploading/pending/processing/completed/failed`，完成后返回 `recording_id`。

新导入在 `offline_audio` 单独记录 `source=cli`、`source_detail=idock-cli`，与 `device/phone` 区分，转写任务类型仍是 `OFFLINE`。来源由服务端指定，CLI 不传入可覆盖的渠道参数，App 上传接口不接受 `cli`。任务查询也返回保存的来源；之前已按 phone 准备的 CLI 任务继续复用原身份，可通过 `source_detail=idock-cli` 识别。

## 输出与退出

业务命令默认 stdout 只有一份 JSON，进度和提示写 stderr；`--help` 默认展示终端帮助：

```json
{"ok":true,"data":{},"meta":{"cli_version":"1.2.3"},"error":null}
```

错误含 `code/message/hint/retryable`，权限错误附 `missing_scopes`。退出码 0 成功/待确认计划、2 参数、3 认证、5 权限、6 限流、1 服务或任务失败。空结果是成功；游标失效仅重查一次首页并标记 `cursor_reset=true`。

同一用户的全部 CLI API 合计每秒最多一次，跨终端、跨节点及重置 Key 共用额度，两次放行至少间隔 1000 毫秒。超限返回 HTTP 429 / `IDOCK_RATE_LIMITED` / `Retry-After: 1`；CLI 自动等待后最多重试两次，持续超限以退出码 6 结束。一次命令可能包含多次 API 调用，批量导出及导入会因此等待。OSS 文件传输不计入后端 API 次数，App 接口不受这条 CLI 规则影响；部署说明见 [RATE-LIMIT.md](docs/RATE-LIMIT.md)。

`--format text` 提供可读输出并隐藏内部 ID；机器 JSON 保留后续定位所需 ID/游标。Agent 回复用户时遵循 SKILL.md，隐藏 ID、凭证和签名 URL。

```powershell
idock auth logout       # 仅清除当前 profile 本地凭证
idock auth revoke       # 预览撤销计划
idock auth revoke --yes # 撤销服务端 Key，所有持有它的设备失去授权
```

环境变量 Key 需在终端/自动化平台另行清除。旧 `recordings list/show/download/export` 保留兼容，旧导出 `--format word` 自动转换。交互模式用 `browse/repl` 显式进入，无参数返回 schema；交互 `find` 按标题筛选，`search` 调用 RAG。

## 发布包服务器配置

发布者在打包前编辑 [config/release.json](config/release.json)。其中 `endpoint` 是用户连接的完整服务根地址，须包含实际网关路径前缀。以下地址仅为格式示例，须替换成当前环境的真实地址：

```json
{
  "endpoint": "https://api.example.com/user"
}
```

```powershell
npm.cmd test
npm.cmd pack
# 登录 npm 后按需手动发布；此命令会向官方仓库发布安装包。
npm.cmd publish --access public --registry=https://registry.npmjs.org/
```

`npm pack` 和 `npm publish` 都会检查配置文件存在、地址非空且格式合法；检查不通过则停止。配置文件随包携带，按模块位置读取，与用户当前工作目录无关。文件中只配置公开服务器地址，个人 AccessKey 仍由用户登录后保存在其本地配置中。多节点部署填写统一网关地址。

### 发布到 gdpisen 组织

维护者后续统一按照 [发布与 GitHub 文档同步流程](docs/RELEASING.md) 操作，并在 `command-results/<日期>-release/` 记录验证、npm 发布核验和 GitHub 提交。

`package.json` 使用组织包名 `@gdpisen/idock-cli`，`publishConfig` 固定官方 registry 和公开访问级别。发布账号需要具备 `gdpisen` 的发包权限；按 npm 提示完成登录和双因素认证。

```powershell
npm.cmd login --registry=https://registry.npmjs.org/ --auth-type=web
npm.cmd whoami --registry=https://registry.npmjs.org/
npm.cmd pack
npm.cmd publish .\gdpisen-idock-cli-1.2.3.tgz --access public --registry=https://registry.npmjs.org/
```

组织 scope 写在包内 `name` 字段中。旧的 `idock-cli-1.2.0.tgz` 仍是无 scope 的历史包，发布本次组织包时使用 `gdpisen-idock-cli-1.2.3.tgz`。同一组织包的已发布版本不能覆盖，后续更新需增加版本号。

用户安装与使用：

```powershell
npm.cmd install -g @gdpisen/idock-cli
idock --version
idock auth login
```

若之前全局安装了无 scope 的 `idock-cli`，先执行 `npm.cmd uninstall -g idock-cli`，再安装组织包，释放旧包占用的 `idock` 命令入口。个人登录配置保存在 `~/.idock/`，新包沿用该配置。

从旧包 `idock-recording-cli` 或旧 `npm link` 迁移时，先运行 `npm.cmd uninstall -g idock-recording-cli`，再安装新包，避免旧包占用相同的 `idock` 命令入口。

## 后端部署与多节点

启动 `user-starter` 使用 JDK 21，环境变量 `hostname_local=cn_test-0`、`env=cn_test`，Spring profile `cn_test`。网关放行 `/idock/**` GET/POST/DELETE，透传 `X-Access-Key`、`X-Idock-Version` 和管理页的 `X-Token`。

RAG 复用 `tingwu.vector-ingest.api-key/api-token`；查询地址用 `idock.rag.query-url`，或从现有 `tingwu.vector-ingest.url` 的 `/api/resources/ingest` 推导 `/api/resources/query`。Java 向 RAG 发送 `POST {userId:"已认证用户",question:"问题",top_k:100,source_ids:["meeting-纪要ID"]}`；指定时间窗口时同时传 Unix 秒级 `recorded_from/recorded_to`。上游必须同时按用户及来源白名单在召回前过滤，并在响应中声明 `source_filter_applied=true/relevance_verified=true`，通过重排分数筛选有效片段。Java 返回前再次校验来源，旧上游不具备这些能力时明确报 `IDOCK_RAG_UNAVAILABLE`。先部署 RAG，再部署 Java，最后更新 CLI；不需要数据库迁移。地址缺失、协议不符或失败均明确报错。发布前需联调真实 RAG、OSS 和听悟额度。

### Key 管理：已有 App X-Token

| 接口 | 用途 |
| --- | --- |
| `GET /idock/access-key` | 状态、scope、固定到期时间与末四位，无明文 |
| `POST /idock/access-key` | 首次生成：`{expiresInDays:90,scopes:[...]}` |
| `POST /idock/access-key/reset` | 原子替换原 Key |
| `DELETE /idock/access-key` | 幂等撤销 |

服务端从 App 登录态推导身份；CLI Key 不能签发或扩大自身授权。生成/重置响应 `data={accessKey,info}`，明文仅此次返回。`info` 含字符串 `userId`、`active/fingerprint/suffix/scopes/createdAt/expiresAt`，时间为 Unix 毫秒。

默认 scope 为 `recording:read`、`recording:download`、`transcription:export`、`summary:export`、`rag:search`、`flash:read`；`recording:import` 必须显式授予。已有 Key 不会自动扩大权限，需要新能力时从 App 重置并授权。

### CLI 接口：个人 X-Access-Key

| 接口 | 能力 |
| --- | --- |
| `GET /idock/auth/me`、`DELETE /idock/auth/access-key` | 状态/撤销 |
| `GET /idock/agent/profile` | 自检契约与时区 |
| `GET /idock/agent/recordings`、`GET /idock/agent/recordings/{id}` | 列表/正文窗口 |
| `GET /idock/agent/search?question=...` | RAG 搜索，支持 `time/from/to/timezone/limit/offset/length` |
| `GET /idock/agent/flash/{kind}`、`GET /idock/agent/flash/{kind}/{id}` | 闪记列表/正文 |
| `POST /idock/agent/imports`、`POST /idock/agent/imports/{jobId}/complete` | 幂等准备/确认 |
| `GET /idock/agent/jobs/{jobId}` | 共享任务状态 |
| `GET /idock/recordings/{id}/audio-url?source=original` | 原音/MP3 授权 |
| `GET /idock/recordings/{id}/export/transcription?format=TXT` | 转写文件 |
| `GET /idock/recordings/{id}/export/summary?format=WORD` | 纪要文件 |

保留旧 `/idock/recordings` 和 `/{id}` 元信息接口。CLI 不发送用户 ID/App Token，不接受 query 中的 Key，也不支持内部共享 Key 替代个人 Key。

部署前，在各区域用户主库执行 [045_add_idock_access_key.sql](../user-starter/sql/045_add_idock_access_key.sql)，给 `user` 表增加两个字段：`idock_access_key`（完整 Key）和 `idock_access_key_expire_time`（固定到期时间）。脚本附有直接改库的生成示例；Key 格式为 `idock_<真实用户ID>_<64位小写随机十六进制>`，到期时间必填。直接配置这两个字段即可使用默认六项读取/下载/导出权限；导入仍需管理接口显式授权。

SDK 在业务分库路由前认证，每次从所属区域用户主库核对当前 Key 和到期时间；直接改库、注销和跨节点重置在后续请求生效。签发/重置/撤销通过数据库用户行锁和事务协调，scope 和签发时间复用同一主库现有 `app_user_setting` 表的内部键 `idock.access_key_grant`，缓存丢失仍保留原权限。普通用户实体查询、更新和 JSON 输出不携带这两个字段。

Redis 仅缓存摘要、权限和数据库版本，使用 Lua `SET + PEXPIREAT` 原子写入，**TTL = 数据库到期时间 − 当前时间**，请求不续期。为空、已到期或用户已删除时拒绝授权并清理缓存；缓存丢失则从数据库重建，数据库或 Redis 故障时拒绝授权。升级前仅存在 Redis 中的旧 Key 需要重新签发；先完成数据库迁移和所有节点升级，再开放新版授权流程。

导入元信息/准备锁同样使用共享 Redis，业务最终状态读数据库，转写复用现有数据库认领与后台补偿，没有节点内队列。Micrometer 记录命令、鉴权、搜索命中/空结果和裁剪，标签不含正文、用户 ID、文件名或秘密。

## 测试

逐命令验收、异常场景和未验证边界见 [测试矩阵](docs/TEST-MATRIX.md)，本轮执行结果见 [验证记录](docs/VERIFICATION.md)。

```powershell
cd idock-cli
npm.cmd test
cd ..
mvn -pl user-starter -am '-Dtest=IdockAccessKeyFlowTest,IdockAgentReadTest,IdockDocumentExportTest,IdockRagServiceTest,IdockImportFlowTest,IdockTelemetryFilterTest,IdockExportPermissionTest,IdockControllerLoggingTest,RecordingAudioDownloadServiceTest,TingwuMeetingTaskListTest,FileOfflineControllerTest,FileOfflineUploadQuotaTest,FileOfflineTranscriptionResultTest,FileOfflineStorageQuotaServiceTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.useIncrementalCompilation=false test
```

Node 用真实子进程和本地 HTTP 验证信封、退出码、流式文件、凭证隔离与旧命令。Java 用测试专用 embedded Redis、MyBatis/H2 和本地 RAG HTTP 验证多节点/并发幂等、用户隔离、时间、解锁与裁剪；真实 Node 经 HTTP 交替调用两个 MVC 节点。不发送真实短信、不访问业务 Redis/RAG/OSS，不调用计费转写。
