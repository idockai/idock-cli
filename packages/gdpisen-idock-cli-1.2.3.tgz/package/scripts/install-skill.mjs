import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';

/** Skill 使用独立目录，名称与 YAML frontmatter 保持一致。 */
const skillName = 'idock-cli';
/** 仅复制调用指引与引用，不携带发布地址、用户凭证、源码或实测业务数据。 */
const skillFiles = ['SKILL.md', 'agents/openai.yaml', 'references/workflows.md'];
/** 源文件按脚本位置定位，兼容 npm 全局安装和任意当前目录。 */
const packageDirectory = fileURLToPath(new URL('../', import.meta.url));

/** 文件不存在返回空，损坏链接和其它文件系统异常保留原错误。 */
async function existingFile(file) {
  try {
    const stat = await fs.lstat(file);
    if (!stat.isFile()) throw new Error(`目标不是普通文件，未修改：${file}`);
    return await fs.readFile(file);
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

/** 先检查所有目标再复制；默认保护用户定制，--force 仅覆盖本 Skill 管理的三个文件。 */
export async function installSkill({ skillsDirectory = path.join(os.homedir(), '.agents', 'skills'), force = false } = {}) {
  if (!skillsDirectory.trim()) throw new Error('目标技能父目录不能为空');
  const destination = path.resolve(skillsDirectory, skillName);
  try {
    const stat = await fs.lstat(destination);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error(`目标应为实际目录，请指定其它技能父目录：${destination}`);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  const changes = [];
  for (const relative of skillFiles) {
    const content = await fs.readFile(path.join(packageDirectory, relative));
    const target = path.join(destination, relative);
    const existing = await existingFile(target);
    if (existing?.equals(content)) continue;
    if (existing && !force) throw new Error(`已有不同内容，未覆盖：${target}；确认替换本 Skill 文件时使用 --force`);
    changes.push({ target, content });
  }
  for (const { target, content } of changes) {
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.writeFile(target, content);
  }
  return { skill: skillName, path: destination, changed: changes.length, files: skillFiles };
}

/** 安装入口不连接服务、不登录，也不修改任何 CLI 账号或 Codex 全局配置。 */
async function main() {
  const { values } = parseArgs({ options: { target: { type: 'string' }, force: { type: 'boolean' }, help: { type: 'boolean' } } });
  if (values.help) {
    console.log('node scripts/install-skill.mjs [--target <技能父目录>] [--force]\n默认安装到 ~/.agents/skills/idock-cli；--target 指向父目录；不会安装 CLI 或写入凭证。');
    return;
  }
  console.log(JSON.stringify(await installSkill({ skillsDirectory: values.target, force: values.force }), null, 2));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { await main(); }
  catch (error) { console.error(`Skill 安装失败：${error.message}`); process.exitCode = 1; }
}
