import { loadReleaseEndpoint, requireEndpoint } from '../src/config.js';

// npm pack 和 npm publish 共用检查：发布者须填写随包地址，避免把网关配置工作留给终端用户。
try {
  requireEndpoint(await loadReleaseEndpoint());
  // 校验日志走 stderr，避免污染 npm pack --json 供发布脚本读取的标准输出。
  console.error('发布服务器地址配置检查通过');
} catch (error) {
  console.error(`发布检查失败：${error.message}。请先在 config/release.json 中填写 endpoint（含实际网关前缀）。`);
  process.exitCode = 1;
}
