import { readFileSync } from 'node:fs';

/** 版本号统一读取随包清单，保证命令、响应、请求头及兼容性检查与 npm 实际版本一致。 */
export const CLI_VERSION = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;
