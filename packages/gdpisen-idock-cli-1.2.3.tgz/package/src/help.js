import { Chalk } from 'chalk';
import { schema } from './schema.js';

/** 命令说明只描述当前已实现能力；命令名称、参数和选项由 Commander 的实际命令树提供。 */
const descriptions = {
  auth: 'AccessKey 登录、状态与撤销',
  'auth login': '隐藏输入 AccessKey，验证成功后保存到本机',
  'auth status': '查看登录状态、授权范围和到期时间',
  'auth logout': '清除当前环境的本地登录信息',
  'auth revoke': '撤销当前 AccessKey，使所有节点上的授权失效',
  recording: '录音查询、正文读取、音频下载、文档导出与导入',
  'recording list': '按时间、名称和来源查询录音',
  'recording get': '读取转写、章节、笔记或纪要，支持分页续读',
  'recording download': '下载原始音频或 MP3 到本机',
  'recording export': '导出转写或纪要，支持 TXT、Markdown、PDF、Word',
  'recording import': '上传本地音频并创建异步转写任务',
  search: '仅检索当前用户的 RAG 向量库',
  flash: '随手记、待办、账目与灵感查询',
  job: '查询导入任务与等待转写完成',
  'job get': '查看已有导入任务的状态',
  'job wait': '轮询已有任务，直到完成、失败或超时',
  config: '本地连接环境与时区配置',
  'config set': '设置 profile、timezone 或 endpoint',
  doctor: '检查本地设置、网络、鉴权与服务版本',
  schema: '输出供 Agent 读取的完整 JSON 命令契约',
  browse: '进入交互浏览，查询、选择、下载与导出录音',
  repl: '进入交互命令会话',
  whoami: '查看当前 AccessKey 对应的用户身份',
  recordings: '兼容原有复数录音命令',
  'recordings list': '使用游标查询录音，保留分组和手机关联筛选',
  'recordings show': '查看单条录音的元信息',
  help: '查看任意层级命令的帮助'
};

/** 闪记种类使用业务中文名称，兼容别名也明确显示其实际含义。 */
const flashKinds = { note: '随手记', todo: '待办', bill: '账目', idea: '灵感', flash: '灵感（兼容别名）' };
/** 位置参数统一给出中文含义，帮助页中的编号始终只是示例占位符。 */
const argumentDescriptions = { id: '从对应列表获取的记录 ID', question: '要在 RAG 向量库检索的问题',
  file: '本地音频文件路径', job_id: '导入返回的任务 UUID', key: '配置项：profile、timezone 或 endpoint',
  value: '配置项的值', path: '命令路径，例如 recording import' };
/** 补齐历史命令中只有名称、没有说明的选项，实际约束仍由原命令定义提供。 */
const optionDescriptions = { keyword: '按录音名称筛选', source: '录音或音频来源', from: '起始 ISO 时间，包含此时刻',
  to: '结束 ISO 时间，不包含此时刻', cursor: '上一页返回的 next_cursor', id: '录音列表中的会议主键 id，不能使用 taskId', ids: '多个会议主键 id，以逗号分隔，不能使用 taskId',
  groupId: '按原有录音分组筛选', appTmpId: '按 App 临时标识筛选', section: '要读取的正文板块',
  type: '导出转写或纪要', fileFormat: '导出文件的文档格式' };
/** 示例仅使用已经注册的命令；写操作示例先展示计划，执行由用户显式增加 --yes。 */
const examples = {
  auth: ['idock auth login', 'idock auth status'],
  'auth login': ['idock auth login', 'idock auth login --key-stdin'],
  'auth revoke': ['idock auth revoke'],
  recording: ['idock recording list --time 7d --limit 5', 'idock recording get <id> --section summary',
    'idock recording download --id <id> --out ./downloads'],
  'recording list': ['idock recording list --time 7d --limit 5', 'idock recording list --keyword "产品会议" --source offline'],
  'recording get': ['idock recording get <id> --section summary', 'idock recording get <id> --offset 4000 --length 4000'],
  'recording download': ['idock recording download --id <id> --source original --out ./downloads'],
  'recording export': ['idock recording export --id <id> --type summary --file-format word --out ./exports'],
  'recording import': ['idock recording import "./会议.wav" --duration-seconds 3600'],
  search: ['idock search "会议行动项" --time last-week --limit 5', 'idock --format text search "工作计划" --time 7d',
    'idock --timezone Asia/Shanghai search "采购流程" --from 2026-10-01T00:00:00+08:00 --to 2026-11-01T00:00:00+08:00'],
  flash: ['idock flash note list --time today', 'idock flash todo get <id>'],
  job: ['idock job get <job_id>', 'idock job wait <job_id> --timeout 300'],
  'job get': ['idock job get <job_id>'],
  'job wait': ['idock job wait <job_id> --timeout 300 --interval 3'],
  config: ['idock config set timezone Asia/Shanghai', 'idock config set profile cn_test'],
  'config set': ['idock config set timezone Asia/Shanghai', 'idock config set profile cn_test'],
  schema: ['idock schema'],
  help: ['idock help recording import', 'idock --format json recording list --help']
};

/** 获取相对根命令的完整路径，支持 flash 等多层命令且不依赖私有解析字段。 */
export function commandPath(command) {
  const parts = [];
  for (let current = command; current.parent; current = current.parent) parts.unshift(current.name());
  return parts.join(' ');
}

/** 遍历真实命令树补齐说明，不注册业务能力，也不会加载配置或访问网络。 */
export function describeCommands(command) {
  const path = commandPath(command);
  const parts = path.split(' ');
  if (descriptions[path]) command.description(descriptions[path]);
  else if (parts[0] === 'flash' && flashKinds[parts[1]]) {
    command.description(parts.length === 2 ? flashKinds[parts[1]]
      : `${parts[2] === 'list' ? '查询' : '读取'}${flashKinds[parts[1]]}${parts[2] === 'list' ? '列表' : '正文'}`);
  } else if (parts[0] === 'recordings' && descriptions[`recording ${parts[1]}`]) {
    command.description(descriptions[`recording ${parts[1]}`]);
  }
  for (const argument of command.registeredArguments) {
    if (!argument.description) argument.description = argument.name() === 'id' && ['recording', 'recordings'].includes(parts[0])
      ? '录音列表中的会议主键 id，不能使用 taskId' : argumentDescriptions[argument.name()] || '';
  }
  for (const option of command.options) {
    if (!option.description) option.description = optionDescriptions[option.attributeName()] || '';
  }
  command.helpOption('-h, --help', '查看当前命令帮助');
  if (command.parent && command.commands.length) command.addHelpCommand('help [command]', '查看子命令帮助');
  else command.addHelpCommand(false);
  for (const child of command.commands) describeCommands(child);
}

/** 中文占两个终端列，保证全局参数和值为中文的帮助列对齐。 */
function displayWidth(value) {
  return [...value].reduce((width, character) => width + (/[\u1100-\u115f\u2e80-\ua4cf\uac00-\ud7a3\uf900-\ufaff\ufe10-\ufe6f\uff01-\uff60\uffe0-\uffe6]/u.test(character) ? 2 : 1), 0);
}

/** 帮助只在交互终端着色；管道、重定向、NO_COLOR 和 JSON 输出均可得到无 ANSI 内容。 */
export function renderHelp(command, helper, { color = false, columns = 76 } = {}) {
  const paint = new Chalk({ level: color ? 1 : 0 });
  const path = commandPath(command);
  const root = !command.parent;
  const width = Math.max(40, Math.min(96, columns || 76));
  const output = [paint.bold.cyan(`iDock CLI · 录音、知识检索与闪记 · v${schema.version}`), paint.dim('─'.repeat(width)), ''];

  /** 同一分区共享列宽，先计算可见字符再着色，避免 ANSI 和中文造成错位。 */
  function section(title, rows, { bullet = false } = {}) {
    if (!rows.length) return;
    output.push(paint.bold.cyan(`▍ ${title}`), '');
    const termWidth = Math.max(...rows.map(([term]) => displayWidth(term)));
    for (const [term, description] of rows) {
      const padding = ' '.repeat(termWidth - displayWidth(term) + 2);
      output.push(`  ${bullet ? paint.cyan('•') + ' ' : ''}${paint.bold(term)}${description ? padding + description : ''}`);
    }
    output.push('');
  }

  /** 默认值和可选值沿用真实解析器定义，必填选项单独标识，避免示例与参数约束不一致。 */
  function optionDescription(option) {
    return helper.optionDescription(option).replace(/\bchoices:/g, '可选：').replace(/\bdefault:/g, '默认：')
      + (option.mandatory ? '（必填）' : '');
  }

  if (!root && command.description()) output.push(command.description(), '');
  section('用法 Usage', [[`Usage: ${helper.commandUsage(command)}`, '']]);
  const commands = helper.visibleCommands(command);
  if (root) {
    for (const [title, names] of [['功能命令', ['recording', 'search', 'flash', 'job']],
      ['工具命令', ['auth', 'config', 'doctor', 'schema', 'help']],
      ['交互与兼容', ['browse', 'repl', 'whoami', 'recordings']]]) {
      section(title, names.map(name => commands.find(item => item.name() === name)).filter(Boolean)
        .map(item => [item.name(), item.description()]), { bullet: true });
    }
  } else {
    section('子命令', commands.map(item => [helper.subcommandTerm(item), item.description()]), { bullet: true });
  }
  section('位置参数', helper.visibleArguments(command).map(argument => [helper.argumentTerm(argument), helper.argumentDescription(argument)]));
  section(root ? '全局参数' : '命令参数', helper.visibleOptions(command).map(option => [helper.optionTerm(option), optionDescription(option)]));
  if (!root) section('全局参数', helper.visibleGlobalOptions(command).map(option => [helper.optionTerm(option), optionDescription(option)]));
  const samples = root ? ['idock auth login', 'idock recording list --time 7d --limit 5', 'idock search "会议行动项"',
    'idock recording export --id <id> --type summary --file-format word'] : examples[path]
    || (path.startsWith('flash ') ? [`idock ${path}${path.endsWith('get') ? ' <id>' : path.endsWith('list') ? ' --limit 5' : ' list'}`] : []);
  section('示例', samples.map(sample => [sample, '']), { bullet: true });
  if (root) {
    section('Agent 快速开始', [
      ['1.', 'idock <命令> --help 查看功能与参数'],
      ['2.', 'idock schema 读取完整 JSON 命令契约'],
      ['3.', '业务结果默认 JSON；--format text 查看可读正文'],
      ['4.', 'idock --format json <命令> --help 获取结构化帮助']
    ]);
    output.push('服务地址由安装包预设；首次使用只需执行 idock auth login。', '');
  }
  if (root || path === 'recording import' || path === 'auth revoke') {
    output.push('导入音频和撤销授权先输出计划，确认后加 --yes 执行。', '');
  }
  output.push(paint.dim(root ? '下一步：idock recording --help 查看录音命令。'
    : '更多帮助：idock --help · 机器契约：idock schema'));
  return output.join('\n') + '\n';
}
