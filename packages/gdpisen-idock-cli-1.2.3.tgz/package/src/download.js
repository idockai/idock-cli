import path from 'node:path';
import fs from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { randomUUID } from 'node:crypto';

/** 将服务端文件名转换为跨平台安全文件名，不允许绝对路径、目录穿越或终端控制字符。 */
export function safeFileName(value) {
  let name = String(value || 'recording').replace(/[<>:"/\\|?*\x00-\x1f\x7f]/g, '_')
    .replace(/[. ]+$/, '').slice(0, 180).replace(/[. ]+$/, '');
  if (!name || /^\.+$/.test(name)) name = 'recording';
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name)) name = `_${name}`;
  return name;
}

/** 读取 RFC 5987 下载文件名，兼容现有中文 Content-Disposition；始终经过本地文件名清洗。 */
export function responseFileName(response, fallback) {
  const header = response.headers.get('content-disposition') || '';
  const encoded = header.match(/filename\*=UTF-8''([^;]+)/i);
  if (encoded) {
    try { return safeFileName(decodeURIComponent(encoded[1].trim())); } catch { /* 损坏编码时尝试普通文件名。 */ }
  }
  const plain = header.match(/filename="([^"]+)"|filename=([^;]+)/i);
  return safeFileName(plain?.[1] || plain?.[2]?.trim() || fallback);
}

/** 不带项目用户凭证访问 OSS 授权地址；超时和 HTTP 错误使用不含签名的错误消息。 */
export async function fetchAudio(url, { fetchFn = fetch } = {}) {
  const parsed = new URL(url);
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw new Error('服务端返回了无效的音频下载地址');
  }
  let response;
  try {
    response = await fetchFn(parsed, { signal: AbortSignal.timeout(1_800_000), redirect: 'follow' });
  } catch (error) {
    throw new Error(error.name === 'TimeoutError' ? '音频下载超时' : '无法连接音频存储服务');
  }
  if (!response.ok) {
    await response.body?.cancel();
    const error = new Error(`音频下载失败（HTTP ${response.status}），可重试申请新的下载授权`);
    error.status = response.status;
    throw error;
  }
  if (/json|xml|text\/html/i.test(response.headers.get('content-type') || '')) {
    await response.body?.cancel();
    throw new Error('音频存储返回了错误页面，未保存为录音文件');
  }
  return response;
}

/**
 * 流式写入独立临时文件后发布结果；失败清理临时文件，默认保留已有文件并生成递增名称。
 * 通过硬链接原子占用最终路径，多个 CLI 进程同时下载也不会互相覆盖或留下未完成的目标文件。
 */
export async function saveDownload(response, { directory = './exports', fileName, overwrite = false, onProgress } = {}) {
  if (!response.body) throw new Error('下载响应没有文件内容');
  const output = path.resolve(directory);
  await fs.mkdir(output, { recursive: true });
  const name = safeFileName(fileName);
  const temporary = path.join(output, `.${name}.part-${randomUUID()}`);
  const total = Number(response.headers.get('content-length')) || null;
  let received = 0;
  const progress = new Transform({
    /** 统计已下载字节，不将整个录音加载到内存。 */
    transform(chunk, encoding, callback) {
      received += chunk.length;
      onProgress?.(received, total);
      callback(null, chunk);
    }
  });
  try {
    await pipeline(Readable.fromWeb(response.body), progress, createWriteStream(temporary, { flags: 'wx' }));
    if (total !== null && !response.headers.get('content-encoding') && received !== total) {
      throw new Error('文件下载不完整，请重试');
    }
    const parsed = path.parse(name);
    for (let index = 0; ; index += 1) {
      const target = path.join(output, index === 0 ? name : `${parsed.name} (${index})${parsed.ext}`);
      try {
        if (overwrite) await fs.rename(temporary, target);
        else await fs.link(temporary, target);
        return { path: target, sizeBytes: received };
      } catch (error) {
        if (!overwrite && error.code === 'EEXIST') continue;
        throw error;
      }
    }
  } finally {
    await fs.rm(temporary, { force: true });
  }
}
