import { CLI_VERSION } from './version.js';

/** Agent 可读取的命令契约；文件格式与终端输出格式分别命名。 */
export const schema = {
  name: 'idock', version: CLI_VERSION, schema_version: 1,
  output: { envelope: ['ok', 'data', 'meta', 'error'], default: 'json', text: '--format text',
    help: { default: 'text', json: '--format json --help', path: 'help [path...]' } },
  globals: ['--profile <name>', '--endpoint <url>', '--timezone <IANA>', '--format <json|text>'],
  scopes: ['recording:read', 'recording:download', 'transcription:export', 'summary:export', 'rag:search', 'flash:read', 'recording:import'],
  defaults: { limit: 10, max_limit: 10, text_length: 4000 },
  /** 录音命令只接收会议任务表主键；列表中的听悟 taskId 和导入 job_id 均不是此编号。 */
  recording_ids: { source: 'recording list: items[].id; recordings list: dataList[].id; completed job: recording_id; search: documents[].metadata.recording_id',
    type: 'decimal string', min: '1', max: '9223372036854775807',
    rejected_identifiers: ['taskId', 'job_id', 'recordId', 'doc_id', 'point_id'],
    transport: '/idock/.../{id}; X-Access-Key' },
  exit_codes: { 0: 'success', 1: 'service_or_job_error', 2: 'argument', 3: 'authentication', 5: 'permission', 6: 'rate_limit' },
  /** 本地校验和服务端同类参数校验统一输出此错误码。 */
  error_codes: { argument: 'INVALID_ARGUMENT' },
  compatibility_commands: [
    { command: 'recordings list', scope: 'recording:read', pagination: 'cursor',
      parameters: ['--keyword <text>', '--group-id <id>', '--app-tmp-id <id>', '--page-size <1..200>', '--cursor <value>'],
      result: ['dataList', 'pageSize', 'next_cursor', 'has_more'], deprecated: { '--page': '仅接受 1；后续页面使用 --cursor，不再返回 total/totalPages' } }
  ],
  commands: [
    { command: 'auth login', parameters: ['--key-stdin'], writes: 'local_config' },
    { command: 'auth status', parameters: [] },
    { command: 'auth logout', parameters: [] },
    { command: 'auth revoke', parameters: ['--yes'], writes: 'remote_authorization' },
    { command: 'schema', parameters: [] },
    { command: 'config set', arguments: ['key', 'value'], keys: ['endpoint', 'profile', 'timezone'] },
    { command: 'doctor', parameters: [] },
    { command: 'recording list', scope: 'recording:read', parameters: ['--time <today|7d|last-week>', '--from <ISO>', '--to <ISO>', '--keyword <text>', '--source <online|offline|merged>', '--limit <1..10>', '--cursor <value>'] },
    { command: 'recording get', scope: 'recording:read', arguments: ['id'], parameters: ['--section <all|transcription|chapters|notes|summary>', '--offset <number>', '--length <1..4000>'] },
    { command: 'recording download', scope: 'recording:download', parameters: ['--id <id>', '--ids <ids>', '--source <original|mp3>', '--out <directory>', '--overwrite', '--retries <0..5>'] },
    { command: 'recording export', scope: '<type>:export', parameters: ['--id <id>', '--ids <ids>', '--type <transcription|summary>', '--file-format <md|txt|pdf|word>', '--out <directory>', '--overwrite', '--retries <0..5>'],
      transcription_text: 'OSS temporary URL; downloaded and converted locally; URLs are never returned in command results' },
    { command: 'recording import', scope: 'recording:import', arguments: ['file'], parameters: ['--duration-seconds <number>', '--idempotency-key <value>', '--yes'], writes: 'audio_and_transcription' },
    { command: 'job get', scope: 'recording:import', arguments: ['job_id'], parameters: [] },
    { command: 'job wait', scope: 'recording:import', arguments: ['job_id'], parameters: ['--timeout <seconds>', '--interval <seconds>'] },
    { command: 'search', scope: 'rag:search', arguments: ['question'], parameters: ['--limit <1..10>', '--offset <number>', '--length <1..4000>', '--time <today|7d|last-week>', '--from <ISO>', '--to <ISO>'], backend: 'rag_only',
      /** 时间范围由服务端按录制时间解析，问题中的自然语言时间词不构成过滤条件。 */
      time_filter: { field: 'recorded_at', timezone: 'user profile or --timezone', bounds: '[from,to)', exclusive: ['--time', '--from/--to'] },
      /** 录音编号按字符串使用；向量文档编号不能传给录音详情、下载或导出命令。 */
      source_metadata: ['recording_id', 'title', 'recorded_at'],
      /** 空结果是成功响应；低相关性时不能引用正文，分数含义由 score_type 声明，不是正确率。 */
      no_match: 'low_confidence=true or documents=[]; do not answer from snippets',
      relevance: ['low_confidence', 'relevance_verified', 'score_type'] },
    ...['note', 'todo', 'bill', 'idea'].flatMap((type) => [
      { command: `flash ${type} list`, scope: 'flash:read', parameters: ['--limit <1..10>', '--cursor <value>', '--time <today|7d|last-week>', '--from <ISO>', '--to <ISO>'] },
      { command: `flash ${type} get`, scope: 'flash:read', arguments: ['id'], parameters: ['--offset <number>', '--length <1..4000>'] }
    ])
  ]
};
