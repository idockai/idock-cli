import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { createApi } from './api.js';
import { createCommands, positiveId } from './commands.js';
import { requireConnection, resolveConfig, setConfig } from './config.js';
import { CliError, argumentError } from './result.js';
import { CLI_VERSION } from './version.js';

/** Agent 扩展命令；复用已有 Node API、配置和安全流下载实现。 */
export function createAgentCommands({ overrides = {}, api, sleep = delay, now = Date.now, fetchFn = fetch } = {}) {
  const client = api || createApi({ connection: () => resolveConfig(overrides) });
  const legacy = createCommands({ overrides });

  /** 游标失效仅重查一次首页，明确标记重置，不偷偷遍历其他页面。 */
  async function page(route, options) {
    const config = await resolveConfig(overrides);
    const params = { ...options, timezone: config.timezone };
    try { return await client.request(route, params); }
    catch (error) {
      if (error.code !== 'IDOCK_CURSOR_INVALID' || !params.cursor) throw error;
      return { ...await client.request(route, { ...params, cursor: undefined }), cursor_reset: true };
    }
  }

  /** 所有远端写命令先返回可审阅计划，显式 --yes 才会发送请求。 */
  function requireYes(options, plan) {
    if (options.yes) return null;
    return { executed: false, confirmation_required: true, plan, hint: '向用户复述以上操作；确认后加 --yes 执行' };
  }

  /** 检查网络和认证，不修改服务端数据或泄露配置中的 Key。 */
  async function doctor() {
    const config = requireConnection(await resolveConfig(overrides));
    const user = await client.getUser();
    const profile = await client.request('/idock/agent/profile');
    if (profile.min_cli_version && profile.min_cli_version.localeCompare(CLI_VERSION, undefined, { numeric: true }) > 0) {
      throw new CliError('IDOCK_CLIENT_TOO_OLD', '服务要求更新的 CLI 版本', { hint: '升级 idock 后重新执行 doctor' });
    }
    return { healthy: true, node_version: process.versions.node, endpoint: config.endpoint,
      profile: config.profile, scopes: user.scopes, expires_at: user.expiresAt, server: profile };
  }

  /** 校验文件后流式计算内容摘要；不把整个两 GB 音频读入内存。 */
  async function fileInfo(file, options) {
    const absolute = path.resolve(file);
    let stat;
    try { stat = await fs.stat(absolute); } catch { throw argumentError('音频文件不存在或无法读取'); }
    if (!stat.isFile() || stat.size < 1 || stat.size > 2 * 1024 ** 3) throw argumentError('须为非空音频文件，最大 2GB');
    // 上传只开放 WAV、MP3、MP4、M4A，与服务端的扩展名白名单保持一致。
    const types = { '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.mp4': 'audio/mp4', '.m4a': 'audio/mp4' };
    const contentType = types[path.extname(absolute).toLowerCase()];
    if (!contentType) throw argumentError('不支持的音频扩展名，仅支持 wav、mp3、mp4、m4a');
    const duration = options.durationSeconds;
    if (!Number.isSafeInteger(duration) || duration < 1 || duration > 14400) throw argumentError('duration-seconds 须为 1 至 14400 的实际时长');
    const hash = createHash('sha256');
    for await (const chunk of createReadStream(absolute)) hash.update(chunk);
    return { absolute, size: stat.size, modified: stat.mtimeMs, contentType, sha256: hash.digest('hex'), durationSeconds: duration };
  }

  /** 导入只等待上传和任务受理；转写通过独立 job 查询，超时不会自动重传。 */
  async function importRecording(file, options) {
    const plan = { operation: 'recording import', file: path.basename(file), duration_seconds: options.durationSeconds,
      effect: '上传音频并触发转写，沿用现有云存储与转写额度规则' };
    const preview = requireYes(options, plan);
    if (preview) return preview;
    const info = await fileInfo(file, options);
    const idempotencyKey = options.idempotencyKey || info.sha256;
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(idempotencyKey)) throw argumentError('idempotency-key 须为 1 至 128 位字母、数字、下划线或横线');
    const ticket = await client.request('/idock/agent/imports', {}, { method: 'POST', command: 'recording.import', body: {
      fileName: path.basename(info.absolute), contentType: info.contentType, fileSize: info.size,
      durationSeconds: info.durationSeconds, sha256: info.sha256, idempotencyKey, confirmed: true
    } });
    if (ticket.status === 'preparing') return { job_id: ticket.job_id, status: ticket.status, hint: '任务正在准备，请执行 job get；重试导入时复用同一幂等键' };
    if (ticket.upload?.uploadRequired) {
      const stat = await fs.stat(info.absolute);
      if (stat.size !== info.size || stat.mtimeMs !== info.modified) throw argumentError('文件在计算摘要后发生变化，请重新执行导入');
      const url = new URL(ticket.upload.uploadUrl);
      if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) throw new Error('服务端返回了无效上传地址');
      const headers = { ...ticket.upload.requiredHeaders, 'Content-Length': String(info.size) };
      if (Object.keys(headers).some((name) => /^(x-access-key|x-token|authorization|cookie|host)$/i.test(name))) {
        throw new Error('上传授权包含不允许的请求头');
      }
      let response;
      try {
        response = await fetchFn(url, { method: 'PUT', headers, body: createReadStream(info.absolute), duplex: 'half',
          redirect: 'error', signal: AbortSignal.timeout(3600000) });
      } catch {
        throw new CliError('UPLOAD_UNCERTAIN', '上传未确认；重试同一文件将复用原任务', {
          hint: '使用 error.details 中的幂等键重试同一文件，或通过 job get 查询原任务', retryable: true,
          details: { job_id: ticket.job_id, idempotency_key: idempotencyKey }
        });
      }
      await response.body?.cancel();
      if (!response.ok) throw new CliError('UPLOAD_FAILED', `音频上传失败（HTTP ${response.status}）`, { retryable: response.status >= 500,
        hint: '重试同一文件和幂等键以恢复上传，不要创建不同的业务导入',
        details: { job_id: ticket.job_id, idempotency_key: idempotencyKey } });
    }
    let result;
    try {
      result = await client.request(`/idock/agent/imports/${encodeURIComponent(ticket.job_id)}/complete`, {}, { method: 'POST', body: { confirmed: true } });
    } catch (error) {
      // 完成确认可能已经被另一节点受理，必须把原任务交还调用方，避免盲目创建第二份导入。
      error.details = { job_id: ticket.job_id, idempotency_key: idempotencyKey }; throw error;
    }
    return { ...result, idempotency_key: idempotencyKey };
  }

  /** 任务标识不是会议 ID，单独校验 UUID，不调用上传入口。 */
  async function jobGet(id) {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) throw argumentError('job_id 须使用 recording import 返回的任务编号');
    return client.request(`/idock/agent/jobs/${encodeURIComponent(id)}`);
  }

  /** 有界轮询只查询任务；超时保留原 job_id，绝不隐式重新上传。 */
  async function jobWait(id, { timeout = 300, interval = 3 } = {}) {
    const deadline = now() + timeout * 1000;
    for (;;) {
      const job = await jobGet(id);
      if (job.status === 'completed') return job;
      if (job.status === 'failed') throw new CliError('JOB_FAILED', job.message || '转写失败', { hint: '检查额度或任务错误，使用 job get 查询原任务', details: { job_id: id } });
      if (now() >= deadline) throw new CliError('JOB_TIMEOUT', '等待任务超时，原任务继续处理', {
        hint: '稍后使用相同 job_id 执行 job wait，不要重新上传', retryable: true, details: { job_id: id }
      });
      await sleep(Math.min(interval * 1000, deadline - now()));
    }
  }

  return {
    doctor, importRecording, jobGet, jobWait,
    /** 本地设置修改只接受非秘密白名单字段。 */
    async configSet(key, value) { try { return await setConfig(key, value, overrides); } catch (error) { throw argumentError(error.message); } },
    /** 撤销是远端写操作，未带 --yes 时只返回计划。 */
    async revoke(options) { return requireYes(options, { operation: 'auth revoke', effect: '全部使用当前 Key 的设备将失去授权' }) || legacy.revoke(); },
    /** 录音列表仅请求指定页。 */
    list: (options) => page('/idock/agent/recordings', options),
    /** 单条元信息及正文均经过服务端用户隔离、解锁与裁剪。 */
    get: (id, options) => client.request(`/idock/agent/recordings/${positiveId(id)}`, options),
    /** 问题只发送到 RAG 专用入口，结果不会从其它数据库补齐。 */
    async search(question, options) {
      const config = await resolveConfig(overrides);
      return client.request('/idock/agent/search', { question, ...options, timezone: config.timezone });
    },
    /** 闪记列表与详情由同一用户授权控制，类型不能跨用。 */
    flashList: ({ kind, ...options }) => page(`/idock/agent/flash/${kind}`, options),
    /** 详情使用列表返回的主记录 ID，正文按字符窗口读取。 */
    flashGet: (id, { kind, ...options }) => client.request(`/idock/agent/flash/${kind}/${positiveId(id)}`, options)
  };
}
