import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { CliError } from './result.js';
import { saveDownload } from './download.js';

/** 原始转写 JSON 最大十六 MiB，与已有正文读取限制一致；流式下载时同样强制检查实际字节。 */
export const MAX_TRANSCRIPTION_BYTES = 16 * 1024 * 1024;

/** 复用服务端转写时间格式 mm:ss.SS，分钟超过 59 不转换为小时。 */
function timestamp(value) {
  const milliseconds = typeof value === 'number' && Number.isSafeInteger(value) ? Math.max(0, value) : 0;
  return `${String(Math.floor(milliseconds / 60000)).padStart(2, '0')}:${String(Math.floor(milliseconds / 1000) % 60).padStart(2, '0')}.${String(Math.floor(milliseconds / 10) % 100).padStart(2, '0')}`;
}

/** 按句子生成 UTF-8 字节，保留时间、说话人和正文；不把整个最终 TXT 再拼成一份大字符串。 */
function* renderSentences(sentences, title, format) {
  if (format === 'markdown') yield Buffer.from(`# ${title}\n`, 'utf8');
  let first = true;
  for (const sentence of sentences) {
    if (!sentence?.content) continue;
    const speaker = sentence.speakerLabel || '说话人';
    yield Buffer.from(format === 'markdown'
      ? `\n### ${speaker} ${timestamp(sentence.beginTime)}\n${sentence.content}\n`
      : `${first ? '' : '\n'}[${timestamp(sentence.beginTime)}]${speaker}:  ${sentence.content}`, 'utf8');
    first = false;
  }
}

/** 校验短期下载地址，仅生产 HTTPS 和本机 HTTP 测试地址可用；无效地址的错误不包含签名。 */
function downloadAddress(value) {
  try {
    const url = new URL(value);
    const localHttp = url.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
    if (url.username || url.password || url.hash || !(url.protocol === 'https:' || localHttp)) throw new Error();
    return url;
  } catch { throw new CliError('TRANSCRIPTION_URL_INVALID', '服务端返回了无效的转写下载地址'); }
}

/**
 * 从对象存储无凭证流式下载到独立临时目录，再在本地解析受限大小的 JSON 并原子发布文本。
 * 仅读取句子白名单字段，不返回原始 JSON 或签名；失败清理临时文件，最终路径只在完整成功后出现。
 */
export async function downloadTranscription(ticket, options, { fetchFn = fetch, saveFn = saveDownload,
  maxBytes = MAX_TRANSCRIPTION_BYTES, temporaryRoot = os.tmpdir() } = {}) {
  if (ticket?.sourceFormat !== 'tingwu-sentences-v1') {
    throw new CliError('TRANSCRIPTION_FORMAT_INVALID', '服务端转写格式不受支持，请检查后端版本');
  }
  const url = downloadAddress(ticket.downloadUrl);
  let response;
  try { response = await fetchFn(url, { redirect: 'error', signal: AbortSignal.timeout(300_000) }); }
  catch { throw new Error('无法连接转写存储服务，请重新申请下载授权'); }
  if (!response.ok) {
    await response.body?.cancel();
    const error = new Error(`转写下载失败（HTTP ${response.status}），请重新申请下载授权`);
    error.status = response.status;
    throw error;
  }
  const type = response.headers.get('content-type') || '';
  if (/html|xml/i.test(type) || type && !/^(application\/(json|octet-stream)|text\/(plain|json))(;|$)/i.test(type)) {
    await response.body?.cancel();
    throw new CliError('TRANSCRIPTION_FORMAT_INVALID', '转写存储返回了错误页面，未生成文档');
  }
  const declared = Number(response.headers.get('content-length'));
  if (Number.isFinite(declared) && declared > maxBytes) {
    await response.body?.cancel();
    throw new CliError('TRANSCRIPTION_TOO_LARGE', '转写源文件超过 16 MiB，请使用服务端 PDF/Word 导出');
  }
  if (!response.body) throw new Error('转写下载响应没有文件内容');
  const temporary = await fs.mkdtemp(path.join(temporaryRoot, 'idock-transcription-'));
  const source = path.join(temporary, 'sentences.json');
  let received = 0;
  try {
    const limit = new Transform({
      /** Content-Length 缺失或被压缩时仍按实际解压后的字节限制，避免错误资源耗尽本地内存或磁盘。 */
      transform(chunk, encoding, callback) {
        received += chunk.length;
        if (received > maxBytes) callback(new CliError('TRANSCRIPTION_TOO_LARGE', '转写源文件超过 16 MiB，未生成文档'));
        else callback(null, chunk);
      }
    });
    try {
      await pipeline(Readable.fromWeb(response.body), limit, createWriteStream(source, { flags: 'wx', mode: 0o600 }));
      if (response.headers.has('content-length') && !response.headers.get('content-encoding') && received !== declared) {
        throw new Error('incomplete');
      }
    } catch (error) {
      if (error instanceof CliError || error.code && !['ECONNRESET', 'UND_ERR_SOCKET'].includes(error.code)) throw error;
      throw new Error('转写下载中断或内容不完整，请重新申请下载授权');
    }
    let sentences;
    try { sentences = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(await fs.readFile(source))); }
    catch { throw new CliError('TRANSCRIPTION_FORMAT_INVALID', '转写文件不是有效的 UTF-8 JSON，未生成文档'); }
    if (!Array.isArray(sentences) || sentences.some(item => item !== null && (typeof item !== 'object' || Array.isArray(item)
      || item.content != null && typeof item.content !== 'string' || item.speakerLabel != null && typeof item.speakerLabel !== 'string'))) {
      throw new CliError('TRANSCRIPTION_FORMAT_INVALID', '转写文件不是有效的句子列表，未生成文档');
    }
    if (!sentences.some(item => item?.content)) throw new CliError('TINGWU_TRANSCRIPTION_EMPTY', '转写内容为空，未生成文档');
    const format = options.format;
    const fileName = `${options.id}_${String(ticket.fileName || 'transcription.json').replace(/\.json$/i, '')}.${format === 'markdown' ? 'md' : 'txt'}`;
    const body = Readable.toWeb(Readable.from(renderSentences(sentences, ticket.title || '会议转写', format)));
    return { ...await saveFn(new Response(body), { directory: options.out, fileName, overwrite: options.overwrite,
      onProgress: options.onProgress }), version: ticket.version };
  } finally {
    // 目录由 mkdtemp 在系统临时根下直接创建，路径不使用用户输入，仅清理本次调用拥有的源文件。
    await fs.rm(source, { force: true });
    await fs.rmdir(temporary);
  }
}
