import { requireConnection, resolveConfig } from './config.js';
import { normalizeError } from './result.js';
import { setTimeout as wait } from 'node:timers/promises';
import { CLI_VERSION } from './version.js';

/** 只重试服务端在执行前拒绝的用户限流，持续竞争时最多额外请求两次，避免无限等待。 */
const MAX_RATE_LIMIT_RETRIES = 2;

/** 根据业务错误结构生成异常，只输出业务消息，不输出含 AccessKey 或 OSS 签名的请求地址。 */
export function responseError(payload, status, retryAfter) {
  const message = status === 401 ? 'AccessKey 无效、已撤销或已过期，请重新执行 auth login'
    : payload?.errorMessage || payload?.message || `接口请求失败（HTTP ${status}）`;
  const error = new Error(message);
  error.code = payload?.errorCode || `HTTP_${status}`;
  error.status = status;
  error.hint = payload?.hint;
  const missing = payload?.missing_scopes || payload?.data?.missing_scopes;
  error.missingScopes = missing || (status === 403 && /[a-z]+:[a-z]+/.test(message) ? [message.match(/[a-z]+:[a-z]+/)[0]] : []);
  const normalized = normalizeError(error);
  // 只有本服务的限流码和明确的秒数头同时存在时才自动重试，不重放 RAG 上游限流或未知写入错误。
  if (status === 429 && payload?.errorCode === 'IDOCK_RATE_LIMITED' && /^[1-5]$/.test(retryAfter || '')) {
    normalized.rateLimitRetryMs = Number(retryAfter) * 1000;
    normalized.hint = `等待 ${retryAfter} 秒后重试；同一用户所有 CLI 接口共用每秒一次额度`;
    normalized.details = { ...normalized.details, retry_after_seconds: Number(retryAfter) };
  }
  return normalized;
}

/** 创建 API 客户端，可注入连接配置与请求实现，测试无需业务环境或真实账号。 */
export function createApi({ connection = () => resolveConfig(), fetchFn = fetch, waitFn = wait } = {}) {
  /** 只向 idock 专属 API 发送用户 Key；不发送 User-Id 或 App Token，OSS 下载另走无凭证请求。 */
  async function requestOnce(config, path, params = {}, { file = false, method = 'GET', body, command } = {}) {
    const url = new URL(`${config.endpoint}${path}`);
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, String(value));
    }
    let response;
    try {
      response = await fetchFn(url, {
        method,
        headers: { 'X-Access-Key': config.accessKey, 'User-Agent': 'idock-cli',
          'X-Idock-Version': CLI_VERSION, ...(command ? { 'X-Idock-Command': command } : {}),
          ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
          Accept: file ? 'text/plain, text/markdown, application/pdf, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/json, application/octet-stream'
            : 'application/json' },
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
        signal: AbortSignal.timeout(file ? 300_000 : 60_000), redirect: 'error'
      });
    } catch (error) {
      throw new Error(error.name === 'TimeoutError' ? '接口请求超时，请稍后重试' : '无法连接服务，请检查服务地址和网络');
    }
    // 导出异常可能也是 HTTP 200 JSON；只有成功的非 JSON 响应才交给流下载处理。
    const isJson = /\bjson\b/i.test(response.headers.get('content-type') || '');
    if (file && response.ok && !isJson) {
      const contentType = response.headers.get('content-type') || '';
      if (!/^(text\/(plain|markdown)|application\/(pdf|vnd\.openxmlformats-officedocument\.wordprocessingml\.document|octet-stream))(;|$)/i.test(contentType)) {
        await response.body?.cancel();
        throw new Error('导出接口没有返回支持的文档内容，请检查服务地址');
      }
      return response;
    }
    // 数据库主键可能超过 JavaScript 安全整数；利用 Node 22 的 JSON 源文本保留精确数字字符串。
    const payload = await response.text().then((raw) => JSON.parse(raw, (key, value, context) =>
      typeof value === 'number' && !Number.isSafeInteger(value) && /^-?\d+$/.test(context?.source || '')
        ? context.source : value)).catch(() => null);
    if (!response.ok || payload?.success !== true) throw responseError(payload, response.status, response.headers.get('retry-after'));
    if (file) throw new Error('导出接口返回了 JSON，未收到文件内容');
    return payload.data;
  }

  /** 服务端在业务执行前返回用户限流时按 Retry-After 等待；重试沿用同一份连接、方法和请求体。 */
  async function request(path, params = {}, options = {}) {
    const config = requireConnection(await connection());
    for (let attempt = 0; ; attempt += 1) {
      try { return await requestOnce(config, path, params, options); }
      catch (error) {
        if (!error.rateLimitRetryMs || attempt >= MAX_RATE_LIMIT_RETRIES) throw error;
        await waitFn(error.rateLimitRetryMs);
      }
    }
  }

  return {
    /** Agent 扩展命令共用同一凭证隔离、错误映射和 HTTP 超时逻辑。 */
    request,
    /** 查询服务端从 Key 确认的用户及操作权限，登录时无需输入用户 ID。 */
    getUser: () => request('/idock/auth/me'),
    /** 撤销当前 Key，后端以摘要条件删除，避免并发重置时误删另一把新 Key。 */
    revokeKey: () => request('/idock/auth/access-key', {}, { method: 'DELETE' }),
    /** 以 ID 游标查询录音列表，沿用 App 的用户隔离、搜索和手机关联可见性，不传页码。 */
    listRecordings: (options) => request('/idock/recordings', options),
    /** 按数字会议主键查询详情，避免与听悟字符串 taskId 混淆。 */
    getRecording: (id) => request(`/idock/recordings/${encodeURIComponent(id)}`),
    /** 申请原始文件或听悟 MP3 下载授权；每次下载及重试都重新申请。 */
    audioDownload: (id, source) => request(`/idock/recordings/${encodeURIComponent(id)}/audio-url`, { source }),
    /** 仅申请转写短期授权，响应含签名信息，调用方必须消费后只返回本地文件结果。 */
    transcriptionDownload: (id) => request(`/idock/recordings/${encodeURIComponent(id)}/transcription-url`),
    /** 数字会议主键直接作为路径参数，服务端分别验证转写与纪要的导出权限。 */
    exportDocument: (id, type, format) => request(`/idock/recordings/${encodeURIComponent(id)}/export/${type}`,
      { format: format.toUpperCase() }, { file: true })
  };
}
