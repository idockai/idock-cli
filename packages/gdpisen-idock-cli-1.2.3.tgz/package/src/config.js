import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { CliError } from './result.js';

/** 获取配置文件路径；独立目录覆盖用于自动化运行和测试，不修改系统 HOME。 */
export function getSettingsFile() {
  return path.join(process.env.IDOCK_CONFIG_DIR || path.join(os.homedir(), '.idock'), 'settings.json');
}

/** 读取多环境配置；文件损坏时明确报错，避免覆盖用户已有凭证。 */
export async function loadConfig() {
  try {
    const config = JSON.parse(await fs.readFile(getSettingsFile(), 'utf8'));
    if (!config || typeof config !== 'object' || !config.profiles || typeof config.profiles !== 'object') {
      throw new Error('配置结构不正确');
    }
    return config;
  } catch (error) {
    if (error.code === 'ENOENT') return { activeProfile: 'cn_test', profiles: {} };
    throw new Error(`无法读取 CLI 配置：${error.message}`);
  }
}

/** 以临时文件和原子替换保存完整配置，避免进程中断留下半份 JSON。 */
export async function saveConfig(config) {
  const file = getSettingsFile();
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 });
  const temporary = `${file}.${randomUUID()}.tmp`;
  try {
    await fs.writeFile(temporary, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
    await fs.rename(temporary, file);
  } finally {
    await fs.rm(temporary, { force: true });
  }
}

/** 校验并规范化 API 根地址，支持网关路径前缀，不附加语雀的 /api/v2。 */
export function normalizeEndpoint(value) {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    throw new Error('服务地址须为 HTTP/HTTPS 地址，不能包含账号、查询参数或片段');
  }
  return url.toString().replace(/\/+$/, '');
}

/** 服务地址由发布者随包配置；缺少地址时明确报告安装包问题，不要求终端用户输入网关。 */
export function requireEndpoint(endpoint) {
  if (!endpoint) throw new CliError('RELEASE_CONFIG_INVALID', '当前安装包未配置服务地址', {
    hint: '请联系管理员获取已配置服务器地址的安装包'
  });
  return normalizeEndpoint(endpoint);
}

/**
 * 从模块相对路径读取发布配置，保证全局安装后在任意工作目录都能找到随包携带的网关地址。
 * endpoint 留空仅供开发阶段使用；打包检查会拒绝空值。参数供发布校验与隔离测试读取指定配置。
 */
export async function loadReleaseEndpoint(file = new URL('../config/release.json', import.meta.url)) {
  try {
    const release = JSON.parse(await fs.readFile(file, 'utf8'));
    if (!release || typeof release.endpoint !== 'string') throw new Error('endpoint 须为字符串');
    const endpoint = release.endpoint.trim();
    return endpoint ? normalizeEndpoint(endpoint) : undefined;
  } catch {
    throw new CliError('RELEASE_CONFIG_INVALID', '安装包的服务地址配置缺失或无效', {
      hint: '请联系管理员重新配置并打包安装'
    });
  }
}

/** 合并显式覆盖和随包默认地址；凭证始终使用当前选中环境，禁止回退到其他环境。 */
export async function resolveConfig(overrides = {}) {
  const saved = await loadConfig();
  const profile = overrides.profile || process.env.IDOCK_PROFILE || saved.activeProfile || 'cn_test';
  const current = saved.profiles[profile] || {};
  return {
    profile,
    endpoint: overrides.endpoint || process.env.IDOCK_ENDPOINT || current.endpoint || await loadReleaseEndpoint(),
    userId: current.userId,
    timezone: overrides.timezone || process.env.IDOCK_TIMEZONE || current.timezone,
    accessKey: process.env.IDOCK_ACCESS_KEY || current.accessKey
  };
}

/** 只允许修改非秘密连接设置；密钥必须经过 auth login 的远端校验。 */
export async function setConfig(key, value, overrides = {}) {
  if (!['endpoint', 'profile', 'timezone'].includes(key)) throw new Error('config set 仅支持 endpoint、profile、timezone；凭证请使用 auth login');
  const config = await loadConfig();
  const resolved = await resolveConfig(overrides);
  if (key === 'profile') {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(value)) throw new Error('profile 须为 1 至 64 位字母、数字、下划线或横线');
    config.activeProfile = value;
  } else {
    if (key === 'timezone') new Intl.DateTimeFormat('en', { timeZone: value }).format();
    config.profiles[resolved.profile] ||= {};
    if (key === 'endpoint') {
      const normalized = normalizeEndpoint(value);
      // 服务地址改变必须重新验证凭证，不能把旧环境秘密自动发送给新服务。
      if (config.profiles[resolved.profile].endpoint !== normalized) delete config.profiles[resolved.profile].accessKey;
      config.profiles[resolved.profile].endpoint = normalized;
    } else config.profiles[resolved.profile][key] = value;
  }
  await saveConfig(config);
  return { key, value, profile: config.activeProfile || resolved.profile };
}

/** 发请求前校验发布地址与个人 Key；服务地址问题和用户尚未登录分别提示。 */
export function requireConnection(config) {
  const endpoint = requireEndpoint(config.endpoint);
  if (!config.accessKey) throw new Error('请先执行 idock auth login，或配置 IDOCK_ACCESS_KEY');
  if (typeof config.accessKey !== 'string' || !config.accessKey.trim() || /[\r\n]/.test(config.accessKey)) throw new Error('AccessKey 格式无效');
  return { ...config, accessKey: config.accessKey.trim(), endpoint };
}

/** 保存已验证的环境和凭证，并将其设为当前环境。 */
export async function saveConnection(connection) {
  const config = await loadConfig();
  config.activeProfile = connection.profile;
  config.profiles[connection.profile] = {
    ...config.profiles[connection.profile],
    endpoint: normalizeEndpoint(connection.endpoint), userId: String(connection.userId), accessKey: connection.accessKey
  };
  await saveConfig(config);
}

/** 仅删除指定环境的本地 AccessKey，保留服务地址和已验证用户编号，其他环境凭证不受影响。 */
export async function clearAccessKey(profile) {
  const config = await loadConfig();
  if (config.profiles[profile]) delete config.profiles[profile].accessKey;
  await saveConfig(config);
}
