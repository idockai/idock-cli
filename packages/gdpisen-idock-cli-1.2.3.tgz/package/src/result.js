import { CLI_VERSION } from './version.js';

/** 所有命令共享的稳定错误类型；业务消息与重试建议分开，调用方无需解析中文文案。 */
export class CliError extends Error {
  constructor(code, message, { exitCode = 1, hint = '稍后重试，或执行 idock doctor 检查连接', retryable = false, missingScopes = [], details } = {}) {
    super(message); Object.assign(this, { code, exitCode, hint, retryable, missingScopes, details });
  }
}

/** 参数错误在发送请求或写入文件前返回。 */
export function argumentError(message) {
  return new CliError('INVALID_ARGUMENT', message, { exitCode: 2, hint: '执行 idock schema 查看命令参数' });
}

/** 规范化历史异常和 HTTP 异常，避免不同命令使用不同退出码。 */
export function normalizeError(error) {
  if (error.code === 'IDOCK_ARGUMENT_INVALID') return argumentError(error.message);
  if (error instanceof CliError) return error;
  const status = error.status;
  const auth = status === 401 || /AUTH|ACCESS_KEY_INVALID|LOGIN_REQUIRED/.test(error.code || '')
    || /请先执行 idock auth login/.test(error.message || '');
  const permission = status === 403;
  const normalized = new CliError(error.code || (auth ? 'AUTH_REQUIRED' : 'COMMAND_FAILED'), error.message || '命令执行失败', {
    exitCode: auth ? 3 : permission ? 5 : status === 429 ? 6 : [400, 422].includes(status) ? 2 : 1,
    hint: error.hint || (auth ? '执行 idock auth login，或在 App 重置后重新登录' : permission ? '在 App 中为 AccessKey 补充所需 scope' : undefined),
    retryable: status === 429 || status >= 500 || Boolean(error.retryable), missingScopes: error.missingScopes || [], details: error.details
  });
  normalized.status = status;
  return normalized;
}

/** 成功响应也始终包含四个顶层字段；内部命令可返回独立的分页、裁剪元信息。 */
export function success(data, meta = {}) {
  return { ok: true, data, meta: { cli_version: CLI_VERSION, ...meta }, error: null };
}

/** 失败信息不携带原始请求、堆栈、凭证或签名地址。 */
export function failure(error) {
  const item = normalizeError(error);
  return { ok: false, data: null, meta: { cli_version: CLI_VERSION }, error: {
    code: item.code, message: item.message, hint: item.hint, retryable: item.retryable,
    ...(item.missingScopes.length ? { missing_scopes: item.missingScopes } : {}),
    ...(item.details ? { details: item.details } : {})
  } };
}
