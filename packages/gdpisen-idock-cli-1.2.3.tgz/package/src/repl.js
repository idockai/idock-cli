import { createInterface } from 'node:readline/promises';
import chalk from 'chalk';
import { createCommands } from './commands.js';
import { renderRecordings } from './ui.js';
import { createRecordingPager } from './recording-pager.js';
import { CLI_VERSION } from './version.js';

/** 支持补全的命令前缀，交互模式与单次命令使用同一 Commander 参数定义。 */
const COMMANDS = ['help', 'list', 'find ', 'search ', 'next', 'prev', 'select ', 'download', 'export',
  'recordings list', 'recordings show ', 'recordings download ', 'recordings export ',
  'auth login', 'auth logout', 'auth status', 'auth revoke', 'whoami', 'clear', 'exit'];

/** 解析带引号的命令参数，保留 Windows 路径中的反斜杠，不通过系统 shell 执行任何输入。 */
export function splitArguments(input) {
  const result = [];
  let value = '';
  let quote = null;
  let started = false;
  for (const character of input) {
    if (quote) {
      if (character === quote) quote = null;
      else value += character;
      started = true;
    } else if (character === '"' || character === "'") { quote = character; started = true; }
    else if (/\s/.test(character)) {
      if (started) { result.push(value); value = ''; started = false; }
    } else { value += character; started = true; }
  }
  if (quote) throw new Error('命令中存在未闭合的引号');
  if (started) result.push(value);
  return result;
}

/** 中文交互浏览入口，提供历史、Tab 补全、分页、录音选择及快捷下载；非终端不进入等待。 */
export async function startRepl({ overrides = {}, runCommand } = {}) {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    throw new Error('交互模式需要终端；脚本请使用 idock recordings list/download/export');
  }
  const commands = createCommands({ overrides });
  const pager = createRecordingPager(commands.list);
  let page;
  let selected;
  let finished = false;
  console.log(chalk.cyan.bold(`idock Agent CLI  ${CLI_VERSION}`));
  console.log('list 查看列表 | find 录音名 | search 向量检索 | next/prev 翻页 | select 序号 | download | export | help | exit');
  const current = await commands.status({ local: true });
  console.log(`环境：${current.profile}  服务：${current.endpoint || '未配置'}`);

  /** 执行一次提问后立即关闭读取器，使登录时独立的隐藏 Key 输入不会被第二个读取器回显。 */
  async function question(prompt) {
    const abort = new AbortController();
    const reader = createInterface({ input: process.stdin, output: process.stdout, history,
      completer: (line) => [COMMANDS.filter((command) => command.startsWith(line)), line] });
    reader.on('SIGINT', () => { finished = true; abort.abort(); });
    reader.on('close', () => { abort.abort(); });
    try { return await reader.question(prompt, { signal: abort.signal }); }
    finally { reader.close(); }
  }

  /** 当前会话命令历史，只保存在内存中，不持久化登录输入。 */
  const history = [];
  /** 成功切换游标后显示当前页并重置选择；首尾不请求，不取消仍然有效的当前选择。 */
  async function refresh(operation, keyword) {
    const moved = operation === 'reset' ? await pager.reset(keyword)
      : operation === 'next' ? await pager.next() : await pager.previous();
    if (!moved) { console.log(operation === 'next' ? '已到最后一页。' : '已到第一页。'); return; }
    page = pager.current;
    selected = null;
    renderRecordings(page);
    console.log('输入 select 序号 选择录音，或 next/prev 翻页。');
  }

  while (!finished) {
    let input;
    try { input = (await question(chalk.cyan(`idock${selected ? '[已选择录音]' : ''}> `))).trim(); }
    catch (error) { if (finished || error.code === 'ABORT_ERR') break; throw error; }
    if (!input) continue;
    history.unshift(input);
    try {
      if (['exit', 'quit'].includes(input)) break;
      if (input === 'clear') { console.clear(); continue; }
      if (input === 'help') {
        console.log('list：第一页；find 关键词：按录音名筛选；search 问题：检索 RAG；next/prev：翻页；select 序号：选择录音。');
        console.log('限定检索时间示例：search "会议行动项" --time last-week；结果显示来源标题和录制时间，无匹配时明确提示。');
        console.log('选择后 download 下载原始文件；download --source mp3 下载处理音频；export --type summary --format word 导出纪要。');
        console.log('也支持全部 recordings/auth 命令；auth login 配置连接；参数可用引号包含空格，exit 退出。');
        continue;
      }
      if (input === 'list') { await refresh('reset'); continue; }
      if (input.startsWith('find ')) { await refresh('reset', input.slice(5).trim().replace(/^"(.*)"$/, '$1')); continue; }
      if (input === 'next' || input === 'prev') {
        await refresh(input); continue;
      }
      if (input.startsWith('select ')) {
        const number = input.slice(7).trim();
        if (!/^[1-9]\d*$/.test(number) || !page?.dataList?.[Number(number) - 1]) throw new Error('请输入当前页中的有效序号');
        selected = page.dataList[Number(number) - 1];
        console.log(`已选择：${selected.meetingName || '未命名录音'}`); continue;
      }
      let args = splitArguments(input);
      if (['repl', 'browse'].includes(args[0])) throw new Error('当前已在交互模式');
      if (['download', 'export'].includes(args[0])) {
        if (!selected) throw new Error('请先 list 并 select 序号选择录音');
        args = ['recordings', args[0], '--id', String(selected.id), ...args.slice(1)];
      }
      // 将启动时的环境参数加入每次调用，但不把 AccessKey 放入命令参数或历史记录。
      const globals = Object.entries({ profile: overrides.profile, endpoint: overrides.endpoint })
        .filter(([, value]) => value).flatMap(([name, value]) => [`--${name}`, String(value)]);
      await runCommand([...globals, ...args]);
    } catch (error) { console.error(chalk.red(`错误：${error.message}`)); }
  }
}
