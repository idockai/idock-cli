import chalk from 'chalk';

// 中文表格排版改编自 yuque/yuque-cli，来源信息见 UPSTREAM.md。
/** 为支持 OSC8 的交互终端生成可点击链接。 */
function hyperlink(label, url) {
  if (!process.stdout.isTTY || !url) return label;
  return `\u001B]8;;${url}\u0007${label}\u001B]8;;\u0007`;
}

/** 移除终端控制序列，计算表格宽度时只保留可见字符。 */
function stripControl(input) {
  return String(input)
    .replace(/\u001B\]8;;[^\u0007]*\u0007/g, '')
    .replace(/\u001B\]8;;\u0007/g, '')
    .replace(/\u001B\][^\u0007]*\u0007/g, '')
    .replace(/\u001B\[[0-?]*[ -/]*[@-~]/g, '');
}

/** 按中日韩全角字符计算显示宽度，复用上游表格排版规则。 */
function charDisplayWidth(ch) {
  const cp = ch.codePointAt(0);
  if (!cp) return 0;
  if (cp <= 0x1f || (cp >= 0x7f && cp <= 0x9f)) return 0;
  if (
    (cp >= 0x1100 && cp <= 0x115f) ||
    cp === 0x2329 ||
    cp === 0x232a ||
    (cp >= 0x2e80 && cp <= 0xa4cf && cp !== 0x303f) ||
    (cp >= 0xac00 && cp <= 0xd7a3) ||
    (cp >= 0xf900 && cp <= 0xfaff) ||
    (cp >= 0xfe10 && cp <= 0xfe19) ||
    (cp >= 0xfe30 && cp <= 0xfe6f) ||
    (cp >= 0xff00 && cp <= 0xff60) ||
    (cp >= 0xffe0 && cp <= 0xffe6)
  ) {
    return 2;
  }
  return 1;
}

/** 统计文本在终端中的可见列数。 */
function visibleLength(input) {
  const plain = stripControl(input);
  let len = 0;
  for (const ch of plain) len += charDisplayWidth(ch);
  return len;
}

/** 按显示列数截断文本，避免中文字符导致表格错位。 */
function truncatePlain(text, width) {
  const s = String(text ?? '');
  if (width <= 0) return '';
  let totalWidth = 0;
  for (const ch of s) totalWidth += charDisplayWidth(ch);
  if (totalWidth <= width) return s;
  if (width <= 3) return '.'.repeat(width);

  const max = width - 3;
  let out = '';
  let used = 0;
  for (const ch of s) {
    const w = charDisplayWidth(ch);
    if (used + w > max) break;
    out += ch;
    used += w;
  }
  return `${out}...`;
}

/** 按终端宽度收缩表格列，同时保留各列最小宽度。 */
function fitColumnWidths(columns, terminalWidth) {
  const mins = columns.map((c) => c.min || 6);
  const widths = columns.map((c) => c.pref || c.min || 12);
  const overhead = 3 * columns.length + 1;
  const available = Math.max(mins.reduce((a, b) => a + b, 0), terminalWidth - overhead);

  let total = widths.reduce((a, b) => a + b, 0);
  while (total > available) {
    let idx = -1;
    let best = -1;
    for (let i = 0; i < widths.length; i += 1) {
      if (widths[i] > mins[i] && widths[i] > best) {
        idx = i;
        best = widths[i];
      }
    }
    if (idx === -1) break;
    widths[idx] -= 1;
    total -= 1;
  }

  return widths;
}

/** 渲染单元格内容和对齐填充。 */
function renderCell(cell, width, align = 'left') {
  const normalized =
    typeof cell === 'object' && cell !== null
      ? { plain: cell.plain ?? '', url: cell.url, style: cell.style }
      : { plain: String(cell ?? '') };

  const plain = truncatePlain(normalized.plain, width);
  let display = normalized.url ? hyperlink(plain, normalized.url) : plain;
  if (typeof normalized.style === 'function') {
    display = normalized.style(display);
  }

  const pad = Math.max(0, width - visibleLength(display));
  if (align === 'right') return `${' '.repeat(pad)}${display}`;
  if (align === 'center') {
    const left = Math.floor(pad / 2);
    const right = pad - left;
    return `${' '.repeat(left)}${display}${' '.repeat(right)}`;
  }
  return `${display}${' '.repeat(pad)}`;
}

/** 将列定义和数据行渲染为带边框的中文表格。 */
function buildBorderTable(columns, rows, terminalWidth = process.stdout.columns || 120) {
  const widths = fitColumnWidths(columns, terminalWidth);

  const top = chalk.gray(`┌${widths.map((w) => '─'.repeat(w + 2)).join('┬')}┐`);
  const mid = chalk.gray(`├${widths.map((w) => '─'.repeat(w + 2)).join('┼')}┤`);
  const bottom = chalk.gray(`└${widths.map((w) => '─'.repeat(w + 2)).join('┴')}┘`);

  const headerCells = columns.map((col, i) =>
    renderCell({ plain: col.title, style: chalk.bold.cyan }, widths[i], col.align || 'left')
  );
  const headerLine = `│ ${headerCells.join(' │ ')} │`;

  const bodyLines = rows.map((row) => {
    const cells = columns.map((col, i) => renderCell(row[col.key], widths[i], col.align || 'left'));
    return `│ ${cells.join(' │ ')} │`;
  });

  return [top, headerLine, mid, ...bodyLines, bottom];
}


export { buildBorderTable, visibleLength, truncatePlain };

/** 格式化历史字段 meetingDurationSec，该字段在本项目中的实际单位是毫秒。 */
export function formatDuration(milliseconds) {
  if (milliseconds === null || milliseconds === undefined) return '-';
  const seconds = Math.floor(Math.max(0, Number(milliseconds) || 0) / 1000);
  return [Math.floor(seconds / 3600), Math.floor(seconds / 60) % 60, seconds % 60]
    .map((value) => value.toString().padStart(2, '0')).join(':');
}

/** 输出与交互模式共享的会议列表，搜索结果保留数字 ID，供后续下载和导出使用。 */
export function renderRecordings(page, stdout = console.log) {
  const rows = (page?.dataList || []).map((item, index) => ({ number: index + 1, id: item.id,
    name: item.meetingName || '未命名录音', duration: formatDuration(item.meetingDurationSec),
    status: item.tingwuStatus || item.status || '-', group: item.groupName || '-' }));
  for (const line of buildBorderTable([
    { key: 'number', title: '序号', min: 4, pref: 4 }, { key: 'id', title: '会议ID', min: 8, pref: 14 },
    { key: 'name', title: '录音名称', min: 12, pref: 36 }, { key: 'duration', title: '时长', min: 8, pref: 8 },
    { key: 'status', title: '处理状态', min: 10, pref: 12 }, { key: 'group', title: '分组', min: 6, pref: 10 }
  ], rows)) stdout(line);
  stdout(`第 ${page?.pageNumber || 1} 页，本页 ${rows.length} 条；${page?.next_cursor ? '可输入 next 查看下一页' : '已到末页'}`);
}
