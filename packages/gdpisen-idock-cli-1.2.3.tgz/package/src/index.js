#!/usr/bin/env node
import process from 'node:process';
import { realpathSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Command, Option, InvalidArgumentError } from 'commander';
import { createCommands } from './commands.js';
import { createAgentCommands } from './agent.js';
import { argumentError, failure, normalizeError, success } from './result.js';
import { schema } from './schema.js';
import { commandPath, describeCommands, renderHelp } from './help.js';
import { CLI_VERSION } from './version.js';
export { formatDuration } from './ui.js';

/** 参数解析器在网络请求和文件读取前拒绝非法数值。 */
function integer(min, max) {
  return (value) => {
    if (!/^\d+$/.test(value) || !Number.isSafeInteger(Number(value)) || Number(value) < min || Number(value) > max) {
      throw new InvalidArgumentError(`须为 ${min} 至 ${max} 的整数`);
    }
    return Number(value);
  };
}

/** 旧随机页码明确提示迁移方式，不仅返回数值范围错误，避免用户继续寻找深页参数。 */
function legacyFirstPage(value) {
  if (!/^\d+$/.test(value) || Number(value) !== 1) {
    throw new InvalidArgumentError('列表已改用游标分页，--page 仅兼容 1；下一页请使用 --cursor');
  }
  return 1;
}

/** 业务结果默认 JSON 信封，帮助默认终端排版；显式 JSON 帮助保留供 Agent 使用。 */
export function createProgram({ stdout = console.log, stderr = console.error, commandsFactory = createCommands,
  agentFactory = createAgentCommands, startReplFn, color = Boolean(process.stdout.isTTY) && !('NO_COLOR' in process.env),
  columns = process.stdout.columns, setExitCode = (code) => { process.exitCode = code; } } = {}) {
  const program = new Command();
  /** 只有显式选择 JSON 才包装帮助；业务命令仍沿用原有默认 JSON 格式。 */
  const jsonHelp = () => program.opts().json || program.opts().format === 'json' && program.getOptionValueSource('format') === 'cli';
  program.name('idock').description('iDock Agent CLI：录音、RAG 检索与闪记')
    .version(CLI_VERSION, '-V, --version', '显示版本信息').allowExcessArguments(false)
    .option('--profile <name>', '连接环境').option('--endpoint <url>', '服务根地址，支持网关前缀')
    .option('--timezone <IANA>', '覆盖用户时区，例如 Asia/Shanghai')
    .addOption(new Option('--format <format>', '终端输出格式').choices(['json', 'text']).default('json'))
    .option('--json', '显式输出 JSON，包括帮助；业务结果默认已为 JSON')
    .configureHelp({ showGlobalOptions: true,
      formatHelp: (command, helper) => renderHelp(command, helper, { color: color && !jsonHelp(), columns }) })
    .exitOverride().configureOutput({
      writeOut: (text) => {
        if (text.trim() === CLI_VERSION) stdout(program.opts().format === 'text' ? text.trim() : JSON.stringify(success({ version: CLI_VERSION }), null, 2));
        else stdout(jsonHelp() ? JSON.stringify(success({ help: text.trimEnd() }), null, 2) : text.trimEnd());
      },
      writeErr: (text) => stderr(text.trimEnd())
    });

  /** 统一命令结果与批量失败输出，部分成功也用 ok=false 明确告知 Agent。 */
  function action(method, { agent = false, argument = false, extra = {} } = {}) {
    return async (...args) => {
      const options = { ...args.at(-1).opts(), ...extra };
      const overrides = program.opts();
      const commands = agent ? agentFactory({ overrides }) : commandsFactory({ overrides });
      const result = await commands[method](...(argument ? [args[0], options] : [options]));
      const envelope = success(result, result?.next_cursor !== undefined ? { next_cursor: result.next_cursor } : {});
      if (result?.failed > 0) {
        envelope.ok = false; envelope.error = { code: 'PARTIAL_FAILURE', message: '部分文件处理失败', hint: '仅重试失败项', retryable: true };
        setExitCode(1);
      }
      stdout(overrides.format === 'text' ? renderText(result) : JSON.stringify(envelope, null, 2));
    };
  }

  /** 保留原 Node 交互模式；Agent 无参数调用只返回 schema，不进入阻塞会话。 */
  async function interactive() {
    const start = startReplFn || (await import('./repl.js')).startRepl;
    // 会话内的 search、download 等仍须沿用启动时的连接和时区，避免切回另一个 profile 或发送到错误服务。
    const options = program.opts();
    const globals = ['profile', 'endpoint', 'timezone'].flatMap(key => options[key] ? [`--${key}`, options[key]] : []);
    await start({ overrides: options, runCommand: (args) => main(['node', 'idock', ...globals, ...args, '--format', 'text'], {
      stdout, stderr, commandsFactory, agentFactory, setExitCode: () => {}
    }) });
  }
  program.action(() => stdout(JSON.stringify(success(schema), null, 2)));
  program.command('schema').description('输出完整命令与参数定义').action(() => stdout(JSON.stringify(success(schema), null, 2)));
  program.command('help').argument('[path...]').action((parts) => {
    let target = program;
    for (const name of parts) {
      const child = target.commands.find(item => item.name() === name);
      if (!child) throw argumentError(`未知命令：${[commandPath(target), name].filter(Boolean).join(' ')}`);
      target = child;
    }
    target.outputHelp();
  });
  program.command('repl').action(interactive); program.command('browse').action(interactive);
  program.command('whoami').action(action('whoami'));
  const auth = program.command('auth').description('管理用户专属 AccessKey');
  auth.command('login').option('--key-stdin', '从标准输入读取 Key').action(action('login'));
  auth.command('status').action(action('status'));
  auth.command('logout').action(action('logout'));
  auth.command('revoke').option('--yes', '确认撤销授权').action(action('revoke', { agent: true }));
  program.command('doctor').description('检查本地设置、网络、鉴权与服务版本').action(action('doctor', { agent: true }));
  program.command('config').command('set').argument('<key>').argument('<value>')
    .action(async (key, value) => {
      const result = await agentFactory({ overrides: program.opts() }).configSet(key, value);
      stdout(JSON.stringify(success(result), null, 2));
    });
  const recording = program.command('recording').description('Agent 录音读取与导入');
  timeOptions(recording.command('list').option('--keyword <text>').addOption(new Option('--source <source>').choices(['online', 'offline', 'merged'])))
    .action(action('list', { agent: true }));
  textOptions(recording.command('get').argument('<id>')
    .addOption(new Option('--section <name>').choices(['all', 'transcription', 'chapters', 'notes', 'summary']).default('all')))
    .action(action('get', { agent: true, argument: true }));
  textOptions(program.command('search').argument('<question>')).option('--limit <n>', '片段数，最多十条', integer(1, 10), 10)
    .option('--time <range>', '录音时间范围：today、7d、last-week')
    .option('--from <ISO>', '录音开始时间，须携带时区偏移（含）')
    .option('--to <ISO>', '录音结束时间，须携带时区偏移（不含）')
    .action(action('search', { agent: true, argument: true }));
  recording.command('import').argument('<file>').requiredOption('--duration-seconds <seconds>', '实际音频时长（秒）', integer(1, 14400))
    .option('--idempotency-key <key>', '重试同一业务导入时复用的幂等键')
    .option('--yes', '确认上传并触发转写').action(action('importRecording', { agent: true, argument: true }));
  const jobs = program.command('job');
  jobs.command('get').argument('<job_id>').action(action('jobGet', { agent: true, argument: true }));
  jobs.command('wait').argument('<job_id>').option('--timeout <seconds>', '最长等待秒数', integer(1, 86400), 300)
    .option('--interval <seconds>', '轮询间隔，秒', integer(1, 60), 3).action(action('jobWait', { agent: true, argument: true }));
  const flash = program.command('flash');
  for (const kind of ['note', 'todo', 'bill', 'idea', 'flash']) {
    const group = flash.command(kind);
    timeOptions(group.command('list')).action(action('flashList', { agent: true, extra: { kind } }));
    textOptions(group.command('get').argument('<id>')).action(action('flashGet', { agent: true, argument: true, extra: { kind } }));
  }
  // 复数兼容入口也使用游标，不保留随机跳页；旧 --page 1 仅为首页脚本提供迁移兼容。
  const legacy = program.command('recordings');
  legacy.command('list').option('--keyword <text>').option('--group-id <id>').option('--app-tmp-id <id>')
    .option('--cursor <cursor>', '上一页返回的 next_cursor')
    .option('--page <n>', '仅兼容首页 1；下一页使用 --cursor', legacyFirstPage)
    .option('--page-size <n>', '每页条数', integer(1, 200), 20).action(action('list'));
  legacy.command('show').argument('<id>').action(action('show', { argument: true }));
  for (const group of [recording, legacy]) {
    const download = group.command('download'); const document = group.command('export');
    for (const command of [download, document]) command.option('--id <id>').option('--ids <ids>')
      .option('--out <directory>', '保存目录', './exports').option('--overwrite', '覆盖同名文件');
    download.addOption(new Option('--source <source>').choices(['original', 'mp3']).default('original'))
      .option('--retries <n>', '重新授权次数', integer(0, 5), 1).action(action('download'));
    document.addOption(new Option('--type <type>').choices(['transcription', 'summary']).default('transcription'))
      .option('--retries <n>', '转写直传失败时重新授权次数', integer(0, 5), 1)
      .addOption(new Option('--file-format <type>').choices(['txt', 'md', 'markdown', 'pdf', 'word']).default('txt'));
    document.action(action('export'));
  }
  describeCommands(program);
  return program;
}

/** 所有正文命令使用同一字符窗口，最大四千字符。 */
function textOptions(command) {
  return command.option('--offset <n>', '字符偏移', integer(0, 2147483647), 0)
    .option('--length <n>', '单次字符数', integer(1, 4000), 4000);
}

/** 相对时间与显式 ISO 时间由服务端按用户时区解析。 */
function timeOptions(command) {
  return command.option('--time <range>', 'today、7d、last-week').option('--from <ISO>').option('--to <ISO>')
    .option('--limit <n>', '最多十条', integer(1, 10), 10).option('--cursor <cursor>');
}

/** 文本输出不展示内部 ID、用户 ID 和原始签名信息。 */
function renderText(value) {
  // RAG 正文附带可读来源，不把内部向量编号或分数当成面向用户的引用与置信度。
  if (value?.backend === 'rag' && Array.isArray(value.documents)) {
    if (value.low_confidence === true || value.documents.length === 0) return '未找到相关内容。';
    return value.documents.map((document, index) => {
      const metadata = document.metadata || {};
      const source = [metadata.title, metadata.recorded_at].filter(Boolean).join(' · ');
      return [`${index + 1}. ${source || '未提供来源信息'}`, document.content || ''].join('\n');
    }).join('\n\n');
  }
  if (value?.content !== undefined) return value.content;
  const clean = (item) => Array.isArray(item) ? item.map(clean) : item && typeof item === 'object'
    ? Object.fromEntries(Object.entries(item).filter(([key]) => !/(^id$|_id$|Id$|cursor|settingsFile)/.test(key)).map(([key, child]) => [key, clean(child)])) : item;
  return JSON.stringify(clean(value), null, 2);
}

/** 业务成功和异常都输出单份 JSON，帮助使用终端排版，错误退出码供 Agent 稳定分支处理。 */
export async function main(argv = process.argv, deps = {}) {
  // Commander 会先解析父级全局选项；旧导出 --format 在入口转成新文件参数，避免与 JSON/text 混用。
  const argumentsCopy = [...argv];
  if (argumentsCopy.includes('recordings') && argumentsCopy.includes('export')) {
    for (let i = 2; i < argumentsCopy.length - 1; i++) {
      if (argumentsCopy[i] === '--format' && ['txt', 'markdown', 'pdf', 'word'].includes(argumentsCopy[i + 1])) argumentsCopy[i] = '--file-format';
    }
  }
  try { await createProgram(deps).parseAsync(argumentsCopy); return true; }
  catch (error) {
    if (error.code?.startsWith('commander.') && error.exitCode === 0) return true;
    const normalized = error.code?.startsWith('commander.') ? argumentError(error.message) : normalizeError(error);
    (deps.stdout || console.log)(JSON.stringify(failure(normalized), null, 2));
    (deps.setExitCode || ((code) => { process.exitCode = code; }))(normalized.exitCode);
    return false;
  }
}

/** npm 链接和 Windows shim 均解析真实文件路径后启动。 */
function isDirectRun() {
  try { return Boolean(process.argv[1]) && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); }
  catch { return false; }
}
if (isDirectRun()) await main();
