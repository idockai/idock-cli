import { createApi } from './api.js';
import { clearAccessKey, getSettingsFile, requireConnection, requireEndpoint, resolveConfig, saveConnection } from './config.js';
import { fetchAudio, responseFileName, saveDownload } from './download.js';
import { ask } from './prompt.js';
import { argumentError } from './result.js';
import { downloadTranscription } from './transcription.js';

/** 后端会议主键使用有符号 Long，按精确整数比较上界，不能先转成 Number。 */
const MAX_DATABASE_ID = 9223372036854775807n;

/** 校验数据库主键并保留字符串；拒绝已失真的数字、听悟 taskId 和超出后端 Long 范围的值。 */
export function positiveId(value) {
  if (typeof value === 'number' && !Number.isSafeInteger(value)) {
    throw argumentError('会议 ID 数字精度不可靠，请使用列表中的原始 id 字符串');
  }
  const id = String(value ?? '');
  if (!/^[1-9]\d*$/.test(id)) throw argumentError('会议 ID 必须为正整数，请使用录音列表中的 id，不能使用听悟 taskId');
  if (id.length > 19 || BigInt(id) > MAX_DATABASE_ID) throw argumentError('会议 ID 超出后端 Long 范围，请使用列表中的 id');
  return id;
}

/** 解析批量会议编号，显式区分单个和批量参数并去重，避免同一命令重复导出。 */
export function recordingIds(options) {
  if (Boolean(options.id) === Boolean(options.ids)) throw argumentError('请指定 --id 或 --ids，二者只能选一个');
  const ids = options.id ? [options.id] : options.ids.split(',').map((id) => id.trim());
  if (ids.length > 200) throw argumentError('单次最多处理 200 个会议 ID');
  return [...new Set(ids.map(positiveId))];
}

/** 创建业务命令；API、文件保存和交互输入均可替换，交互模式与单次命令共享同一套逻辑。 */
export function createCommands({ overrides = {}, api, saveFn = saveDownload, fetchAudioFn = fetchAudio, askFn = ask,
  downloadTranscriptionFn = downloadTranscription } = {}) {
  const client = api || createApi({ connection: () => resolveConfig(overrides) });

  /** 查询连接概要；配置了 Key 时实时校验，交互入口可只读本地状态以便重新登录。 */
  async function status({ local = false } = {}) {
    const config = await resolveConfig(overrides);
    const user = config.accessKey && !local ? await client.getUser() : null;
    return { profile: config.profile, endpoint: config.endpoint || null, userId: config.userId || null,
      accessKeyConfigured: Boolean(config.accessKey), authenticated: Boolean(user),
      ...(user ? { userId: user.userId, fingerprint: user.fingerprint, suffix: user.suffix, scopes: user.scopes, expiresAt: user.expiresAt } : {}),
      settingsFile: getSettingsFile() };
  }

  /** 从管道读取一份秘密，不接受命令行明文参数，并限制输入长度避免误读大型文件。 */
  async function keyFromStdin() {
    if (process.stdin.isTTY) throw new Error('--key-stdin 需要通过标准输入传入 AccessKey');
    let value = '';
    for await (const chunk of process.stdin) {
      value += chunk.toString();
      if (value.length > 4096) throw new Error('AccessKey 输入过长');
    }
    if (!value.trim()) throw new Error('标准输入中的 AccessKey 不能为空');
    return value.trim();
  }

  /** 使用随包配置的地址，仅交互输入 Key 或从管道读取；校验成功后保存，不要求用户输入网关或用户 ID。 */
  async function login(options = {}) {
    const config = await resolveConfig(overrides);
    // 先检查发布地址，再读取个人 Key，避免漏配的安装包询问秘密后才失败。
    const endpoint = requireEndpoint(config.endpoint);
    const connection = requireConnection({
      ...config,
      endpoint,
      accessKey: options.keyStdin ? await keyFromStdin()
        : process.env.IDOCK_ACCESS_KEY || await askFn('AccessKey（输入不回显）：', { secret: true })
    });
    const user = await createApi({ connection: () => connection }).getUser();
    if (!user?.active || !/^[1-9]\d*$/.test(String(user.userId))) throw new Error('服务端未返回有效的 Key 用户身份');
    await saveConnection({ ...connection, userId: user.userId });
    return { profile: connection.profile, ...user };
  }

  /** 退出指定环境的本地凭证；环境变量由调用终端管理，存在时明确告知。 */
  async function logout() {
    const config = await resolveConfig(overrides);
    await clearAccessKey(config.profile);
    return { profile: config.profile, cleared: true, environmentAccessKeyActive: Boolean(process.env.IDOCK_ACCESS_KEY) };
  }

  /** 服务端撤销成功后清除本地 Key；失败时保留配置，让用户可重试或单独执行本地退出。 */
  async function revoke() {
    await client.revokeKey();
    return { ...await logout(), revoked: true };
  }

  /** 列表统一传递 ID 游标；旧页码仅接受首页，不模拟遍历前面所有页，避免隐藏的深分页开销。 */
  async function list(options = {}) {
    if (options.page !== undefined && options.page !== 1) throw argumentError('列表已改用游标，请使用 --cursor；--page 仅兼容 1');
    return client.listRecordings({ cursor: options.cursor, pageSize: options.pageSize ?? 20,
      keyword: options.keyword, groupId: options.groupId, apptmpid: options.appTmpId });
  }

  /** 单个录音流下载；失败可重新获取签名，避免复用过期地址。 */
  async function downloadOne(id, options) {
    for (let attempt = 0; ; attempt += 1) {
      try {
        const ticket = await client.audioDownload(id, options.source || 'original');
        if (!ticket?.downloadUrl) throw new Error('服务端未返回音频下载地址');
        const response = await fetchAudioFn(ticket.downloadUrl);
        const result = await saveFn(response, { directory: options.out,
          fileName: `${id}_${ticket.fileName || 'recording'}`, overwrite: options.overwrite,
          onProgress: options.onProgress });
        return { id, source: ticket.source, ...result };
      } catch (error) {
        const retryable = [403, 408, 429, 500, 502, 503, 504].includes(error.status)
          || (!error.status && !error.code);
        if (attempt >= (options.retries ?? 1) || !retryable) throw error;
      }
    }
  }

  /** 转写文本使用 OSS 直传并在本地转换；过期/断连最多重新签发指定次数，鉴权失败不重复申请。 */
  async function exportTranscription(id, options, format) {
    for (let attempt = 0; ; attempt += 1) {
      const ticket = await client.transcriptionDownload(id);
      try {
        return await downloadTranscriptionFn(ticket, { ...options, id, format }, { saveFn });
      } catch (error) {
        const retryable = [403, 408, 429, 500, 502, 503, 504].includes(error.status) || (!error.status && !error.code);
        if (attempt >= (options.retries ?? 1) || !retryable) throw error;
      }
    }
  }

  /** 转写 TXT/Markdown 不再经过后端正文中转；纪要及 PDF/Word 保留已有文档生成接口。 */
  async function exportOne(id, options) {
    const type = options.type || 'transcription';
    const input = options.format || options.fileFormat || 'txt';
    const format = input === 'md' ? 'markdown' : input;
    if (type === 'transcription' && ['txt', 'markdown'].includes(format)) {
      return { id, type, format, ...await exportTranscription(id, options, format) };
    }
    const extensions = { txt: 'txt', markdown: 'md', pdf: 'pdf', word: 'docx' };
    const response = await client.exportDocument(id, type, format);
    const name = responseFileName(response, `${type}.${extensions[format]}`);
    const result = await saveFn(response, { directory: options.out, fileName: `${id}_${name}`,
      overwrite: options.overwrite, onProgress: options.onProgress });
    return { id, type, format, ...result };
  }

  /** 逐个执行批量任务，保留已成功文件并收集每项失败；命令层据此返回非零退出码。 */
  async function runBatch(options, operation) {
    const results = [];
    for (const id of recordingIds(options)) {
      try { results.push({ success: true, ...await operation(id, options) }); }
      catch (error) { results.push({ id, success: false, errorCode: error.code || 'DOWNLOAD_FAILED', errorMessage: error.message }); }
    }
    return { results, succeeded: results.filter((item) => item.success).length,
      failed: results.filter((item) => !item.success).length };
  }

  return {
    status, login, logout, revoke, list,
    /** 查询当前 Key 绑定的用户与操作权限，不返回账号登录 Token。 */
    whoami: () => client.getUser(),
    /** 查询指定会议列表详情，参数始终使用数字主键。 */
    show: (id) => client.getRecording(positiveId(id)),
    /** 下载一个或多个音频，统一按所选来源执行。 */
    download: (options) => runBatch(options, downloadOne),
    /** 导出一个或多个会议文档，单项失败不丢弃其它成功结果。 */
    export: (options) => runBatch(options, exportOne)
  };
}
