import { createInterface } from 'node:readline/promises';
import { Writable } from 'node:stream';

/** 询问一个配置值；非交互环境要求调用方提供参数或环境变量，防止脚本永久等待。 */
export async function ask(question, { secret = false } = {}) {
  if (!process.stdin.isTTY) throw new Error('非交互模式请通过参数和 IDOCK_ACCESS_KEY 环境变量提供连接配置');
  let muted = false;
  const output = new Writable({
    /** 隐藏 AccessKey 输入及终端回显，只保留问题文字。 */
    write(chunk, encoding, callback) {
      if (!muted) process.stderr.write(chunk);
      callback();
    }
  });
  const reader = createInterface({ input: process.stdin, output, terminal: true });
  const abort = new AbortController();
  reader.once('SIGINT', () => { abort.abort(); });
  reader.once('close', () => { abort.abort(); });
  try {
    const answer = reader.question(question, { signal: abort.signal });
    muted = secret;
    return (await answer).trim();
  } catch (error) {
    if (error.code === 'ABORT_ERR') throw new Error('已取消输入');
    throw error;
  } finally {
    reader.close();
    if (secret) process.stderr.write('\n');
  }
}
