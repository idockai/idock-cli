/**
 * 交互录音浏览器只保存已访问的请求游标和当前一页正文，不累计整份历史记录。
 * 上一页通过历史游标重新查询；成功后才提交状态，失败不会丢失当前页或移动页位置。
 */
export function createRecordingPager(list, { pageSize = 10 } = {}) {
  /** 已访问页的请求游标；首页不传游标，数组位置仅作终端显示，不发送给服务器。 */
  let cursors = [undefined];
  /** 当前页在已访问游标中的位置，从零开始。 */
  let index = 0;
  /** 当前关键词与当前响应在请求成功后一起更新。 */
  let keyword;
  /** 当前页数据，未查询时为 null；不在本地缓存其它页的录音内容。 */
  let page = null;

  /** 加载指定游标并原子替换会话状态；筛选重置或返回上一页会丢弃后续旧游标。 */
  async function load(cursor, target, nextKeyword, history) {
    const result = await list({ cursor, pageSize, keyword: nextKeyword });
    // 重复游标会导致 next 永远返回同一页；拒绝环路，使服务异常不会放大为无限翻页。
    if (result.next_cursor && [...history.slice(0, target), cursor].includes(result.next_cursor)) {
      throw new Error('服务返回了重复游标，请重新执行 list 查询');
    }
    cursors = [...history.slice(0, target), cursor];
    index = target;
    keyword = nextKeyword;
    page = result;
    return true;
  }

  return {
    /** 显示页序号来自会话游标位置，不声称知道总页数或数据库总条数。 */
    get current() { return page ? { ...page, pageNumber: index + 1 } : null; },
    /** 显式 list/find 从首页重新查询，并清空原筛选下的游标历史。 */
    reset: (nextKeyword) => load(undefined, 0, nextKeyword, []),
    /** 末页不发送 HTTP；未加载时查询首页，否则仅跟随响应中的下一页游标。 */
    async next() {
      if (!page) return load(undefined, 0, keyword, []);
      if (!page.next_cursor) return false;
      return load(page.next_cursor, index + 1, keyword, cursors);
    },
    /** 首页不发送 HTTP；其它页面使用上一次保存的请求游标，支持跨服务节点读取。 */
    async previous() {
      if (!page) return load(undefined, 0, keyword, []);
      if (index === 0) return false;
      return load(cursors[index - 1], index - 1, keyword, cursors);
    }
  };
}
